package jca;

import test.assertions.Assertions;
import crypto.analysis.CrySLRulesetSelector.Ruleset;
import org.junit.Test;
import java.security.KeyStore;
import java.io.IOException;
import java.security.KeyStoreException;
import java.security.cert.CertificateException;
import java.security.Key;
import java.security.KeyStore.ProtectionParameter;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.KeyStore.Entry;
import java.security.KeyStore.LoadStoreParameter;
import java.lang.String;
import test.UsagePatternTestingFramework;
import java.io.InputStream;
import java.security.UnrecoverableEntryException;

public class KeyStoreTest extends UsagePatternTestingFramework {
	protected Ruleset getRuleSet() {
		return Ruleset.JavaCryptographicArchitecture;

	}

	@Test
	public void keyStoreValidTest1()
			throws NoSuchAlgorithmException, IOException, KeyStoreException, CertificateException {

		InputStream fileinput = null;
		String keyStoreAlgorithm = null;
		char[] passwordIn = null;

		KeyStore keyStore0 = KeyStore.getInstance(keyStoreAlgorithm);
		keyStore0.load(fileinput, passwordIn);
		Assertions.hasEnsuredPredicate(keyStore0);
		Assertions.mustBeInAcceptingState(keyStore0);

	}

	@Test
	public void keyStoreValidTest2() throws NoSuchAlgorithmException, UnrecoverableKeyException, IOException,
			KeyStoreException, CertificateException {

		char[] passwordKey = null;
		String alias = null;
		InputStream fileinput = null;
		String keyStoreAlgorithm = null;
		char[] passwordIn = null;

		KeyStore keyStore0 = KeyStore.getInstance(keyStoreAlgorithm);
		keyStore0.load(fileinput, passwordIn);
		Key key = keyStore0.getKey(alias, passwordKey);
		Assertions.hasEnsuredPredicate(key);
		Assertions.mustBeInAcceptingState(keyStore0);

	}

	@Test
	public void keyStoreValidTest3() throws NoSuchAlgorithmException, UnrecoverableKeyException, IOException,
			KeyStoreException, CertificateException, UnrecoverableEntryException {

		char[] passwordKey = null;
		String aliasGet = null;
		String alias = null;
		InputStream fileinput = null;
		String keyStoreAlgorithm = null;
		char[] passwordIn = null;
		ProtectionParameter protParamGet = null;

		KeyStore keyStore0 = KeyStore.getInstance(keyStoreAlgorithm);
		keyStore0.load(fileinput, passwordIn);
		keyStore0.getEntry(aliasGet, protParamGet);
		Key key = keyStore0.getKey(alias, passwordKey);
		Assertions.hasEnsuredPredicate(key);
		Assertions.mustBeInAcceptingState(keyStore0);

	}

	@Test
	public void keyStoreValidTest4() throws NoSuchAlgorithmException, UnrecoverableKeyException, IOException,
			KeyStoreException, CertificateException, UnrecoverableEntryException {

		char[] passwordKey = null;
		String aliasGet = null;
		String alias = null;
		Entry entry = null;
		InputStream fileinput = null;
		String keyStoreAlgorithm = null;
		String aliasSet = null;
		ProtectionParameter protParamSet = null;
		char[] passwordIn = null;
		LoadStoreParameter paramStore = null;
		ProtectionParameter protParamGet = null;

		KeyStore keyStore0 = KeyStore.getInstance(keyStoreAlgorithm);
		keyStore0.load(fileinput, passwordIn);
		keyStore0.getEntry(aliasGet, protParamGet);
		Key key = keyStore0.getKey(alias, passwordKey);
		keyStore0.setEntry(aliasSet, entry, protParamSet);
		keyStore0.store(paramStore);
		Assertions.hasEnsuredPredicate(key);
		Assertions.mustBeInAcceptingState(keyStore0);

	}

	@Test
	public void keyStoreInvalidTest1() throws KeyStoreException {

		String keyStoreAlgorithm = null;

		KeyStore keyStore0 = KeyStore.getInstance(keyStoreAlgorithm);
		Assertions.notHasEnsuredPredicate(keyStore0);
		Assertions.mustNotBeInAcceptingState(keyStore0);

	}

	@Test
	public void keyStoreInvalidTest2() throws NoSuchAlgorithmException, UnrecoverableKeyException, KeyStoreException {

		char[] passwordKey = null;
		String alias = null;
		String keyStoreAlgorithm = null;

		KeyStore keyStore0 = KeyStore.getInstance(keyStoreAlgorithm);
		Key key = keyStore0.getKey(alias, passwordKey);
		Assertions.notHasEnsuredPredicate(key);
		Assertions.mustNotBeInAcceptingState(keyStore0);

	}

	@Test
	public void keyStoreInvalidTest3()
			throws NoSuchAlgorithmException, UnrecoverableKeyException, KeyStoreException, UnrecoverableEntryException {

		char[] passwordKey = null;
		String aliasGet = null;
		String alias = null;
		String keyStoreAlgorithm = null;
		ProtectionParameter protParamGet = null;

		KeyStore keyStore0 = KeyStore.getInstance(keyStoreAlgorithm);
		keyStore0.getEntry(aliasGet, protParamGet);
		Key key = keyStore0.getKey(alias, passwordKey);
		Assertions.notHasEnsuredPredicate(key);
		Assertions.mustNotBeInAcceptingState(keyStore0);

	}

	@Test
	public void keyStoreInvalidTest4() throws NoSuchAlgorithmException, UnrecoverableKeyException, IOException,
			KeyStoreException, CertificateException, UnrecoverableEntryException {

		char[] passwordKey = null;
		String aliasGet = null;
		String alias = null;
		Entry entry = null;
		String keyStoreAlgorithm = null;
		String aliasSet = null;
		ProtectionParameter protParamSet = null;
		LoadStoreParameter paramStore = null;
		ProtectionParameter protParamGet = null;

		KeyStore keyStore0 = KeyStore.getInstance(keyStoreAlgorithm);
		keyStore0.getEntry(aliasGet, protParamGet);
		Key key = keyStore0.getKey(alias, passwordKey);
		keyStore0.setEntry(aliasSet, entry, protParamSet);
		keyStore0.store(paramStore);
		Assertions.notHasEnsuredPredicate(key);
		Assertions.mustNotBeInAcceptingState(keyStore0);

	}

	@Test
	public void keyStoreInvalidTest5() throws NoSuchAlgorithmException, UnrecoverableKeyException, IOException,
			KeyStoreException, CertificateException {

		char[] passwordKey = null;
		String alias = null;
		Entry entry = null;
		InputStream fileinput = null;
		String keyStoreAlgorithm = null;
		String aliasSet = null;
		ProtectionParameter protParamSet = null;
		char[] passwordIn = null;
		LoadStoreParameter paramStore = null;

		KeyStore keyStore0 = KeyStore.getInstance(keyStoreAlgorithm);
		keyStore0.load(fileinput, passwordIn);
		Key key = keyStore0.getKey(alias, passwordKey);
		keyStore0.setEntry(aliasSet, entry, protParamSet);
		keyStore0.store(paramStore);
		Assertions.hasEnsuredPredicate(key);
		Assertions.mustNotBeInAcceptingState(keyStore0);

	}

	@Test
	public void keyStoreInvalidTest6() throws NoSuchAlgorithmException, IOException, KeyStoreException,
			CertificateException, UnrecoverableEntryException {

		String aliasGet = null;
		Entry entry = null;
		InputStream fileinput = null;
		String keyStoreAlgorithm = null;
		String aliasSet = null;
		ProtectionParameter protParamSet = null;
		char[] passwordIn = null;
		LoadStoreParameter paramStore = null;
		ProtectionParameter protParamGet = null;

		KeyStore keyStore0 = KeyStore.getInstance(keyStoreAlgorithm);
		keyStore0.load(fileinput, passwordIn);
		keyStore0.getEntry(aliasGet, protParamGet);
		keyStore0.setEntry(aliasSet, entry, protParamSet);
		keyStore0.store(paramStore);
		Assertions.hasEnsuredPredicate(keyStore0);
		Assertions.mustNotBeInAcceptingState(keyStore0);

	}

	@Test
	public void keyStoreInvalidTest7() throws NoSuchAlgorithmException, UnrecoverableKeyException, IOException,
			KeyStoreException, CertificateException, UnrecoverableEntryException {

		char[] passwordKey = null;
		String aliasGet = null;
		String alias = null;
		InputStream fileinput = null;
		String keyStoreAlgorithm = null;
		char[] passwordIn = null;
		LoadStoreParameter paramStore = null;
		ProtectionParameter protParamGet = null;

		KeyStore keyStore0 = KeyStore.getInstance(keyStoreAlgorithm);
		keyStore0.load(fileinput, passwordIn);
		keyStore0.getEntry(aliasGet, protParamGet);
		Key key = keyStore0.getKey(alias, passwordKey);
		keyStore0.store(paramStore);
		Assertions.hasEnsuredPredicate(key);
		Assertions.mustNotBeInAcceptingState(keyStore0);

	}
}