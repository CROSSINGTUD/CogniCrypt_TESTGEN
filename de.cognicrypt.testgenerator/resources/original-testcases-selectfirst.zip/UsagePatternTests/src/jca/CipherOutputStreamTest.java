package jca;

import java.io.OutputStream;
import test.assertions.Assertions;
import crypto.analysis.CrySLRulesetSelector.Ruleset;
import org.junit.Test;
import java.io.IOException;
import test.UsagePatternTestingFramework;
import javax.crypto.CipherOutputStream;
import javax.crypto.Cipher;

public class CipherOutputStreamTest extends UsagePatternTestingFramework {
	protected Ruleset getRuleSet() {
		return Ruleset.JavaCryptographicArchitecture;

	}

	@Test
	public void cipherOutputStreamValidTest1() throws IOException {

		OutputStream os = null;
		int b = 0;
		Cipher ciph = null;

		CipherOutputStream cipherOutputStream0 = new CipherOutputStream(os, ciph);
		cipherOutputStream0.write(b);
		cipherOutputStream0.close();
		Assertions.hasEnsuredPredicate(os);
		Assertions.mustBeInAcceptingState(cipherOutputStream0);

	}

	@Test
	public void cipherOutputStreamInvalidTest1() {

		OutputStream os = null;
		Cipher ciph = null;

		CipherOutputStream cipherOutputStream0 = new CipherOutputStream(os, ciph);
		Assertions.notHasEnsuredPredicate(os);
		Assertions.mustNotBeInAcceptingState(cipherOutputStream0);

	}

	@Test
	public void cipherOutputStreamInvalidTest2() throws IOException {

		OutputStream os = null;
		int b = 0;
		Cipher ciph = null;

		CipherOutputStream cipherOutputStream0 = new CipherOutputStream(os, ciph);
		cipherOutputStream0.write(b);
		Assertions.notHasEnsuredPredicate(os);
		Assertions.mustNotBeInAcceptingState(cipherOutputStream0);

	}

	@Test
	public void cipherOutputStreamInvalidTest3() throws IOException {

		OutputStream os = null;
		Cipher ciph = null;

		CipherOutputStream cipherOutputStream0 = new CipherOutputStream(os, ciph);
		cipherOutputStream0.close();
		Assertions.notHasEnsuredPredicate(os);
		Assertions.mustNotBeInAcceptingState(cipherOutputStream0);

	}
}