package jca;

import java.security.SecureRandom;
import test.assertions.Assertions;
import crypto.analysis.CrySLRulesetSelector.Ruleset;
import java.security.NoSuchAlgorithmException;
import org.junit.Test;
import test.UsagePatternTestingFramework;

public class SecureRandomTest extends UsagePatternTestingFramework {
	protected Ruleset getRuleSet() {
		return Ruleset.JavaCryptographicArchitecture;

	}

	@Test
	public void secureRandomValidTest1() throws NoSuchAlgorithmException {

		SecureRandom secureRandom0 = SecureRandom.getInstance("SHA1PRNG");
		Assertions.hasEnsuredPredicate(secureRandom0);
		Assertions.mustBeInAcceptingState(secureRandom0);

	}

	@Test
	public void secureRandomValidTest2() throws NoSuchAlgorithmException {

		int num = 0;

		SecureRandom secureRandom1 = SecureRandom.getInstance("SHA1PRNG");
		byte[] genSeed = secureRandom1.generateSeed(num);
		Assertions.hasEnsuredPredicate(genSeed);
		Assertions.mustBeInAcceptingState(secureRandom1);

		SecureRandom secureRandom0 = SecureRandom.getInstance("SHA1PRNG");
		secureRandom0.setSeed(genSeed);
		Assertions.hasEnsuredPredicate(secureRandom0);
		Assertions.mustBeInAcceptingState(secureRandom0);

	}

	@Test
	public void secureRandomValidTest3() throws NoSuchAlgorithmException {

		int num = 0;

		SecureRandom secureRandom0 = SecureRandom.getInstance("SHA1PRNG");
		byte[] genSeed = secureRandom0.generateSeed(num);
		Assertions.hasEnsuredPredicate(genSeed);
		Assertions.mustBeInAcceptingState(secureRandom0);

	}

	@Test
	public void secureRandomValidTest4() throws NoSuchAlgorithmException {

		int num = 0;

		SecureRandom secureRandom1 = SecureRandom.getInstance("SHA1PRNG");
		byte[] genSeed = secureRandom1.generateSeed(num);
		Assertions.hasEnsuredPredicate(genSeed);
		Assertions.mustBeInAcceptingState(secureRandom1);

		num = 0;

		SecureRandom secureRandom0 = SecureRandom.getInstance("SHA1PRNG");
		secureRandom0.setSeed(genSeed);
		genSeed = secureRandom0.generateSeed(num);
		Assertions.hasEnsuredPredicate(genSeed);
		Assertions.mustBeInAcceptingState(secureRandom0);

	}
}