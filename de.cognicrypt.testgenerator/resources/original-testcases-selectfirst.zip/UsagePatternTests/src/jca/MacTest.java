package jca;

import java.security.Key;
import java.lang.IllegalStateException;
import test.assertions.Assertions;
import crypto.analysis.CrySLRulesetSelector.Ruleset;
import java.security.NoSuchAlgorithmException;
import javax.crypto.Mac;
import org.junit.Test;
import java.security.InvalidKeyException;
import test.UsagePatternTestingFramework;

public class MacTest extends UsagePatternTestingFramework {
	protected Ruleset getRuleSet() {
		return Ruleset.JavaCryptographicArchitecture;

	}

	@Test
	public void macValidTest1() throws IllegalStateException, NoSuchAlgorithmException, InvalidKeyException {

		Key key = null;

		Mac mac0 = Mac.getInstance("HmacMD5");
		mac0.init(key);
		byte[] output1 = mac0.doFinal();
		Assertions.hasEnsuredPredicate(output1);
		Assertions.mustBeInAcceptingState(mac0);

	}

	@Test
	public void macValidTest2() throws IllegalStateException, NoSuchAlgorithmException, InvalidKeyException {

		byte inp = 0;
		Key key = null;

		Mac mac0 = Mac.getInstance("HmacMD5");
		mac0.init(key);
		mac0.update(inp);
		byte[] output1 = mac0.doFinal();
		Assertions.hasEnsuredPredicate(output1);
		Assertions.mustBeInAcceptingState(mac0);

	}

	@Test
	public void macInvalidTest1() throws NoSuchAlgorithmException {

		Mac mac0 = Mac.getInstance("HmacMD5");
		Assertions.mustNotBeInAcceptingState(mac0);

	}

	@Test
	public void macInvalidTest2() throws NoSuchAlgorithmException, InvalidKeyException {

		Key key = null;

		Mac mac0 = Mac.getInstance("HmacMD5");
		mac0.init(key);
		Assertions.mustNotBeInAcceptingState(mac0);

	}

	@Test
	public void macInvalidTest3() throws IllegalStateException, NoSuchAlgorithmException {

		Mac mac0 = Mac.getInstance("HmacMD5");
		byte[] output1 = mac0.doFinal();
		Assertions.notHasEnsuredPredicate(output1);
		Assertions.mustNotBeInAcceptingState(mac0);

	}

	@Test
	public void macInvalidTest4() throws IllegalStateException, NoSuchAlgorithmException, InvalidKeyException {

		byte inp = 0;
		Key key = null;

		Mac mac0 = Mac.getInstance("HmacMD5");
		mac0.init(key);
		mac0.update(inp);
		Assertions.mustNotBeInAcceptingState(mac0);

	}

	@Test
	public void macInvalidTest5() throws IllegalStateException, NoSuchAlgorithmException {

		byte inp = 0;

		Mac mac0 = Mac.getInstance("HmacMD5");
		mac0.update(inp);
		byte[] output1 = mac0.doFinal();
		Assertions.notHasEnsuredPredicate(output1);
		Assertions.mustNotBeInAcceptingState(mac0);

	}
}