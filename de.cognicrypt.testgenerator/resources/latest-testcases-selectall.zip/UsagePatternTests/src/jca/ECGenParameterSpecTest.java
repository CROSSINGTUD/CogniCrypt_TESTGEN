package jca;

import test.assertions.Assertions;
import java.security.spec.ECGenParameterSpec;
import crypto.analysis.CrySLRulesetSelector.Ruleset;
import org.junit.Test;
import java.lang.String;
import test.UsagePatternTestingFramework;

public class ECGenParameterSpecTest extends UsagePatternTestingFramework {
	protected Ruleset getRuleSet() {
		return Ruleset.JavaCryptographicArchitecture;

	}

	@Test
	public void eCGenParameterSpecValidTest1() {

		String stdName = null;

		ECGenParameterSpec eCGenParameterSpec0 = new ECGenParameterSpec(stdName);
		Assertions.hasEnsuredPredicate(eCGenParameterSpec0);
		Assertions.mustBeInAcceptingState(eCGenParameterSpec0);

	}
}