package jca;

import java.security.KeyPairGenerator;
import java.security.KeyPair;
import test.assertions.Assertions;
import crypto.analysis.CrySLRulesetSelector.Ruleset;
import org.junit.Test;
import java.security.Provider;
import java.security.InvalidAlgorithmParameterException;
import java.security.SecureRandom;
import java.security.spec.DSAParameterSpec;
import java.security.NoSuchAlgorithmException;
import java.math.BigInteger;
import test.UsagePatternTestingFramework;
import java.security.NoSuchProviderException;

public class KeyPairGeneratorTest extends UsagePatternTestingFramework {
	protected Ruleset getRuleSet() {
		return Ruleset.JavaCryptographicArchitecture;

	}

	@Test
	public void keyPairGeneratorValidTest1() throws NoSuchAlgorithmException {

		KeyPairGenerator keyPairGenerator0 = KeyPairGenerator.getInstance("RSA");
		keyPairGenerator0.initialize(4096);
		KeyPair keyPair = keyPairGenerator0.generateKeyPair();
		Assertions.hasEnsuredPredicate(keyPair);
		Assertions.mustBeInAcceptingState(keyPairGenerator0);

	}

	@Test
	public void keyPairGeneratorValidTest2() throws NoSuchAlgorithmException, NoSuchProviderException {

		KeyPairGenerator keyPairGenerator0 = KeyPairGenerator.getInstance("RSA", (Provider) null);
		keyPairGenerator0.initialize(4096);
		KeyPair keyPair = keyPairGenerator0.generateKeyPair();
		Assertions.hasEnsuredPredicate(keyPair);
		Assertions.mustBeInAcceptingState(keyPairGenerator0);

	}

	@Test
	public void keyPairGeneratorValidTest3() throws NoSuchAlgorithmException {

		KeyPairGenerator keyPairGenerator0 = KeyPairGenerator.getInstance("RSA");
		keyPairGenerator0.initialize(4096, (SecureRandom) null);
		KeyPair keyPair = keyPairGenerator0.generateKeyPair();
		Assertions.hasEnsuredPredicate(keyPair);
		Assertions.mustBeInAcceptingState(keyPairGenerator0);

	}

	@Test
	public void keyPairGeneratorValidTest4() throws NoSuchAlgorithmException, InvalidAlgorithmParameterException {

		BigInteger q = null;

		DSAParameterSpec dSAParameterSpec0 = new DSAParameterSpec(BigInteger.valueOf(2), q, BigInteger.valueOf(1));
		Assertions.hasEnsuredPredicate(dSAParameterSpec0);
		Assertions.mustBeInAcceptingState(dSAParameterSpec0);

		KeyPairGenerator keyPairGenerator0 = KeyPairGenerator.getInstance("RSA");
		keyPairGenerator0.initialize(dSAParameterSpec0);
		KeyPair keyPair = keyPairGenerator0.generateKeyPair();
		Assertions.hasEnsuredPredicate(keyPair);
		Assertions.mustBeInAcceptingState(keyPairGenerator0);

	}

	@Test
	public void keyPairGeneratorValidTest5() throws NoSuchAlgorithmException, InvalidAlgorithmParameterException {

		BigInteger q = null;

		DSAParameterSpec dSAParameterSpec0 = new DSAParameterSpec(BigInteger.valueOf(1), q, BigInteger.valueOf(2));
		Assertions.hasEnsuredPredicate(dSAParameterSpec0);
		Assertions.mustBeInAcceptingState(dSAParameterSpec0);

		KeyPairGenerator keyPairGenerator0 = KeyPairGenerator.getInstance("RSA");
		keyPairGenerator0.initialize(dSAParameterSpec0, (SecureRandom) null);
		KeyPair keyPair = keyPairGenerator0.generateKeyPair();
		Assertions.hasEnsuredPredicate(keyPair);
		Assertions.mustBeInAcceptingState(keyPairGenerator0);

	}

	@Test
	public void keyPairGeneratorValidTest6() throws NoSuchAlgorithmException {

		KeyPairGenerator keyPairGenerator0 = KeyPairGenerator.getInstance("RSA");
		keyPairGenerator0.initialize(4096);
		KeyPair keyPair = keyPairGenerator0.genKeyPair();
		Assertions.hasEnsuredPredicate(keyPair);
		Assertions.mustBeInAcceptingState(keyPairGenerator0);

	}

	@Test
	public void keyPairGeneratorInvalidTest1() throws NoSuchAlgorithmException {

		KeyPairGenerator keyPairGenerator0 = KeyPairGenerator.getInstance("RSA");
		Assertions.mustNotBeInAcceptingState(keyPairGenerator0);

	}

	@Test
	public void keyPairGeneratorInvalidTest2() throws NoSuchAlgorithmException, NoSuchProviderException {

		KeyPairGenerator keyPairGenerator0 = KeyPairGenerator.getInstance("RSA", (Provider) null);
		Assertions.mustNotBeInAcceptingState(keyPairGenerator0);

	}

	@Test
	public void keyPairGeneratorInvalidTest3() throws NoSuchAlgorithmException {

		KeyPairGenerator keyPairGenerator0 = KeyPairGenerator.getInstance("RSA");
		keyPairGenerator0.initialize(4096);
		Assertions.mustNotBeInAcceptingState(keyPairGenerator0);

	}

	@Test
	public void keyPairGeneratorInvalidTest4() throws NoSuchAlgorithmException, NoSuchProviderException {

		KeyPairGenerator keyPairGenerator0 = KeyPairGenerator.getInstance("RSA", (Provider) null);
		keyPairGenerator0.initialize(4096);
		Assertions.mustNotBeInAcceptingState(keyPairGenerator0);

	}

	@Test
	public void keyPairGeneratorInvalidTest5() throws NoSuchAlgorithmException {

		KeyPairGenerator keyPairGenerator0 = KeyPairGenerator.getInstance("RSA");
		keyPairGenerator0.initialize(4096, (SecureRandom) null);
		Assertions.mustNotBeInAcceptingState(keyPairGenerator0);

	}

	@Test
	public void keyPairGeneratorInvalidTest6() throws NoSuchAlgorithmException, InvalidAlgorithmParameterException {

		BigInteger q = null;

		DSAParameterSpec dSAParameterSpec0 = new DSAParameterSpec(BigInteger.valueOf(1), q, BigInteger.valueOf(1));
		Assertions.hasEnsuredPredicate(dSAParameterSpec0);
		Assertions.mustBeInAcceptingState(dSAParameterSpec0);

		KeyPairGenerator keyPairGenerator0 = KeyPairGenerator.getInstance("RSA");
		keyPairGenerator0.initialize(dSAParameterSpec0);
		Assertions.mustNotBeInAcceptingState(keyPairGenerator0);

	}

	@Test
	public void keyPairGeneratorInvalidTest7() throws NoSuchAlgorithmException, InvalidAlgorithmParameterException {

		BigInteger q = null;

		DSAParameterSpec dSAParameterSpec0 = new DSAParameterSpec(BigInteger.valueOf(1), q, BigInteger.valueOf(2));
		Assertions.hasEnsuredPredicate(dSAParameterSpec0);
		Assertions.mustBeInAcceptingState(dSAParameterSpec0);

		KeyPairGenerator keyPairGenerator0 = KeyPairGenerator.getInstance("RSA");
		keyPairGenerator0.initialize(dSAParameterSpec0, (SecureRandom) null);
		Assertions.mustNotBeInAcceptingState(keyPairGenerator0);

	}

	@Test
	public void keyPairGeneratorInvalidTest8() throws NoSuchAlgorithmException {

		KeyPairGenerator keyPairGenerator0 = KeyPairGenerator.getInstance("RSA");
		KeyPair keyPair = keyPairGenerator0.generateKeyPair();
		Assertions.notHasEnsuredPredicate(keyPair);
		Assertions.mustNotBeInAcceptingState(keyPairGenerator0);

	}

	@Test
	public void keyPairGeneratorInvalidTest9() throws NoSuchAlgorithmException, NoSuchProviderException {

		KeyPairGenerator keyPairGenerator0 = KeyPairGenerator.getInstance("RSA", (Provider) null);
		KeyPair keyPair = keyPairGenerator0.generateKeyPair();
		Assertions.notHasEnsuredPredicate(keyPair);
		Assertions.mustNotBeInAcceptingState(keyPairGenerator0);

	}

	@Test
	public void keyPairGeneratorInvalidTest10() throws NoSuchAlgorithmException {

		KeyPairGenerator keyPairGenerator0 = KeyPairGenerator.getInstance("RSA");
		KeyPair keyPair = keyPairGenerator0.genKeyPair();
		Assertions.notHasEnsuredPredicate(keyPair);
		Assertions.mustNotBeInAcceptingState(keyPairGenerator0);

	}
}