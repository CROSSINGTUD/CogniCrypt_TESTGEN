package jca;

import java.security.SecureRandom;
import test.assertions.Assertions;
import crypto.analysis.CrySLRulesetSelector.Ruleset;
import java.security.NoSuchAlgorithmException;
import org.junit.Test;
import java.lang.String;
import test.UsagePatternTestingFramework;
import java.security.NoSuchProviderException;

public class SecureRandomTest extends UsagePatternTestingFramework {
	protected Ruleset getRuleSet() {
		return Ruleset.JavaCryptographicArchitecture;

	}

	@Test
	public void secureRandomValidTest1() throws NoSuchAlgorithmException {

		SecureRandom secureRandom0 = SecureRandom.getInstance("SHA1PRNG");
		Assertions.hasEnsuredPredicate(secureRandom0);
		Assertions.mustBeInAcceptingState(secureRandom0);

	}

	@Test
	public void secureRandomValidTest2() throws NoSuchAlgorithmException, NoSuchProviderException {

		SecureRandom secureRandom0 = SecureRandom.getInstance("SHA1PRNG", (String) null);
		Assertions.hasEnsuredPredicate(secureRandom0);
		Assertions.mustBeInAcceptingState(secureRandom0);

	}

	@Test
	public void secureRandomValidTest3() throws NoSuchAlgorithmException {

		SecureRandom secureRandom0 = SecureRandom.getInstanceStrong();
		Assertions.hasEnsuredPredicate(secureRandom0);
		Assertions.mustBeInAcceptingState(secureRandom0);

	}

	@Test
	public void secureRandomValidTest4() {

		SecureRandom secureRandom0 = new SecureRandom();
		Assertions.hasEnsuredPredicate(secureRandom0);
		Assertions.mustBeInAcceptingState(secureRandom0);

	}

	@Test
	public void secureRandomValidTest5() throws NoSuchAlgorithmException {

		SecureRandom secureRandom1 = SecureRandom.getInstance("SHA1PRNG");
		byte[] genSeed = secureRandom1.generateSeed(0);
		Assertions.hasEnsuredPredicate(randInt);
		Assertions.mustBeInAcceptingState(secureRandom1);

		SecureRandom secureRandom0 = new SecureRandom(genSeed);
		Assertions.hasEnsuredPredicate(secureRandom0);
		Assertions.mustBeInAcceptingState(secureRandom0);

	}

	@Test
	public void secureRandomValidTest6() throws NoSuchAlgorithmException {

		SecureRandom secureRandom1 = SecureRandom.getInstance("SHA1PRNG");
		byte[] genSeed = secureRandom1.generateSeed(0);
		Assertions.hasEnsuredPredicate(randInt);
		Assertions.mustBeInAcceptingState(secureRandom1);

		SecureRandom secureRandom0 = SecureRandom.getInstance("SHA1PRNG");
		secureRandom0.setSeed(genSeed);
		Assertions.hasEnsuredPredicate(secureRandom0);
		Assertions.mustBeInAcceptingState(secureRandom0);

	}

	@Test
	public void secureRandomValidTest7() throws NoSuchAlgorithmException, NoSuchProviderException {

		SecureRandom secureRandom1 = SecureRandom.getInstance("SHA1PRNG");
		byte[] genSeed = secureRandom1.generateSeed(0);
		Assertions.hasEnsuredPredicate(randInt);
		Assertions.mustBeInAcceptingState(secureRandom1);

		SecureRandom secureRandom0 = SecureRandom.getInstance("SHA1PRNG", (String) null);
		secureRandom0.setSeed(genSeed);
		Assertions.hasEnsuredPredicate(secureRandom0);
		Assertions.mustBeInAcceptingState(secureRandom0);

	}

	@Test
	public void secureRandomValidTest8() throws NoSuchAlgorithmException {

		SecureRandom secureRandom1 = SecureRandom.getInstance("SHA1PRNG");
		byte[] genSeed = secureRandom1.generateSeed(0);
		Assertions.hasEnsuredPredicate(randInt);
		Assertions.mustBeInAcceptingState(secureRandom1);

		SecureRandom secureRandom0 = SecureRandom.getInstanceStrong();
		secureRandom0.setSeed(genSeed);
		Assertions.hasEnsuredPredicate(secureRandom0);
		Assertions.mustBeInAcceptingState(secureRandom0);

	}

	@Test
	public void secureRandomValidTest9() throws NoSuchAlgorithmException {

		SecureRandom secureRandom1 = SecureRandom.getInstance("SHA1PRNG");
		byte[] genSeed = secureRandom1.generateSeed(0);
		Assertions.hasEnsuredPredicate(randInt);
		Assertions.mustBeInAcceptingState(secureRandom1);

		SecureRandom secureRandom0 = new SecureRandom();
		secureRandom0.setSeed(genSeed);
		Assertions.hasEnsuredPredicate(secureRandom0);
		Assertions.mustBeInAcceptingState(secureRandom0);

	}

	@Test
	public void secureRandomValidTest10() throws NoSuchAlgorithmException {

		SecureRandom secureRandom1 = SecureRandom.getInstance("SHA1PRNG");
		byte[] genSeed = secureRandom1.generateSeed(0);
		Assertions.hasEnsuredPredicate(randInt);
		Assertions.mustBeInAcceptingState(secureRandom1);

		SecureRandom secureRandom0 = new SecureRandom(genSeed);
		secureRandom0.setSeed(genSeed);
		Assertions.hasEnsuredPredicate(secureRandom0);
		Assertions.mustBeInAcceptingState(secureRandom0);

	}

	@Test
	public void secureRandomValidTest11() throws NoSuchAlgorithmException {

		long lSeed = 0;

		SecureRandom secureRandom0 = SecureRandom.getInstance("SHA1PRNG");
		secureRandom0.setSeed(lSeed);
		Assertions.hasEnsuredPredicate(secureRandom0);
		Assertions.mustBeInAcceptingState(secureRandom0);

	}

	@Test
	public void secureRandomValidTest12() throws NoSuchAlgorithmException {

		SecureRandom secureRandom0 = SecureRandom.getInstance("SHA1PRNG");
		byte[] genSeed = secureRandom0.generateSeed(0);
		Assertions.hasEnsuredPredicate(randInt);
		Assertions.mustBeInAcceptingState(secureRandom0);

	}

	@Test
	public void secureRandomValidTest13() throws NoSuchAlgorithmException, NoSuchProviderException {

		SecureRandom secureRandom0 = SecureRandom.getInstance("SHA1PRNG", (String) null);
		byte[] genSeed = secureRandom0.generateSeed(0);
		Assertions.hasEnsuredPredicate(randInt);
		Assertions.mustBeInAcceptingState(secureRandom0);

	}

	@Test
	public void secureRandomValidTest14() throws NoSuchAlgorithmException {

		SecureRandom secureRandom0 = SecureRandom.getInstanceStrong();
		byte[] genSeed = secureRandom0.generateSeed(0);
		Assertions.hasEnsuredPredicate(randInt);
		Assertions.mustBeInAcceptingState(secureRandom0);

	}

	@Test
	public void secureRandomValidTest15() {

		SecureRandom secureRandom0 = new SecureRandom();
		byte[] genSeed = secureRandom0.generateSeed(0);
		Assertions.hasEnsuredPredicate(randInt);
		Assertions.mustBeInAcceptingState(secureRandom0);

	}

	@Test
	public void secureRandomValidTest16() throws NoSuchAlgorithmException {

		SecureRandom secureRandom1 = SecureRandom.getInstance("SHA1PRNG");
		byte[] genSeed = secureRandom1.generateSeed(0);
		Assertions.hasEnsuredPredicate(randInt);
		Assertions.mustBeInAcceptingState(secureRandom1);

		SecureRandom secureRandom0 = new SecureRandom(genSeed);
		genSeed = secureRandom0.generateSeed(0);
		Assertions.hasEnsuredPredicate(randInt);
		Assertions.mustBeInAcceptingState(secureRandom0);

	}

	@Test
	public void secureRandomValidTest17() throws NoSuchAlgorithmException {

		byte[] next = null;

		SecureRandom secureRandom0 = SecureRandom.getInstance("SHA1PRNG");
		secureRandom0.nextBytes(next);
		Assertions.hasEnsuredPredicate(randInt);
		Assertions.mustBeInAcceptingState(secureRandom0);

	}

	@Test
	public void secureRandomValidTest18() throws NoSuchAlgorithmException {

		SecureRandom secureRandom0 = SecureRandom.getInstance("SHA1PRNG");
		int randInt = secureRandom0.nextInt();
		Assertions.hasEnsuredPredicate(randInt);
		Assertions.mustBeInAcceptingState(secureRandom0);

	}

	@Test
	public void secureRandomValidTest19() throws NoSuchAlgorithmException {

		SecureRandom secureRandom1 = SecureRandom.getInstance("SHA1PRNG");
		byte[] genSeed = secureRandom1.generateSeed(0);
		Assertions.hasEnsuredPredicate(randInt);
		Assertions.mustBeInAcceptingState(secureRandom1);

		SecureRandom secureRandom0 = SecureRandom.getInstance("SHA1PRNG");
		secureRandom0.setSeed(genSeed);
		genSeed = secureRandom0.generateSeed(0);
		Assertions.hasEnsuredPredicate(randInt);
		Assertions.mustBeInAcceptingState(secureRandom0);

	}

	@Test
	public void secureRandomValidTest20() throws NoSuchAlgorithmException, NoSuchProviderException {

		SecureRandom secureRandom1 = SecureRandom.getInstance("SHA1PRNG");
		byte[] genSeed = secureRandom1.generateSeed(0);
		Assertions.hasEnsuredPredicate(randInt);
		Assertions.mustBeInAcceptingState(secureRandom1);

		SecureRandom secureRandom0 = SecureRandom.getInstance("SHA1PRNG", (String) null);
		secureRandom0.setSeed(genSeed);
		genSeed = secureRandom0.generateSeed(0);
		Assertions.hasEnsuredPredicate(randInt);
		Assertions.mustBeInAcceptingState(secureRandom0);

	}

	@Test
	public void secureRandomValidTest21() throws NoSuchAlgorithmException {

		SecureRandom secureRandom1 = SecureRandom.getInstance("SHA1PRNG");
		byte[] genSeed = secureRandom1.generateSeed(0);
		Assertions.hasEnsuredPredicate(randInt);
		Assertions.mustBeInAcceptingState(secureRandom1);

		SecureRandom secureRandom0 = SecureRandom.getInstanceStrong();
		secureRandom0.setSeed(genSeed);
		genSeed = secureRandom0.generateSeed(0);
		Assertions.hasEnsuredPredicate(randInt);
		Assertions.mustBeInAcceptingState(secureRandom0);

	}

	@Test
	public void secureRandomValidTest22() throws NoSuchAlgorithmException {

		SecureRandom secureRandom1 = SecureRandom.getInstance("SHA1PRNG");
		byte[] genSeed = secureRandom1.generateSeed(0);
		Assertions.hasEnsuredPredicate(randInt);
		Assertions.mustBeInAcceptingState(secureRandom1);

		SecureRandom secureRandom0 = new SecureRandom();
		secureRandom0.setSeed(genSeed);
		genSeed = secureRandom0.generateSeed(0);
		Assertions.hasEnsuredPredicate(randInt);
		Assertions.mustBeInAcceptingState(secureRandom0);

	}

	@Test
	public void secureRandomValidTest23() throws NoSuchAlgorithmException {

		SecureRandom secureRandom1 = SecureRandom.getInstance("SHA1PRNG");
		byte[] genSeed = secureRandom1.generateSeed(0);
		Assertions.hasEnsuredPredicate(randInt);
		Assertions.mustBeInAcceptingState(secureRandom1);

		SecureRandom secureRandom0 = new SecureRandom(genSeed);
		secureRandom0.setSeed(genSeed);
		genSeed = secureRandom0.generateSeed(0);
		Assertions.hasEnsuredPredicate(randInt);
		Assertions.mustBeInAcceptingState(secureRandom0);

	}

	@Test
	public void secureRandomValidTest24() throws NoSuchAlgorithmException {

		long lSeed = 0;

		SecureRandom secureRandom0 = SecureRandom.getInstance("SHA1PRNG");
		secureRandom0.setSeed(lSeed);
		byte[] genSeed = secureRandom0.generateSeed(0);
		Assertions.hasEnsuredPredicate(randInt);
		Assertions.mustBeInAcceptingState(secureRandom0);

	}

	@Test
	public void secureRandomValidTest25() throws NoSuchAlgorithmException {

		SecureRandom secureRandom1 = SecureRandom.getInstance("SHA1PRNG");
		byte[] genSeed = secureRandom1.generateSeed(0);
		Assertions.hasEnsuredPredicate(randInt);
		Assertions.mustBeInAcceptingState(secureRandom1);

		byte[] next = null;

		SecureRandom secureRandom0 = SecureRandom.getInstance("SHA1PRNG");
		secureRandom0.setSeed(genSeed);
		secureRandom0.nextBytes(next);
		Assertions.hasEnsuredPredicate(randInt);
		Assertions.mustBeInAcceptingState(secureRandom0);

	}

	@Test
	public void secureRandomValidTest26() throws NoSuchAlgorithmException {

		SecureRandom secureRandom1 = SecureRandom.getInstance("SHA1PRNG");
		byte[] genSeed = secureRandom1.generateSeed(0);
		Assertions.hasEnsuredPredicate(randInt);
		Assertions.mustBeInAcceptingState(secureRandom1);

		SecureRandom secureRandom0 = SecureRandom.getInstance("SHA1PRNG");
		secureRandom0.setSeed(genSeed);
		int randInt = secureRandom0.nextInt();
		Assertions.hasEnsuredPredicate(randInt);
		Assertions.mustBeInAcceptingState(secureRandom0);

	}

	@Test
	public void secureRandomValidTest27() throws NoSuchAlgorithmException {

		SecureRandom secureRandom1 = SecureRandom.getInstance("SHA1PRNG");
		byte[] genSeed = secureRandom1.generateSeed(0);
		Assertions.hasEnsuredPredicate(randInt);
		Assertions.mustBeInAcceptingState(secureRandom1);

		SecureRandom secureRandom0 = SecureRandom.getInstance("SHA1PRNG");
		secureRandom0.setSeed(genSeed);
		genSeed = secureRandom0.generateSeed(0);
		secureRandom0.setSeed(genSeed);
		Assertions.hasEnsuredPredicate(randInt);
		Assertions.mustBeInAcceptingState(secureRandom0);

	}

	@Test
	public void secureRandomValidTest28() throws NoSuchAlgorithmException, NoSuchProviderException {

		SecureRandom secureRandom1 = SecureRandom.getInstance("SHA1PRNG");
		byte[] genSeed = secureRandom1.generateSeed(0);
		Assertions.hasEnsuredPredicate(randInt);
		Assertions.mustBeInAcceptingState(secureRandom1);

		SecureRandom secureRandom0 = SecureRandom.getInstance("SHA1PRNG", (String) null);
		secureRandom0.setSeed(genSeed);
		genSeed = secureRandom0.generateSeed(0);
		secureRandom0.setSeed(genSeed);
		Assertions.hasEnsuredPredicate(randInt);
		Assertions.mustBeInAcceptingState(secureRandom0);

	}

	@Test
	public void secureRandomValidTest29() throws NoSuchAlgorithmException {

		SecureRandom secureRandom1 = SecureRandom.getInstance("SHA1PRNG");
		byte[] genSeed = secureRandom1.generateSeed(0);
		Assertions.hasEnsuredPredicate(randInt);
		Assertions.mustBeInAcceptingState(secureRandom1);

		SecureRandom secureRandom0 = SecureRandom.getInstanceStrong();
		secureRandom0.setSeed(genSeed);
		genSeed = secureRandom0.generateSeed(0);
		secureRandom0.setSeed(genSeed);
		Assertions.hasEnsuredPredicate(randInt);
		Assertions.mustBeInAcceptingState(secureRandom0);

	}

	@Test
	public void secureRandomValidTest30() throws NoSuchAlgorithmException {

		SecureRandom secureRandom1 = SecureRandom.getInstance("SHA1PRNG");
		byte[] genSeed = secureRandom1.generateSeed(0);
		Assertions.hasEnsuredPredicate(randInt);
		Assertions.mustBeInAcceptingState(secureRandom1);

		SecureRandom secureRandom0 = new SecureRandom();
		secureRandom0.setSeed(genSeed);
		genSeed = secureRandom0.generateSeed(0);
		secureRandom0.setSeed(genSeed);
		Assertions.hasEnsuredPredicate(randInt);
		Assertions.mustBeInAcceptingState(secureRandom0);

	}

	@Test
	public void secureRandomValidTest31() throws NoSuchAlgorithmException {

		SecureRandom secureRandom1 = SecureRandom.getInstance("SHA1PRNG");
		byte[] genSeed = secureRandom1.generateSeed(0);
		Assertions.hasEnsuredPredicate(randInt);
		Assertions.mustBeInAcceptingState(secureRandom1);

		SecureRandom secureRandom0 = new SecureRandom(genSeed);
		secureRandom0.setSeed(genSeed);
		genSeed = secureRandom0.generateSeed(0);
		secureRandom0.setSeed(genSeed);
		Assertions.hasEnsuredPredicate(randInt);
		Assertions.mustBeInAcceptingState(secureRandom0);

	}

	@Test
	public void secureRandomValidTest32() throws NoSuchAlgorithmException {

		long lSeed = 0;

		SecureRandom secureRandom0 = SecureRandom.getInstance("SHA1PRNG");
		secureRandom0.setSeed(lSeed);
		byte[] genSeed = secureRandom0.generateSeed(0);
		secureRandom0.setSeed(lSeed);
		Assertions.hasEnsuredPredicate(randInt);
		Assertions.mustBeInAcceptingState(secureRandom0);

	}

	@Test
	public void secureRandomValidTest33() throws NoSuchAlgorithmException {

		SecureRandom secureRandom1 = SecureRandom.getInstance("SHA1PRNG");
		byte[] genSeed = secureRandom1.generateSeed(0);
		Assertions.hasEnsuredPredicate(randInt);
		Assertions.mustBeInAcceptingState(secureRandom1);

		byte[] next = null;

		SecureRandom secureRandom0 = SecureRandom.getInstance("SHA1PRNG");
		secureRandom0.setSeed(genSeed);
		secureRandom0.nextBytes(next);
		secureRandom0.setSeed(genSeed);
		Assertions.hasEnsuredPredicate(randInt);
		Assertions.mustBeInAcceptingState(secureRandom0);

	}

	@Test
	public void secureRandomValidTest34() throws NoSuchAlgorithmException {

		SecureRandom secureRandom1 = SecureRandom.getInstance("SHA1PRNG");
		byte[] genSeed = secureRandom1.generateSeed(0);
		Assertions.hasEnsuredPredicate(randInt);
		Assertions.mustBeInAcceptingState(secureRandom1);

		SecureRandom secureRandom0 = SecureRandom.getInstance("SHA1PRNG");
		secureRandom0.setSeed(genSeed);
		int randInt = secureRandom0.nextInt();
		secureRandom0.setSeed(genSeed);
		Assertions.hasEnsuredPredicate(randInt);
		Assertions.mustBeInAcceptingState(secureRandom0);

	}

	@Test
	public void secureRandomValidTest35() throws NoSuchAlgorithmException {

		long lSeed = 0;

		SecureRandom secureRandom0 = SecureRandom.getInstance("SHA1PRNG");
		secureRandom0.setSeed(lSeed);
		byte[] genSeed = secureRandom0.generateSeed(0);
		secureRandom0.setSeed(lSeed);
		Assertions.hasEnsuredPredicate(randInt);
		Assertions.mustBeInAcceptingState(secureRandom0);

	}

	@Test
	public void secureRandomInvalidTest1() throws NoSuchAlgorithmException {

		SecureRandom secureRandom1 = SecureRandom.getInstance("SHA1PRNG");
		byte[] genSeed = secureRandom1.generateSeed(0);
		Assertions.hasEnsuredPredicate(randInt);
		Assertions.mustBeInAcceptingState(secureRandom1);

		SecureRandom secureRandom0 = SecureRandom.getInstance("SHA1PRNG");
		genSeed = secureRandom0.generateSeed(0);
		secureRandom0.setSeed(genSeed);
		Assertions.notHasEnsuredPredicate(randInt);
		Assertions.mustNotBeInAcceptingState(secureRandom0);

	}

	@Test
	public void secureRandomInvalidTest2() throws NoSuchAlgorithmException, NoSuchProviderException {

		SecureRandom secureRandom1 = SecureRandom.getInstance("SHA1PRNG");
		byte[] genSeed = secureRandom1.generateSeed(0);
		Assertions.hasEnsuredPredicate(randInt);
		Assertions.mustBeInAcceptingState(secureRandom1);

		SecureRandom secureRandom0 = SecureRandom.getInstance("SHA1PRNG", (String) null);
		genSeed = secureRandom0.generateSeed(0);
		secureRandom0.setSeed(genSeed);
		Assertions.notHasEnsuredPredicate(randInt);
		Assertions.mustNotBeInAcceptingState(secureRandom0);

	}

	@Test
	public void secureRandomInvalidTest3() throws NoSuchAlgorithmException {

		SecureRandom secureRandom1 = SecureRandom.getInstance("SHA1PRNG");
		byte[] genSeed = secureRandom1.generateSeed(0);
		Assertions.hasEnsuredPredicate(randInt);
		Assertions.mustBeInAcceptingState(secureRandom1);

		SecureRandom secureRandom0 = SecureRandom.getInstanceStrong();
		genSeed = secureRandom0.generateSeed(0);
		secureRandom0.setSeed(genSeed);
		Assertions.notHasEnsuredPredicate(randInt);
		Assertions.mustNotBeInAcceptingState(secureRandom0);

	}

	@Test
	public void secureRandomInvalidTest4() throws NoSuchAlgorithmException {

		SecureRandom secureRandom1 = SecureRandom.getInstance("SHA1PRNG");
		byte[] genSeed = secureRandom1.generateSeed(0);
		Assertions.hasEnsuredPredicate(randInt);
		Assertions.mustBeInAcceptingState(secureRandom1);

		SecureRandom secureRandom0 = new SecureRandom();
		genSeed = secureRandom0.generateSeed(0);
		secureRandom0.setSeed(genSeed);
		Assertions.notHasEnsuredPredicate(randInt);
		Assertions.mustNotBeInAcceptingState(secureRandom0);

	}

	@Test
	public void secureRandomInvalidTest5() throws NoSuchAlgorithmException {

		SecureRandom secureRandom1 = SecureRandom.getInstance("SHA1PRNG");
		byte[] genSeed = secureRandom1.generateSeed(0);
		Assertions.hasEnsuredPredicate(randInt);
		Assertions.mustBeInAcceptingState(secureRandom1);

		SecureRandom secureRandom0 = new SecureRandom(genSeed);
		genSeed = secureRandom0.generateSeed(0);
		secureRandom0.setSeed(genSeed);
		Assertions.notHasEnsuredPredicate(randInt);
		Assertions.mustNotBeInAcceptingState(secureRandom0);

	}

	@Test
	public void secureRandomInvalidTest6() throws NoSuchAlgorithmException {

		SecureRandom secureRandom1 = SecureRandom.getInstance("SHA1PRNG");
		byte[] genSeed = secureRandom1.generateSeed(0);
		Assertions.hasEnsuredPredicate(randInt);
		Assertions.mustBeInAcceptingState(secureRandom1);

		byte[] next = null;

		SecureRandom secureRandom0 = SecureRandom.getInstance("SHA1PRNG");
		secureRandom0.nextBytes(next);
		secureRandom0.setSeed(genSeed);
		Assertions.notHasEnsuredPredicate(randInt);
		Assertions.mustNotBeInAcceptingState(secureRandom0);

	}

	@Test
	public void secureRandomInvalidTest7() throws NoSuchAlgorithmException {

		SecureRandom secureRandom1 = SecureRandom.getInstance("SHA1PRNG");
		byte[] genSeed = secureRandom1.generateSeed(0);
		Assertions.hasEnsuredPredicate(randInt);
		Assertions.mustBeInAcceptingState(secureRandom1);

		SecureRandom secureRandom0 = SecureRandom.getInstance("SHA1PRNG");
		int randInt = secureRandom0.nextInt();
		secureRandom0.setSeed(genSeed);
		Assertions.notHasEnsuredPredicate(randInt);
		Assertions.mustNotBeInAcceptingState(secureRandom0);

	}

	@Test
	public void secureRandomInvalidTest8() throws NoSuchAlgorithmException {

		long lSeed = 0;

		SecureRandom secureRandom0 = SecureRandom.getInstance("SHA1PRNG");
		byte[] genSeed = secureRandom0.generateSeed(0);
		secureRandom0.setSeed(lSeed);
		Assertions.notHasEnsuredPredicate(randInt);
		Assertions.mustNotBeInAcceptingState(secureRandom0);

	}

	@Test
	public void secureRandomInvalidTest9() throws NoSuchAlgorithmException {

		SecureRandom secureRandom1 = SecureRandom.getInstance("SHA1PRNG");
		byte[] genSeed = secureRandom1.generateSeed(0);
		Assertions.hasEnsuredPredicate(randInt);
		Assertions.mustBeInAcceptingState(secureRandom1);

		SecureRandom secureRandom0 = SecureRandom.getInstance("SHA1PRNG");
		secureRandom0.setSeed(genSeed);
		secureRandom0.setSeed(genSeed);
		Assertions.hasEnsuredPredicate(secureRandom0);
		Assertions.mustNotBeInAcceptingState(secureRandom0);

	}

	@Test
	public void secureRandomInvalidTest10() throws NoSuchAlgorithmException, NoSuchProviderException {

		SecureRandom secureRandom1 = SecureRandom.getInstance("SHA1PRNG");
		byte[] genSeed = secureRandom1.generateSeed(0);
		Assertions.hasEnsuredPredicate(randInt);
		Assertions.mustBeInAcceptingState(secureRandom1);

		SecureRandom secureRandom0 = SecureRandom.getInstance("SHA1PRNG", (String) null);
		secureRandom0.setSeed(genSeed);
		secureRandom0.setSeed(genSeed);
		Assertions.hasEnsuredPredicate(secureRandom0);
		Assertions.mustNotBeInAcceptingState(secureRandom0);

	}

	@Test
	public void secureRandomInvalidTest11() throws NoSuchAlgorithmException {

		SecureRandom secureRandom1 = SecureRandom.getInstance("SHA1PRNG");
		byte[] genSeed = secureRandom1.generateSeed(0);
		Assertions.hasEnsuredPredicate(randInt);
		Assertions.mustBeInAcceptingState(secureRandom1);

		SecureRandom secureRandom0 = SecureRandom.getInstanceStrong();
		secureRandom0.setSeed(genSeed);
		secureRandom0.setSeed(genSeed);
		Assertions.hasEnsuredPredicate(secureRandom0);
		Assertions.mustNotBeInAcceptingState(secureRandom0);

	}

	@Test
	public void secureRandomInvalidTest12() throws NoSuchAlgorithmException {

		SecureRandom secureRandom1 = SecureRandom.getInstance("SHA1PRNG");
		byte[] genSeed = secureRandom1.generateSeed(0);
		Assertions.hasEnsuredPredicate(randInt);
		Assertions.mustBeInAcceptingState(secureRandom1);

		SecureRandom secureRandom0 = new SecureRandom();
		secureRandom0.setSeed(genSeed);
		secureRandom0.setSeed(genSeed);
		Assertions.hasEnsuredPredicate(secureRandom0);
		Assertions.mustNotBeInAcceptingState(secureRandom0);

	}

	@Test
	public void secureRandomInvalidTest13() throws NoSuchAlgorithmException {

		SecureRandom secureRandom1 = SecureRandom.getInstance("SHA1PRNG");
		byte[] genSeed = secureRandom1.generateSeed(0);
		Assertions.hasEnsuredPredicate(randInt);
		Assertions.mustBeInAcceptingState(secureRandom1);

		SecureRandom secureRandom0 = new SecureRandom(genSeed);
		secureRandom0.setSeed(genSeed);
		secureRandom0.setSeed(genSeed);
		Assertions.hasEnsuredPredicate(secureRandom0);
		Assertions.mustNotBeInAcceptingState(secureRandom0);

	}

	@Test
	public void secureRandomInvalidTest14() throws NoSuchAlgorithmException {

		long lSeed = 0;

		SecureRandom secureRandom0 = SecureRandom.getInstance("SHA1PRNG");
		secureRandom0.setSeed(lSeed);
		secureRandom0.setSeed(lSeed);
		Assertions.hasEnsuredPredicate(secureRandom0);
		Assertions.mustNotBeInAcceptingState(secureRandom0);

	}

	@Test
	public void secureRandomInvalidTest15() throws NoSuchAlgorithmException {

		long lSeed = 0;

		SecureRandom secureRandom0 = SecureRandom.getInstance("SHA1PRNG");
		secureRandom0.setSeed(lSeed);
		secureRandom0.setSeed(lSeed);
		Assertions.hasEnsuredPredicate(secureRandom0);
		Assertions.mustNotBeInAcceptingState(secureRandom0);

	}
}