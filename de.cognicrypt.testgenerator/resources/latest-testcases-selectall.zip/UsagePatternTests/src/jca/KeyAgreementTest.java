package jca;

import java.lang.IllegalStateException;
import test.assertions.Assertions;
import crypto.analysis.CrySLRulesetSelector.Ruleset;
import org.junit.Test;
import java.security.InvalidAlgorithmParameterException;
import java.security.Key;
import java.security.SecureRandom;
import javax.crypto.KeyAgreement;
import java.security.NoSuchAlgorithmException;
import java.security.InvalidKeyException;
import java.lang.String;
import java.security.spec.AlgorithmParameterSpec;
import test.UsagePatternTestingFramework;
import java.security.NoSuchProviderException;
import javax.crypto.ShortBufferException;

public class KeyAgreementTest extends UsagePatternTestingFramework {
	protected Ruleset getRuleSet() {
		return Ruleset.JavaCryptographicArchitecture;

	}

	@Test
	public void keyAgreementValidTest1() throws IllegalStateException, NoSuchAlgorithmException, InvalidKeyException {

		boolean lastPhase = false;
		Key key = null;

		KeyAgreement keyAgreement0 = KeyAgreement.getInstance("DH");
		keyAgreement0.init(key);
		keyAgreement0.doPhase(key, lastPhase);
		keyAgreement0.generateSecret();
		Assertions.hasEnsuredPredicate(key);
		Assertions.mustBeInAcceptingState(keyAgreement0);

	}

	@Test
	public void keyAgreementValidTest2()
			throws IllegalStateException, NoSuchAlgorithmException, InvalidKeyException, NoSuchProviderException {

		boolean lastPhase = false;
		Key key = null;

		KeyAgreement keyAgreement0 = KeyAgreement.getInstance("DH", (String) null);
		keyAgreement0.init(key);
		keyAgreement0.doPhase(key, lastPhase);
		keyAgreement0.generateSecret();
		Assertions.hasEnsuredPredicate(key);
		Assertions.mustBeInAcceptingState(keyAgreement0);

	}

	@Test
	public void keyAgreementValidTest3() throws IllegalStateException, NoSuchAlgorithmException, InvalidKeyException,
			InvalidAlgorithmParameterException {

		boolean lastPhase = false;
		AlgorithmParameterSpec params = null;
		Key key = null;

		KeyAgreement keyAgreement0 = KeyAgreement.getInstance("DH");
		keyAgreement0.init(key, params);
		keyAgreement0.doPhase(key, lastPhase);
		keyAgreement0.generateSecret();
		Assertions.hasEnsuredPredicate(key);
		Assertions.mustBeInAcceptingState(keyAgreement0);

	}

	@Test
	public void keyAgreementValidTest4() throws IllegalStateException, NoSuchAlgorithmException, InvalidKeyException,
			InvalidAlgorithmParameterException {

		SecureRandom secureRandom0 = SecureRandom.getInstance("SHA1PRNG");
		Assertions.hasEnsuredPredicate(secureRandom0);
		Assertions.mustBeInAcceptingState(secureRandom0);

		boolean lastPhase = false;
		AlgorithmParameterSpec params = null;
		Key key = null;

		KeyAgreement keyAgreement0 = KeyAgreement.getInstance("DH");
		keyAgreement0.init(key, params, secureRandom0);
		keyAgreement0.doPhase(key, lastPhase);
		keyAgreement0.generateSecret();
		Assertions.hasEnsuredPredicate(key);
		Assertions.mustBeInAcceptingState(keyAgreement0);

	}

	@Test
	public void keyAgreementValidTest5() throws IllegalStateException, NoSuchAlgorithmException, InvalidKeyException {

		SecureRandom secureRandom0 = SecureRandom.getInstance("SHA1PRNG");
		Assertions.hasEnsuredPredicate(secureRandom0);
		Assertions.mustBeInAcceptingState(secureRandom0);

		boolean lastPhase = false;
		Key key = null;

		KeyAgreement keyAgreement0 = KeyAgreement.getInstance("DH");
		keyAgreement0.init(key, secureRandom0);
		keyAgreement0.doPhase(key, lastPhase);
		keyAgreement0.generateSecret();
		Assertions.hasEnsuredPredicate(key);
		Assertions.mustBeInAcceptingState(keyAgreement0);

	}

	@Test
	public void keyAgreementValidTest6()
			throws IllegalStateException, NoSuchAlgorithmException, InvalidKeyException, ShortBufferException {

		boolean lastPhase = false;
		int offset = 0;
		byte[] sharedSecret = null;
		Key key = null;

		KeyAgreement keyAgreement0 = KeyAgreement.getInstance("DH");
		keyAgreement0.init(key);
		keyAgreement0.doPhase(key, lastPhase);
		keyAgreement0.generateSecret(sharedSecret, offset);
		Assertions.hasEnsuredPredicate(key);
		Assertions.mustBeInAcceptingState(keyAgreement0);

	}

	@Test
	public void keyAgreementValidTest7() throws IllegalStateException, NoSuchAlgorithmException, InvalidKeyException {

		boolean lastPhase = false;
		Key key = null;

		KeyAgreement keyAgreement0 = KeyAgreement.getInstance("DH");
		keyAgreement0.init(key);
		keyAgreement0.doPhase(key, lastPhase);
		keyAgreement0.generateSecret("DH");
		Assertions.hasEnsuredPredicate(key);
		Assertions.mustBeInAcceptingState(keyAgreement0);

	}

	@Test
	public void keyAgreementInvalidTest1() throws NoSuchAlgorithmException {

		KeyAgreement keyAgreement0 = KeyAgreement.getInstance("DH");
		Assertions.mustNotBeInAcceptingState(keyAgreement0);

	}

	@Test
	public void keyAgreementInvalidTest2() throws NoSuchAlgorithmException, NoSuchProviderException {

		KeyAgreement keyAgreement0 = KeyAgreement.getInstance("DH", (String) null);
		Assertions.mustNotBeInAcceptingState(keyAgreement0);

	}

	@Test
	public void keyAgreementInvalidTest3() throws NoSuchAlgorithmException, InvalidKeyException {

		Key key = null;

		KeyAgreement keyAgreement0 = KeyAgreement.getInstance("DH");
		keyAgreement0.init(key);
		Assertions.notHasEnsuredPredicate(key);
		Assertions.mustNotBeInAcceptingState(keyAgreement0);

	}

	@Test
	public void keyAgreementInvalidTest4()
			throws NoSuchAlgorithmException, InvalidKeyException, NoSuchProviderException {

		Key key = null;

		KeyAgreement keyAgreement0 = KeyAgreement.getInstance("DH", (String) null);
		keyAgreement0.init(key);
		Assertions.notHasEnsuredPredicate(key);
		Assertions.mustNotBeInAcceptingState(keyAgreement0);

	}

	@Test
	public void keyAgreementInvalidTest5()
			throws NoSuchAlgorithmException, InvalidKeyException, InvalidAlgorithmParameterException {

		AlgorithmParameterSpec params = null;
		Key key = null;

		KeyAgreement keyAgreement0 = KeyAgreement.getInstance("DH");
		keyAgreement0.init(key, params);
		Assertions.notHasEnsuredPredicate(key);
		Assertions.mustNotBeInAcceptingState(keyAgreement0);

	}

	@Test
	public void keyAgreementInvalidTest6()
			throws NoSuchAlgorithmException, InvalidKeyException, InvalidAlgorithmParameterException {

		SecureRandom secureRandom0 = SecureRandom.getInstance("SHA1PRNG");
		Assertions.hasEnsuredPredicate(secureRandom0);
		Assertions.mustBeInAcceptingState(secureRandom0);

		AlgorithmParameterSpec params = null;
		Key key = null;

		KeyAgreement keyAgreement0 = KeyAgreement.getInstance("DH");
		keyAgreement0.init(key, params, secureRandom0);
		Assertions.notHasEnsuredPredicate(key);
		Assertions.mustNotBeInAcceptingState(keyAgreement0);

	}

	@Test
	public void keyAgreementInvalidTest7() throws NoSuchAlgorithmException, InvalidKeyException {

		SecureRandom secureRandom0 = SecureRandom.getInstance("SHA1PRNG");
		Assertions.hasEnsuredPredicate(secureRandom0);
		Assertions.mustBeInAcceptingState(secureRandom0);

		Key key = null;

		KeyAgreement keyAgreement0 = KeyAgreement.getInstance("DH");
		keyAgreement0.init(key, secureRandom0);
		Assertions.notHasEnsuredPredicate(key);
		Assertions.mustNotBeInAcceptingState(keyAgreement0);

	}

	@Test
	public void keyAgreementInvalidTest8() throws IllegalStateException, NoSuchAlgorithmException, InvalidKeyException {

		boolean lastPhase = false;
		Key key = null;

		KeyAgreement keyAgreement0 = KeyAgreement.getInstance("DH");
		keyAgreement0.init(key);
		keyAgreement0.doPhase(key, lastPhase);
		Assertions.notHasEnsuredPredicate(key);
		Assertions.mustNotBeInAcceptingState(keyAgreement0);

	}

	@Test
	public void keyAgreementInvalidTest9()
			throws IllegalStateException, NoSuchAlgorithmException, InvalidKeyException, NoSuchProviderException {

		boolean lastPhase = false;
		Key key = null;

		KeyAgreement keyAgreement0 = KeyAgreement.getInstance("DH", (String) null);
		keyAgreement0.init(key);
		keyAgreement0.doPhase(key, lastPhase);
		Assertions.notHasEnsuredPredicate(key);
		Assertions.mustNotBeInAcceptingState(keyAgreement0);

	}

	@Test
	public void keyAgreementInvalidTest10() throws IllegalStateException, NoSuchAlgorithmException, InvalidKeyException,
			InvalidAlgorithmParameterException {

		boolean lastPhase = false;
		AlgorithmParameterSpec params = null;
		Key key = null;

		KeyAgreement keyAgreement0 = KeyAgreement.getInstance("DH");
		keyAgreement0.init(key, params);
		keyAgreement0.doPhase(key, lastPhase);
		Assertions.notHasEnsuredPredicate(key);
		Assertions.mustNotBeInAcceptingState(keyAgreement0);

	}

	@Test
	public void keyAgreementInvalidTest11() throws IllegalStateException, NoSuchAlgorithmException, InvalidKeyException,
			InvalidAlgorithmParameterException {

		SecureRandom secureRandom0 = SecureRandom.getInstance("SHA1PRNG");
		Assertions.hasEnsuredPredicate(secureRandom0);
		Assertions.mustBeInAcceptingState(secureRandom0);

		boolean lastPhase = false;
		AlgorithmParameterSpec params = null;
		Key key = null;

		KeyAgreement keyAgreement0 = KeyAgreement.getInstance("DH");
		keyAgreement0.init(key, params, secureRandom0);
		keyAgreement0.doPhase(key, lastPhase);
		Assertions.notHasEnsuredPredicate(key);
		Assertions.mustNotBeInAcceptingState(keyAgreement0);

	}

	@Test
	public void keyAgreementInvalidTest12()
			throws IllegalStateException, NoSuchAlgorithmException, InvalidKeyException {

		SecureRandom secureRandom0 = SecureRandom.getInstance("SHA1PRNG");
		Assertions.hasEnsuredPredicate(secureRandom0);
		Assertions.mustBeInAcceptingState(secureRandom0);

		boolean lastPhase = false;
		Key key = null;

		KeyAgreement keyAgreement0 = KeyAgreement.getInstance("DH");
		keyAgreement0.init(key, secureRandom0);
		keyAgreement0.doPhase(key, lastPhase);
		Assertions.notHasEnsuredPredicate(key);
		Assertions.mustNotBeInAcceptingState(keyAgreement0);

	}

	@Test
	public void keyAgreementInvalidTest13()
			throws IllegalStateException, NoSuchAlgorithmException, InvalidKeyException {

		boolean lastPhase = false;
		Key key = null;

		KeyAgreement keyAgreement0 = KeyAgreement.getInstance("DH");
		keyAgreement0.doPhase(key, lastPhase);
		keyAgreement0.generateSecret();
		Assertions.notHasEnsuredPredicate(key);
		Assertions.mustNotBeInAcceptingState(keyAgreement0);

	}

	@Test
	public void keyAgreementInvalidTest14()
			throws IllegalStateException, NoSuchAlgorithmException, InvalidKeyException, NoSuchProviderException {

		boolean lastPhase = false;
		Key key = null;

		KeyAgreement keyAgreement0 = KeyAgreement.getInstance("DH", (String) null);
		keyAgreement0.doPhase(key, lastPhase);
		keyAgreement0.generateSecret();
		Assertions.notHasEnsuredPredicate(key);
		Assertions.mustNotBeInAcceptingState(keyAgreement0);

	}

	@Test
	public void keyAgreementInvalidTest15()
			throws IllegalStateException, NoSuchAlgorithmException, InvalidKeyException, ShortBufferException {

		boolean lastPhase = false;
		int offset = 0;
		byte[] sharedSecret = null;
		Key key = null;

		KeyAgreement keyAgreement0 = KeyAgreement.getInstance("DH");
		keyAgreement0.doPhase(key, lastPhase);
		keyAgreement0.generateSecret(sharedSecret, offset);
		Assertions.notHasEnsuredPredicate(key);
		Assertions.mustNotBeInAcceptingState(keyAgreement0);

	}

	@Test
	public void keyAgreementInvalidTest16()
			throws IllegalStateException, NoSuchAlgorithmException, InvalidKeyException {

		boolean lastPhase = false;
		Key key = null;

		KeyAgreement keyAgreement0 = KeyAgreement.getInstance("DH");
		keyAgreement0.doPhase(key, lastPhase);
		keyAgreement0.generateSecret("DH");
		Assertions.notHasEnsuredPredicate(key);
		Assertions.mustNotBeInAcceptingState(keyAgreement0);

	}

	@Test
	public void keyAgreementInvalidTest17()
			throws IllegalStateException, NoSuchAlgorithmException, InvalidKeyException {

		Key key = null;

		KeyAgreement keyAgreement0 = KeyAgreement.getInstance("DH");
		keyAgreement0.init(key);
		keyAgreement0.generateSecret();
		Assertions.notHasEnsuredPredicate(key);
		Assertions.mustNotBeInAcceptingState(keyAgreement0);

	}

	@Test
	public void keyAgreementInvalidTest18()
			throws IllegalStateException, NoSuchAlgorithmException, InvalidKeyException, NoSuchProviderException {

		Key key = null;

		KeyAgreement keyAgreement0 = KeyAgreement.getInstance("DH", (String) null);
		keyAgreement0.init(key);
		keyAgreement0.generateSecret();
		Assertions.notHasEnsuredPredicate(key);
		Assertions.mustNotBeInAcceptingState(keyAgreement0);

	}

	@Test
	public void keyAgreementInvalidTest19() throws IllegalStateException, NoSuchAlgorithmException, InvalidKeyException,
			InvalidAlgorithmParameterException {

		AlgorithmParameterSpec params = null;
		Key key = null;

		KeyAgreement keyAgreement0 = KeyAgreement.getInstance("DH");
		keyAgreement0.init(key, params);
		keyAgreement0.generateSecret();
		Assertions.notHasEnsuredPredicate(key);
		Assertions.mustNotBeInAcceptingState(keyAgreement0);

	}

	@Test
	public void keyAgreementInvalidTest20() throws IllegalStateException, NoSuchAlgorithmException, InvalidKeyException,
			InvalidAlgorithmParameterException {

		SecureRandom secureRandom0 = SecureRandom.getInstance("SHA1PRNG");
		Assertions.hasEnsuredPredicate(secureRandom0);
		Assertions.mustBeInAcceptingState(secureRandom0);

		AlgorithmParameterSpec params = null;
		Key key = null;

		KeyAgreement keyAgreement0 = KeyAgreement.getInstance("DH");
		keyAgreement0.init(key, params, secureRandom0);
		keyAgreement0.generateSecret();
		Assertions.notHasEnsuredPredicate(key);
		Assertions.mustNotBeInAcceptingState(keyAgreement0);

	}

	@Test
	public void keyAgreementInvalidTest21()
			throws IllegalStateException, NoSuchAlgorithmException, InvalidKeyException {

		SecureRandom secureRandom0 = SecureRandom.getInstance("SHA1PRNG");
		Assertions.hasEnsuredPredicate(secureRandom0);
		Assertions.mustBeInAcceptingState(secureRandom0);

		Key key = null;

		KeyAgreement keyAgreement0 = KeyAgreement.getInstance("DH");
		keyAgreement0.init(key, secureRandom0);
		keyAgreement0.generateSecret();
		Assertions.notHasEnsuredPredicate(key);
		Assertions.mustNotBeInAcceptingState(keyAgreement0);

	}

	@Test
	public void keyAgreementInvalidTest22()
			throws IllegalStateException, NoSuchAlgorithmException, InvalidKeyException, ShortBufferException {

		int offset = 0;
		byte[] sharedSecret = null;
		Key key = null;

		KeyAgreement keyAgreement0 = KeyAgreement.getInstance("DH");
		keyAgreement0.init(key);
		keyAgreement0.generateSecret(sharedSecret, offset);
		Assertions.notHasEnsuredPredicate(key);
		Assertions.mustNotBeInAcceptingState(keyAgreement0);

	}

	@Test
	public void keyAgreementInvalidTest23()
			throws IllegalStateException, NoSuchAlgorithmException, InvalidKeyException {

		Key key = null;

		KeyAgreement keyAgreement0 = KeyAgreement.getInstance("DH");
		keyAgreement0.init(key);
		keyAgreement0.generateSecret("DH");
		Assertions.notHasEnsuredPredicate(key);
		Assertions.mustNotBeInAcceptingState(keyAgreement0);

	}
}