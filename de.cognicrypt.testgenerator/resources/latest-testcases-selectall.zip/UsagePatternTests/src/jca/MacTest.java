package jca;

import java.lang.IllegalStateException;
import test.assertions.Assertions;
import crypto.analysis.CrySLRulesetSelector.Ruleset;
import java.security.spec.InvalidKeySpecException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.Mac;
import org.junit.Test;
import javax.crypto.Cipher;
import java.security.Provider;
import java.security.InvalidAlgorithmParameterException;
import java.security.SecureRandom;
import javax.crypto.SecretKeyFactory;
import javax.crypto.BadPaddingException;
import java.security.cert.Certificate;
import javax.xml.crypto.dsig.spec.HMACParameterSpec;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.PBEKeySpec;
import java.security.NoSuchAlgorithmException;
import java.security.InvalidKeyException;
import javax.crypto.SecretKey;
import test.UsagePatternTestingFramework;
import java.security.NoSuchProviderException;
import javax.crypto.ShortBufferException;

public class MacTest extends UsagePatternTestingFramework {
	protected Ruleset getRuleSet() {
		return Ruleset.JavaCryptographicArchitecture;

	}

	@Test
	public void macValidTest1()
			throws IllegalStateException, InvalidKeySpecException, NoSuchAlgorithmException, InvalidKeyException {

		SecureRandom secureRandom0 = SecureRandom.getInstance("SHA1PRNG");
		byte[] genSeed = secureRandom0.generateSeed(0);
		Assertions.hasEnsuredPredicate(randInt);
		Assertions.mustBeInAcceptingState(secureRandom0);

		int keylength = 0;
		char[] password = null;

		PBEKeySpec pBEKeySpec0 = new PBEKeySpec(password, genSeed, 11386, keylength);
		Assertions.hasEnsuredPredicate(pBEKeySpec0);

		SecretKeyFactory secretKeyFactory0 = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA512");
		SecretKey secretKey = secretKeyFactory0.generateSecret(pBEKeySpec0);
		Assertions.hasEnsuredPredicate(secretKey);
		Assertions.mustBeInAcceptingState(secretKeyFactory0);

		Mac mac0 = Mac.getInstance("HmacMD5");
		mac0.init(secretKey);
		byte[] output1 = mac0.doFinal();
		Assertions.hasEnsuredPredicate(output1);
		Assertions.mustBeInAcceptingState(mac0);
		pBEKeySpec0.clearPassword();
		Assertions.mustBeInAcceptingState(pBEKeySpec0);

	}

	@Test
	public void macValidTest2() throws IllegalStateException, InvalidKeySpecException, NoSuchAlgorithmException,
			InvalidKeyException, NoSuchProviderException {

		SecureRandom secureRandom0 = SecureRandom.getInstance("SHA1PRNG");
		byte[] genSeed = secureRandom0.generateSeed(0);
		Assertions.hasEnsuredPredicate(randInt);
		Assertions.mustBeInAcceptingState(secureRandom0);

		int keylength = 0;
		char[] password = null;

		PBEKeySpec pBEKeySpec0 = new PBEKeySpec(password, genSeed, 24062, keylength);
		Assertions.hasEnsuredPredicate(pBEKeySpec0);

		SecretKeyFactory secretKeyFactory0 = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA512");
		SecretKey secretKey = secretKeyFactory0.generateSecret(pBEKeySpec0);
		Assertions.hasEnsuredPredicate(secretKey);
		Assertions.mustBeInAcceptingState(secretKeyFactory0);

		Mac mac0 = Mac.getInstance("HmacMD5", (Provider) null);
		mac0.init(secretKey);
		byte[] output1 = mac0.doFinal();
		Assertions.hasEnsuredPredicate(output1);
		Assertions.mustBeInAcceptingState(mac0);
		pBEKeySpec0.clearPassword();
		Assertions.mustBeInAcceptingState(pBEKeySpec0);

	}

	@Test
	public void macValidTest3() throws IllegalStateException, InvalidKeySpecException, NoSuchAlgorithmException,
			InvalidKeyException, InvalidAlgorithmParameterException {

		SecureRandom secureRandom0 = SecureRandom.getInstance("SHA1PRNG");
		byte[] genSeed = secureRandom0.generateSeed(0);
		Assertions.hasEnsuredPredicate(randInt);
		Assertions.mustBeInAcceptingState(secureRandom0);

		int keylength = 0;
		char[] password = null;

		PBEKeySpec pBEKeySpec0 = new PBEKeySpec(password, genSeed, 15075, keylength);
		Assertions.hasEnsuredPredicate(pBEKeySpec0);

		SecretKeyFactory secretKeyFactory0 = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA512");
		SecretKey secretKey = secretKeyFactory0.generateSecret(pBEKeySpec0);
		Assertions.hasEnsuredPredicate(secretKey);
		Assertions.mustBeInAcceptingState(secretKeyFactory0);

		int outputLength = 0;

		HMACParameterSpec hMACParameterSpec0 = new HMACParameterSpec(outputLength);
		Assertions.hasEnsuredPredicate(hMACParameterSpec0);
		Assertions.mustBeInAcceptingState(hMACParameterSpec0);

		Mac mac0 = Mac.getInstance("HmacMD5");
		mac0.init(secretKey, hMACParameterSpec0);
		byte[] output1 = mac0.doFinal();
		Assertions.hasEnsuredPredicate(output1);
		Assertions.mustBeInAcceptingState(mac0);
		pBEKeySpec0.clearPassword();
		Assertions.mustBeInAcceptingState(pBEKeySpec0);

	}

	@Test
	public void macValidTest4() throws IllegalStateException, InvalidKeySpecException, NoSuchAlgorithmException,
			InvalidKeyException, ShortBufferException {

		SecureRandom secureRandom0 = SecureRandom.getInstance("SHA1PRNG");
		byte[] genSeed = secureRandom0.generateSeed(0);
		Assertions.hasEnsuredPredicate(randInt);
		Assertions.mustBeInAcceptingState(secureRandom0);

		int keylength = 0;
		char[] password = null;

		PBEKeySpec pBEKeySpec0 = new PBEKeySpec(password, genSeed, 20662, keylength);
		Assertions.hasEnsuredPredicate(pBEKeySpec0);

		SecretKeyFactory secretKeyFactory0 = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA512");
		SecretKey secretKey = secretKeyFactory0.generateSecret(pBEKeySpec0);
		Assertions.hasEnsuredPredicate(secretKey);
		Assertions.mustBeInAcceptingState(secretKeyFactory0);

		int outOffset = 0;

		Mac mac0 = Mac.getInstance("HmacMD5");
		mac0.init(secretKey);
		mac0.doFinal(genSeed, outOffset);
		Assertions.hasEnsuredPredicate(output1);
		Assertions.mustBeInAcceptingState(mac0);
		pBEKeySpec0.clearPassword();
		Assertions.mustBeInAcceptingState(pBEKeySpec0);

	}

	@Test
	public void macValidTest5()
			throws IllegalStateException, InvalidKeySpecException, NoSuchAlgorithmException, InvalidKeyException {

		SecureRandom secureRandom0 = SecureRandom.getInstance("SHA1PRNG");
		byte[] genSeed = secureRandom0.generateSeed(0);
		Assertions.hasEnsuredPredicate(randInt);
		Assertions.mustBeInAcceptingState(secureRandom0);

		int keylength = 0;
		char[] password = null;

		PBEKeySpec pBEKeySpec0 = new PBEKeySpec(password, genSeed, 26924, keylength);
		Assertions.hasEnsuredPredicate(pBEKeySpec0);

		SecretKeyFactory secretKeyFactory0 = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA512");
		SecretKey secretKey = secretKeyFactory0.generateSecret(pBEKeySpec0);
		Assertions.hasEnsuredPredicate(secretKey);
		Assertions.mustBeInAcceptingState(secretKeyFactory0);

		byte inp = 0;

		Mac mac0 = Mac.getInstance("HmacMD5");
		mac0.init(secretKey);
		mac0.update(inp);
		byte[] output1 = mac0.doFinal();
		Assertions.hasEnsuredPredicate(output1);
		Assertions.mustBeInAcceptingState(mac0);
		pBEKeySpec0.clearPassword();
		Assertions.mustBeInAcceptingState(pBEKeySpec0);

	}

	@Test
	public void macValidTest6() throws IllegalStateException, InvalidKeySpecException, NoSuchAlgorithmException,
			InvalidKeyException, NoSuchProviderException {

		SecureRandom secureRandom0 = SecureRandom.getInstance("SHA1PRNG");
		byte[] genSeed = secureRandom0.generateSeed(0);
		Assertions.hasEnsuredPredicate(randInt);
		Assertions.mustBeInAcceptingState(secureRandom0);

		int keylength = 0;
		char[] password = null;

		PBEKeySpec pBEKeySpec0 = new PBEKeySpec(password, genSeed, 17118, keylength);
		Assertions.hasEnsuredPredicate(pBEKeySpec0);

		SecretKeyFactory secretKeyFactory0 = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA512");
		SecretKey secretKey = secretKeyFactory0.generateSecret(pBEKeySpec0);
		Assertions.hasEnsuredPredicate(secretKey);
		Assertions.mustBeInAcceptingState(secretKeyFactory0);

		byte inp = 0;

		Mac mac0 = Mac.getInstance("HmacMD5", (Provider) null);
		mac0.init(secretKey);
		mac0.update(inp);
		byte[] output1 = mac0.doFinal();
		Assertions.hasEnsuredPredicate(output1);
		Assertions.mustBeInAcceptingState(mac0);
		pBEKeySpec0.clearPassword();
		Assertions.mustBeInAcceptingState(pBEKeySpec0);

	}

	@Test
	public void macValidTest7() throws IllegalStateException, InvalidKeySpecException, NoSuchAlgorithmException,
			InvalidKeyException, InvalidAlgorithmParameterException {

		SecureRandom secureRandom0 = SecureRandom.getInstance("SHA1PRNG");
		byte[] genSeed = secureRandom0.generateSeed(0);
		Assertions.hasEnsuredPredicate(randInt);
		Assertions.mustBeInAcceptingState(secureRandom0);

		int keylength = 0;
		char[] password = null;

		PBEKeySpec pBEKeySpec0 = new PBEKeySpec(password, genSeed, 29479, keylength);
		Assertions.hasEnsuredPredicate(pBEKeySpec0);

		SecretKeyFactory secretKeyFactory0 = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA512");
		SecretKey secretKey = secretKeyFactory0.generateSecret(pBEKeySpec0);
		Assertions.hasEnsuredPredicate(secretKey);
		Assertions.mustBeInAcceptingState(secretKeyFactory0);

		int outputLength = 0;

		HMACParameterSpec hMACParameterSpec0 = new HMACParameterSpec(outputLength);
		Assertions.hasEnsuredPredicate(hMACParameterSpec0);
		Assertions.mustBeInAcceptingState(hMACParameterSpec0);

		byte inp = 0;

		Mac mac0 = Mac.getInstance("HmacMD5");
		mac0.init(secretKey, hMACParameterSpec0);
		mac0.update(inp);
		byte[] output1 = mac0.doFinal();
		Assertions.hasEnsuredPredicate(output1);
		Assertions.mustBeInAcceptingState(mac0);
		pBEKeySpec0.clearPassword();
		Assertions.mustBeInAcceptingState(pBEKeySpec0);

	}

	@Test
	public void macValidTest8()
			throws IllegalStateException, InvalidKeySpecException, NoSuchAlgorithmException, InvalidKeyException {

		SecureRandom secureRandom0 = SecureRandom.getInstance("SHA1PRNG");
		byte[] genSeed = secureRandom0.generateSeed(0);
		Assertions.hasEnsuredPredicate(randInt);
		Assertions.mustBeInAcceptingState(secureRandom0);

		int keylength = 0;
		char[] password = null;

		PBEKeySpec pBEKeySpec0 = new PBEKeySpec(password, genSeed, 18484, keylength);
		Assertions.hasEnsuredPredicate(pBEKeySpec0);

		SecretKeyFactory secretKeyFactory0 = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA512");
		SecretKey secretKey = secretKeyFactory0.generateSecret(pBEKeySpec0);
		Assertions.hasEnsuredPredicate(secretKey);
		Assertions.mustBeInAcceptingState(secretKeyFactory0);

		byte[] pre_input = null;

		Mac mac0 = Mac.getInstance("HmacMD5");
		mac0.init(secretKey);
		mac0.update(pre_input);
		byte[] output1 = mac0.doFinal();
		Assertions.hasEnsuredPredicate(output1);
		Assertions.mustBeInAcceptingState(mac0);
		pBEKeySpec0.clearPassword();
		Assertions.mustBeInAcceptingState(pBEKeySpec0);

	}

	@Test
	public void macValidTest9()
			throws IllegalStateException, InvalidKeySpecException, NoSuchAlgorithmException, InvalidKeyException {

		SecureRandom secureRandom0 = SecureRandom.getInstance("SHA1PRNG");
		byte[] genSeed = secureRandom0.generateSeed(0);
		Assertions.hasEnsuredPredicate(randInt);
		Assertions.mustBeInAcceptingState(secureRandom0);

		int keylength = 0;
		char[] password = null;

		PBEKeySpec pBEKeySpec0 = new PBEKeySpec(password, genSeed, 21251, keylength);
		Assertions.hasEnsuredPredicate(pBEKeySpec0);

		SecretKeyFactory secretKeyFactory0 = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA512");
		SecretKey secretKey = secretKeyFactory0.generateSecret(pBEKeySpec0);
		Assertions.hasEnsuredPredicate(secretKey);
		Assertions.mustBeInAcceptingState(secretKeyFactory0);

		int offset = 0;
		int len = 0;
		byte[] pre_input = null;

		Mac mac0 = Mac.getInstance("HmacMD5");
		mac0.init(secretKey);
		mac0.update(pre_input, offset, len);
		byte[] output1 = mac0.doFinal();
		Assertions.hasEnsuredPredicate(output1);
		Assertions.mustBeInAcceptingState(mac0);
		pBEKeySpec0.clearPassword();
		Assertions.mustBeInAcceptingState(pBEKeySpec0);

	}

	@Test
	public void macValidTest10()
			throws IllegalStateException, InvalidKeySpecException, NoSuchAlgorithmException, InvalidKeyException {

		SecureRandom secureRandom0 = SecureRandom.getInstance("SHA1PRNG");
		byte[] genSeed = secureRandom0.generateSeed(0);
		Assertions.hasEnsuredPredicate(randInt);
		Assertions.mustBeInAcceptingState(secureRandom0);

		int keylength = 0;
		char[] password = null;

		PBEKeySpec pBEKeySpec0 = new PBEKeySpec(password, genSeed, 11127, keylength);
		Assertions.hasEnsuredPredicate(pBEKeySpec0);

		SecretKeyFactory secretKeyFactory0 = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA512");
		SecretKey secretKey = secretKeyFactory0.generateSecret(pBEKeySpec0);
		Assertions.hasEnsuredPredicate(secretKey);
		Assertions.mustBeInAcceptingState(secretKeyFactory0);

		byte[] pre_input = null;

		Mac mac0 = Mac.getInstance("HmacMD5");
		mac0.init(secretKey);
		mac0.update(pre_input);
		byte[] output1 = mac0.doFinal();
		Assertions.hasEnsuredPredicate(output1);
		Assertions.mustBeInAcceptingState(mac0);
		pBEKeySpec0.clearPassword();
		Assertions.mustBeInAcceptingState(pBEKeySpec0);

	}

	@Test
	public void macValidTest11() throws IllegalStateException, InvalidKeySpecException, NoSuchAlgorithmException,
			InvalidKeyException, ShortBufferException {

		SecureRandom secureRandom0 = SecureRandom.getInstance("SHA1PRNG");
		byte[] genSeed = secureRandom0.generateSeed(0);
		Assertions.hasEnsuredPredicate(randInt);
		Assertions.mustBeInAcceptingState(secureRandom0);

		int keylength = 0;
		char[] password = null;

		PBEKeySpec pBEKeySpec0 = new PBEKeySpec(password, genSeed, 13310, keylength);
		Assertions.hasEnsuredPredicate(pBEKeySpec0);

		SecretKeyFactory secretKeyFactory0 = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA512");
		SecretKey secretKey = secretKeyFactory0.generateSecret(pBEKeySpec0);
		Assertions.hasEnsuredPredicate(secretKey);
		Assertions.mustBeInAcceptingState(secretKeyFactory0);

		int outOffset = 0;
		byte inp = 0;

		Mac mac0 = Mac.getInstance("HmacMD5");
		mac0.init(secretKey);
		mac0.update(inp);
		mac0.doFinal(genSeed, outOffset);
		Assertions.hasEnsuredPredicate(output1);
		Assertions.mustBeInAcceptingState(mac0);
		pBEKeySpec0.clearPassword();
		Assertions.mustBeInAcceptingState(pBEKeySpec0);

	}

	@Test
	public void macValidTest12()
			throws IllegalStateException, InvalidKeySpecException, NoSuchAlgorithmException, InvalidKeyException {

		SecureRandom secureRandom0 = SecureRandom.getInstance("SHA1PRNG");
		byte[] genSeed = secureRandom0.generateSeed(0);
		Assertions.hasEnsuredPredicate(randInt);
		Assertions.mustBeInAcceptingState(secureRandom0);

		int keylength = 0;
		char[] password = null;

		PBEKeySpec pBEKeySpec0 = new PBEKeySpec(password, genSeed, 26231, keylength);
		Assertions.hasEnsuredPredicate(pBEKeySpec0);

		SecretKeyFactory secretKeyFactory0 = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA512");
		SecretKey secretKey = secretKeyFactory0.generateSecret(pBEKeySpec0);
		Assertions.hasEnsuredPredicate(secretKey);
		Assertions.mustBeInAcceptingState(secretKeyFactory0);

		byte[] input = null;
		byte inp = 0;

		Mac mac0 = Mac.getInstance("HmacMD5");
		mac0.init(secretKey);
		mac0.update(inp);
		byte[] output2 = mac0.doFinal(input);
		Assertions.hasEnsuredPredicate(output2);
		Assertions.mustBeInAcceptingState(mac0);
		pBEKeySpec0.clearPassword();
		Assertions.mustBeInAcceptingState(pBEKeySpec0);

	}

	@Test
	public void macInvalidTest1() throws NoSuchAlgorithmException {

		Mac mac0 = Mac.getInstance("HmacMD5");
		Assertions.mustNotBeInAcceptingState(mac0);

	}

	@Test
	public void macInvalidTest2() throws NoSuchAlgorithmException, NoSuchProviderException {

		Mac mac0 = Mac.getInstance("HmacMD5", (Provider) null);
		Assertions.mustNotBeInAcceptingState(mac0);

	}

	@Test
	public void macInvalidTest3() throws InvalidKeySpecException, NoSuchAlgorithmException, InvalidKeyException {

		SecureRandom secureRandom0 = SecureRandom.getInstance("SHA1PRNG");
		byte[] genSeed = secureRandom0.generateSeed(0);
		Assertions.hasEnsuredPredicate(randInt);
		Assertions.mustBeInAcceptingState(secureRandom0);

		int keylength = 0;
		char[] password = null;

		PBEKeySpec pBEKeySpec0 = new PBEKeySpec(password, genSeed, 20564, keylength);
		Assertions.hasEnsuredPredicate(pBEKeySpec0);

		SecretKeyFactory secretKeyFactory0 = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA512");
		SecretKey secretKey = secretKeyFactory0.generateSecret(pBEKeySpec0);
		Assertions.hasEnsuredPredicate(secretKey);
		Assertions.mustBeInAcceptingState(secretKeyFactory0);

		Mac mac0 = Mac.getInstance("HmacMD5");
		mac0.init(secretKey);
		Assertions.mustNotBeInAcceptingState(mac0);
		pBEKeySpec0.clearPassword();
		Assertions.mustBeInAcceptingState(pBEKeySpec0);

	}

	@Test
	public void macInvalidTest4()
			throws InvalidKeySpecException, NoSuchAlgorithmException, InvalidKeyException, NoSuchProviderException {

		SecureRandom secureRandom0 = SecureRandom.getInstance("SHA1PRNG");
		byte[] genSeed = secureRandom0.generateSeed(0);
		Assertions.hasEnsuredPredicate(randInt);
		Assertions.mustBeInAcceptingState(secureRandom0);

		int keylength = 0;
		char[] password = null;

		PBEKeySpec pBEKeySpec0 = new PBEKeySpec(password, genSeed, 24891, keylength);
		Assertions.hasEnsuredPredicate(pBEKeySpec0);

		SecretKeyFactory secretKeyFactory0 = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA512");
		SecretKey secretKey = secretKeyFactory0.generateSecret(pBEKeySpec0);
		Assertions.hasEnsuredPredicate(secretKey);
		Assertions.mustBeInAcceptingState(secretKeyFactory0);

		Mac mac0 = Mac.getInstance("HmacMD5", (Provider) null);
		mac0.init(secretKey);
		Assertions.mustNotBeInAcceptingState(mac0);
		pBEKeySpec0.clearPassword();
		Assertions.mustBeInAcceptingState(pBEKeySpec0);

	}

	@Test
	public void macInvalidTest5() throws InvalidKeySpecException, NoSuchAlgorithmException, InvalidKeyException,
			InvalidAlgorithmParameterException {

		SecureRandom secureRandom0 = SecureRandom.getInstance("SHA1PRNG");
		byte[] genSeed = secureRandom0.generateSeed(0);
		Assertions.hasEnsuredPredicate(randInt);
		Assertions.mustBeInAcceptingState(secureRandom0);

		int keylength = 0;
		char[] password = null;

		PBEKeySpec pBEKeySpec0 = new PBEKeySpec(password, genSeed, 12584, keylength);
		Assertions.hasEnsuredPredicate(pBEKeySpec0);

		SecretKeyFactory secretKeyFactory0 = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA512");
		SecretKey secretKey = secretKeyFactory0.generateSecret(pBEKeySpec0);
		Assertions.hasEnsuredPredicate(secretKey);
		Assertions.mustBeInAcceptingState(secretKeyFactory0);

		int outputLength = 0;

		HMACParameterSpec hMACParameterSpec0 = new HMACParameterSpec(outputLength);
		Assertions.hasEnsuredPredicate(hMACParameterSpec0);
		Assertions.mustBeInAcceptingState(hMACParameterSpec0);

		Mac mac0 = Mac.getInstance("HmacMD5");
		mac0.init(secretKey, hMACParameterSpec0);
		Assertions.mustNotBeInAcceptingState(mac0);
		pBEKeySpec0.clearPassword();
		Assertions.mustBeInAcceptingState(pBEKeySpec0);

	}

	@Test
	public void macInvalidTest6() throws IllegalStateException, NoSuchAlgorithmException {

		Mac mac0 = Mac.getInstance("HmacMD5");
		byte[] output1 = mac0.doFinal();
		Assertions.notHasEnsuredPredicate(output1);
		Assertions.mustNotBeInAcceptingState(mac0);

	}

	@Test
	public void macInvalidTest7() throws IllegalStateException, NoSuchAlgorithmException, NoSuchProviderException {

		Mac mac0 = Mac.getInstance("HmacMD5", (Provider) null);
		byte[] output1 = mac0.doFinal();
		Assertions.notHasEnsuredPredicate(output1);
		Assertions.mustNotBeInAcceptingState(mac0);

	}

	@Test
	public void macInvalidTest8() throws IllegalStateException, BadPaddingException, NoSuchPaddingException,
			IllegalBlockSizeException, NoSuchAlgorithmException, InvalidKeyException, ShortBufferException {

		Certificate cert = null;
		byte[] plainText = null;
		byte[] pre_plaintext = null;

		Cipher cipher0 = Cipher.getInstance("RSA");
		cipher0.init(1, cert);
		byte[] pre_ciphertext = cipher0.update(pre_plaintext);
		byte[] cipherText = cipher0.doFinal(plainText);
		Assertions.hasEnsuredPredicate(cipher0);
		Assertions.mustBeInAcceptingState(cipher0);

		int outOffset = 0;

		Mac mac0 = Mac.getInstance("HmacMD5");
		mac0.doFinal(cipherText, outOffset);
		Assertions.notHasEnsuredPredicate(cipherText);
		Assertions.mustNotBeInAcceptingState(mac0);

	}

	@Test
	public void macInvalidTest9()
			throws IllegalStateException, InvalidKeySpecException, NoSuchAlgorithmException, InvalidKeyException {

		SecureRandom secureRandom0 = SecureRandom.getInstance("SHA1PRNG");
		byte[] genSeed = secureRandom0.generateSeed(0);
		Assertions.hasEnsuredPredicate(randInt);
		Assertions.mustBeInAcceptingState(secureRandom0);

		int keylength = 0;
		char[] password = null;

		PBEKeySpec pBEKeySpec0 = new PBEKeySpec(password, genSeed, 15556, keylength);
		Assertions.hasEnsuredPredicate(pBEKeySpec0);

		SecretKeyFactory secretKeyFactory0 = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA512");
		SecretKey secretKey = secretKeyFactory0.generateSecret(pBEKeySpec0);
		Assertions.hasEnsuredPredicate(secretKey);
		Assertions.mustBeInAcceptingState(secretKeyFactory0);

		byte inp = 0;

		Mac mac0 = Mac.getInstance("HmacMD5");
		mac0.init(secretKey);
		mac0.update(inp);
		Assertions.mustNotBeInAcceptingState(mac0);
		pBEKeySpec0.clearPassword();
		Assertions.mustBeInAcceptingState(pBEKeySpec0);

	}

	@Test
	public void macInvalidTest10() throws IllegalStateException, InvalidKeySpecException, NoSuchAlgorithmException,
			InvalidKeyException, NoSuchProviderException {

		SecureRandom secureRandom0 = SecureRandom.getInstance("SHA1PRNG");
		byte[] genSeed = secureRandom0.generateSeed(0);
		Assertions.hasEnsuredPredicate(randInt);
		Assertions.mustBeInAcceptingState(secureRandom0);

		int keylength = 0;
		char[] password = null;

		PBEKeySpec pBEKeySpec0 = new PBEKeySpec(password, genSeed, 14268, keylength);
		Assertions.hasEnsuredPredicate(pBEKeySpec0);

		SecretKeyFactory secretKeyFactory0 = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA512");
		SecretKey secretKey = secretKeyFactory0.generateSecret(pBEKeySpec0);
		Assertions.hasEnsuredPredicate(secretKey);
		Assertions.mustBeInAcceptingState(secretKeyFactory0);

		byte inp = 0;

		Mac mac0 = Mac.getInstance("HmacMD5", (Provider) null);
		mac0.init(secretKey);
		mac0.update(inp);
		Assertions.mustNotBeInAcceptingState(mac0);
		pBEKeySpec0.clearPassword();
		Assertions.mustBeInAcceptingState(pBEKeySpec0);

	}

	@Test
	public void macInvalidTest11() throws IllegalStateException, InvalidKeySpecException, NoSuchAlgorithmException,
			InvalidKeyException, InvalidAlgorithmParameterException {

		SecureRandom secureRandom0 = SecureRandom.getInstance("SHA1PRNG");
		byte[] genSeed = secureRandom0.generateSeed(0);
		Assertions.hasEnsuredPredicate(randInt);
		Assertions.mustBeInAcceptingState(secureRandom0);

		int keylength = 0;
		char[] password = null;

		PBEKeySpec pBEKeySpec0 = new PBEKeySpec(password, genSeed, 18921, keylength);
		Assertions.hasEnsuredPredicate(pBEKeySpec0);

		SecretKeyFactory secretKeyFactory0 = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA512");
		SecretKey secretKey = secretKeyFactory0.generateSecret(pBEKeySpec0);
		Assertions.hasEnsuredPredicate(secretKey);
		Assertions.mustBeInAcceptingState(secretKeyFactory0);

		int outputLength = 0;

		HMACParameterSpec hMACParameterSpec0 = new HMACParameterSpec(outputLength);
		Assertions.hasEnsuredPredicate(hMACParameterSpec0);
		Assertions.mustBeInAcceptingState(hMACParameterSpec0);

		byte inp = 0;

		Mac mac0 = Mac.getInstance("HmacMD5");
		mac0.init(secretKey, hMACParameterSpec0);
		mac0.update(inp);
		Assertions.mustNotBeInAcceptingState(mac0);
		pBEKeySpec0.clearPassword();
		Assertions.mustBeInAcceptingState(pBEKeySpec0);

	}

	@Test
	public void macInvalidTest12()
			throws IllegalStateException, InvalidKeySpecException, NoSuchAlgorithmException, InvalidKeyException {

		SecureRandom secureRandom0 = SecureRandom.getInstance("SHA1PRNG");
		byte[] genSeed = secureRandom0.generateSeed(0);
		Assertions.hasEnsuredPredicate(randInt);
		Assertions.mustBeInAcceptingState(secureRandom0);

		int keylength = 0;
		char[] password = null;

		PBEKeySpec pBEKeySpec0 = new PBEKeySpec(password, genSeed, 16421, keylength);
		Assertions.hasEnsuredPredicate(pBEKeySpec0);

		SecretKeyFactory secretKeyFactory0 = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA512");
		SecretKey secretKey = secretKeyFactory0.generateSecret(pBEKeySpec0);
		Assertions.hasEnsuredPredicate(secretKey);
		Assertions.mustBeInAcceptingState(secretKeyFactory0);

		byte[] pre_input = null;

		Mac mac0 = Mac.getInstance("HmacMD5");
		mac0.init(secretKey);
		mac0.update(pre_input);
		Assertions.mustNotBeInAcceptingState(mac0);
		pBEKeySpec0.clearPassword();
		Assertions.mustBeInAcceptingState(pBEKeySpec0);

	}

	@Test
	public void macInvalidTest13()
			throws IllegalStateException, InvalidKeySpecException, NoSuchAlgorithmException, InvalidKeyException {

		SecureRandom secureRandom0 = SecureRandom.getInstance("SHA1PRNG");
		byte[] genSeed = secureRandom0.generateSeed(0);
		Assertions.hasEnsuredPredicate(randInt);
		Assertions.mustBeInAcceptingState(secureRandom0);

		int keylength = 0;
		char[] password = null;

		PBEKeySpec pBEKeySpec0 = new PBEKeySpec(password, genSeed, 18032, keylength);
		Assertions.hasEnsuredPredicate(pBEKeySpec0);

		SecretKeyFactory secretKeyFactory0 = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA512");
		SecretKey secretKey = secretKeyFactory0.generateSecret(pBEKeySpec0);
		Assertions.hasEnsuredPredicate(secretKey);
		Assertions.mustBeInAcceptingState(secretKeyFactory0);

		int offset = 0;
		int len = 0;
		byte[] pre_input = null;

		Mac mac0 = Mac.getInstance("HmacMD5");
		mac0.init(secretKey);
		mac0.update(pre_input, offset, len);
		Assertions.mustNotBeInAcceptingState(mac0);
		pBEKeySpec0.clearPassword();
		Assertions.mustBeInAcceptingState(pBEKeySpec0);

	}

	@Test
	public void macInvalidTest14()
			throws IllegalStateException, InvalidKeySpecException, NoSuchAlgorithmException, InvalidKeyException {

		SecureRandom secureRandom0 = SecureRandom.getInstance("SHA1PRNG");
		byte[] genSeed = secureRandom0.generateSeed(0);
		Assertions.hasEnsuredPredicate(randInt);
		Assertions.mustBeInAcceptingState(secureRandom0);

		int keylength = 0;
		char[] password = null;

		PBEKeySpec pBEKeySpec0 = new PBEKeySpec(password, genSeed, 18786, keylength);
		Assertions.hasEnsuredPredicate(pBEKeySpec0);

		SecretKeyFactory secretKeyFactory0 = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA512");
		SecretKey secretKey = secretKeyFactory0.generateSecret(pBEKeySpec0);
		Assertions.hasEnsuredPredicate(secretKey);
		Assertions.mustBeInAcceptingState(secretKeyFactory0);

		byte[] pre_input = null;

		Mac mac0 = Mac.getInstance("HmacMD5");
		mac0.init(secretKey);
		mac0.update(pre_input);
		Assertions.mustNotBeInAcceptingState(mac0);
		pBEKeySpec0.clearPassword();
		Assertions.mustBeInAcceptingState(pBEKeySpec0);

	}

	@Test
	public void macInvalidTest15() throws IllegalStateException, NoSuchAlgorithmException {

		byte inp = 0;

		Mac mac0 = Mac.getInstance("HmacMD5");
		mac0.update(inp);
		byte[] output1 = mac0.doFinal();
		Assertions.notHasEnsuredPredicate(output1);
		Assertions.mustNotBeInAcceptingState(mac0);

	}

	@Test
	public void macInvalidTest16() throws IllegalStateException, NoSuchAlgorithmException, NoSuchProviderException {

		byte inp = 0;

		Mac mac0 = Mac.getInstance("HmacMD5", (Provider) null);
		mac0.update(inp);
		byte[] output1 = mac0.doFinal();
		Assertions.notHasEnsuredPredicate(output1);
		Assertions.mustNotBeInAcceptingState(mac0);

	}

	@Test
	public void macInvalidTest17() throws IllegalStateException, NoSuchAlgorithmException {

		byte[] pre_input = null;

		Mac mac0 = Mac.getInstance("HmacMD5");
		mac0.update(pre_input);
		byte[] output1 = mac0.doFinal();
		Assertions.notHasEnsuredPredicate(output1);
		Assertions.mustNotBeInAcceptingState(mac0);

	}

	@Test
	public void macInvalidTest18() throws IllegalStateException, NoSuchAlgorithmException {

		int offset = 0;
		int len = 0;
		byte[] pre_input = null;

		Mac mac0 = Mac.getInstance("HmacMD5");
		mac0.update(pre_input, offset, len);
		byte[] output1 = mac0.doFinal();
		Assertions.notHasEnsuredPredicate(output1);
		Assertions.mustNotBeInAcceptingState(mac0);

	}

	@Test
	public void macInvalidTest19() throws IllegalStateException, NoSuchAlgorithmException {

		byte[] pre_input = null;

		Mac mac0 = Mac.getInstance("HmacMD5");
		mac0.update(pre_input);
		byte[] output1 = mac0.doFinal();
		Assertions.notHasEnsuredPredicate(output1);
		Assertions.mustNotBeInAcceptingState(mac0);

	}

	@Test
	public void macInvalidTest20() throws IllegalStateException, BadPaddingException, NoSuchPaddingException,
			IllegalBlockSizeException, NoSuchAlgorithmException, InvalidKeyException, ShortBufferException {

		Certificate cert = null;
		byte[] plainText = null;
		byte[] pre_plaintext = null;

		Cipher cipher0 = Cipher.getInstance("RSA");
		cipher0.init(1, cert);
		byte[] pre_ciphertext = cipher0.update(pre_plaintext);
		byte[] cipherText = cipher0.doFinal(plainText);
		Assertions.hasEnsuredPredicate(cipher0);
		Assertions.mustBeInAcceptingState(cipher0);

		int outOffset = 0;
		byte inp = 0;

		Mac mac0 = Mac.getInstance("HmacMD5");
		mac0.update(inp);
		mac0.doFinal(cipherText, outOffset);
		Assertions.notHasEnsuredPredicate(cipherText);
		Assertions.mustNotBeInAcceptingState(mac0);

	}

	@Test
	public void macInvalidTest21() throws IllegalStateException, NoSuchAlgorithmException {

		byte[] input = null;
		byte inp = 0;

		Mac mac0 = Mac.getInstance("HmacMD5");
		mac0.update(inp);
		byte[] output2 = mac0.doFinal(input);
		Assertions.notHasEnsuredPredicate(output2);
		Assertions.mustNotBeInAcceptingState(mac0);

	}
}