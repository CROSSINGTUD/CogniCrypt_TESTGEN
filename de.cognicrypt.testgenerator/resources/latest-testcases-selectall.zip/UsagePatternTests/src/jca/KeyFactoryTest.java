package jca;

import test.assertions.Assertions;
import crypto.analysis.CrySLRulesetSelector.Ruleset;
import java.security.spec.InvalidKeySpecException;
import org.junit.Test;
import java.security.PublicKey;
import java.security.KeyFactory;
import java.security.SecureRandom;
import java.security.PrivateKey;
import javax.crypto.spec.PBEKeySpec;
import java.security.NoSuchAlgorithmException;
import java.lang.String;
import test.UsagePatternTestingFramework;
import java.security.NoSuchProviderException;

public class KeyFactoryTest extends UsagePatternTestingFramework {
	protected Ruleset getRuleSet() {
		return Ruleset.JavaCryptographicArchitecture;

	}

	@Test
	public void keyFactoryValidTest1() throws NoSuchAlgorithmException {

		KeyFactory keyFactory0 = KeyFactory.getInstance("RSA");
		Assertions.hasEnsuredPredicate(keyFactory0);
		Assertions.mustBeInAcceptingState(keyFactory0);

	}

	@Test
	public void keyFactoryValidTest2() throws NoSuchAlgorithmException, NoSuchProviderException {

		KeyFactory keyFactory0 = KeyFactory.getInstance("RSA", (String) null);
		Assertions.hasEnsuredPredicate(keyFactory0);
		Assertions.mustBeInAcceptingState(keyFactory0);

	}

	@Test
	public void keyFactoryValidTest3() throws InvalidKeySpecException, NoSuchAlgorithmException {

		SecureRandom secureRandom0 = SecureRandom.getInstance("SHA1PRNG");
		byte[] genSeed = secureRandom0.generateSeed(0);
		Assertions.hasEnsuredPredicate(randInt);
		Assertions.mustBeInAcceptingState(secureRandom0);

		int keylength = 0;
		char[] password = null;

		PBEKeySpec pBEKeySpec0 = new PBEKeySpec(password, genSeed, 27790, keylength);
		Assertions.hasEnsuredPredicate(pBEKeySpec0);

		KeyFactory keyFactory0 = KeyFactory.getInstance("RSA");
		PrivateKey privateKey = keyFactory0.generatePrivate(pBEKeySpec0);
		Assertions.hasEnsuredPredicate(keyFactory0);
		Assertions.mustBeInAcceptingState(keyFactory0);
		pBEKeySpec0.clearPassword();
		Assertions.mustBeInAcceptingState(pBEKeySpec0);

	}

	@Test
	public void keyFactoryValidTest4()
			throws InvalidKeySpecException, NoSuchAlgorithmException, NoSuchProviderException {

		SecureRandom secureRandom0 = SecureRandom.getInstance("SHA1PRNG");
		byte[] genSeed = secureRandom0.generateSeed(0);
		Assertions.hasEnsuredPredicate(randInt);
		Assertions.mustBeInAcceptingState(secureRandom0);

		int keylength = 0;
		char[] password = null;

		PBEKeySpec pBEKeySpec0 = new PBEKeySpec(password, genSeed, 29169, keylength);
		Assertions.hasEnsuredPredicate(pBEKeySpec0);

		KeyFactory keyFactory0 = KeyFactory.getInstance("RSA", (String) null);
		PrivateKey privateKey = keyFactory0.generatePrivate(pBEKeySpec0);
		Assertions.hasEnsuredPredicate(keyFactory0);
		Assertions.mustBeInAcceptingState(keyFactory0);
		pBEKeySpec0.clearPassword();
		Assertions.mustBeInAcceptingState(pBEKeySpec0);

	}

	@Test
	public void keyFactoryValidTest5() throws InvalidKeySpecException, NoSuchAlgorithmException {

		SecureRandom secureRandom0 = SecureRandom.getInstance("SHA1PRNG");
		byte[] genSeed = secureRandom0.generateSeed(0);
		Assertions.hasEnsuredPredicate(randInt);
		Assertions.mustBeInAcceptingState(secureRandom0);

		int keylength = 0;
		char[] password = null;

		PBEKeySpec pBEKeySpec0 = new PBEKeySpec(password, genSeed, 19264, keylength);
		Assertions.hasEnsuredPredicate(pBEKeySpec0);

		KeyFactory keyFactory0 = KeyFactory.getInstance("RSA");
		PublicKey publicKey = keyFactory0.generatePublic(pBEKeySpec0);
		Assertions.hasEnsuredPredicate(keyFactory0);
		Assertions.mustBeInAcceptingState(keyFactory0);
		pBEKeySpec0.clearPassword();
		Assertions.mustBeInAcceptingState(pBEKeySpec0);

	}

	@Test
	public void keyFactoryValidTest6()
			throws InvalidKeySpecException, NoSuchAlgorithmException, NoSuchProviderException {

		SecureRandom secureRandom0 = SecureRandom.getInstance("SHA1PRNG");
		byte[] genSeed = secureRandom0.generateSeed(0);
		Assertions.hasEnsuredPredicate(randInt);
		Assertions.mustBeInAcceptingState(secureRandom0);

		int keylength = 0;
		char[] password = null;

		PBEKeySpec pBEKeySpec0 = new PBEKeySpec(password, genSeed, 12942, keylength);
		Assertions.hasEnsuredPredicate(pBEKeySpec0);

		KeyFactory keyFactory0 = KeyFactory.getInstance("RSA", (String) null);
		PublicKey publicKey = keyFactory0.generatePublic(pBEKeySpec0);
		Assertions.hasEnsuredPredicate(keyFactory0);
		Assertions.mustBeInAcceptingState(keyFactory0);
		pBEKeySpec0.clearPassword();
		Assertions.mustBeInAcceptingState(pBEKeySpec0);

	}
}