package jca;

import test.assertions.Assertions;
import java.security.AlgorithmParameterGenerator;
import crypto.analysis.CrySLRulesetSelector.Ruleset;
import java.security.spec.InvalidKeySpecException;
import javax.crypto.Cipher;
import java.nio.ByteBuffer;
import java.security.InvalidAlgorithmParameterException;
import java.security.SecureRandom;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.PBEKeySpec;
import test.UsagePatternTestingFramework;
import javax.crypto.ShortBufferException;
import javax.crypto.IllegalBlockSizeException;
import org.junit.Test;
import java.security.AlgorithmParameters;
import java.security.Provider;
import java.security.Key;
import javax.crypto.BadPaddingException;
import java.security.cert.Certificate;
import java.security.NoSuchAlgorithmException;
import java.security.InvalidKeyException;
import javax.crypto.SecretKey;
import java.security.NoSuchProviderException;

public class CipherTest extends UsagePatternTestingFramework {
	protected Ruleset getRuleSet() {
		return Ruleset.JavaCryptographicArchitecture;

	}

	@Test
	public void cipherValidTest1()
			throws NoSuchPaddingException, IllegalBlockSizeException, NoSuchAlgorithmException, InvalidKeyException {

		Certificate cert = null;
		Key wrappedKey = null;

		Cipher cipher0 = Cipher.getInstance("RSA");
		cipher0.init(1, cert);
		byte[] wrappedKeyBytes = cipher0.wrap(wrappedKey);
		Assertions.hasEnsuredPredicate(cipher0);
		Assertions.mustBeInAcceptingState(cipher0);

	}

	@Test
	public void cipherValidTest2() throws NoSuchPaddingException, IllegalBlockSizeException, NoSuchAlgorithmException,
			InvalidKeyException, NoSuchProviderException {

		Certificate cert = null;
		Key wrappedKey = null;

		Cipher cipher0 = Cipher.getInstance("RSA", (Provider) null);
		cipher0.init(1, cert);
		byte[] wrappedKeyBytes = cipher0.wrap(wrappedKey);
		Assertions.hasEnsuredPredicate(cipher0);
		Assertions.mustBeInAcceptingState(cipher0);

	}

	@Test
	public void cipherValidTest3()
			throws NoSuchPaddingException, IllegalBlockSizeException, NoSuchAlgorithmException, InvalidKeyException {

		SecureRandom secureRandom0 = SecureRandom.getInstance("SHA1PRNG");
		Assertions.hasEnsuredPredicate(secureRandom0);
		Assertions.mustBeInAcceptingState(secureRandom0);

		Certificate cert = null;
		Key wrappedKey = null;

		Cipher cipher0 = Cipher.getInstance("RSA");
		cipher0.init(1, cert, secureRandom0);
		byte[] wrappedKeyBytes = cipher0.wrap(wrappedKey);
		Assertions.hasEnsuredPredicate(cipher0);
		Assertions.mustBeInAcceptingState(cipher0);

	}

	@Test
	public void cipherValidTest4() throws NoSuchPaddingException, InvalidKeySpecException, IllegalBlockSizeException,
			NoSuchAlgorithmException, InvalidKeyException {

		SecureRandom secureRandom0 = SecureRandom.getInstance("SHA1PRNG");
		byte[] genSeed = secureRandom0.generateSeed(0);
		Assertions.hasEnsuredPredicate(randInt);
		Assertions.mustBeInAcceptingState(secureRandom0);

		int keylength = 0;
		char[] password = null;

		PBEKeySpec pBEKeySpec0 = new PBEKeySpec(password, genSeed, 27979, keylength);
		Assertions.hasEnsuredPredicate(pBEKeySpec0);

		SecretKeyFactory secretKeyFactory0 = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA512");
		SecretKey secretKey = secretKeyFactory0.generateSecret(pBEKeySpec0);
		Assertions.hasEnsuredPredicate(secretKey);
		Assertions.mustBeInAcceptingState(secretKeyFactory0);

		Key wrappedKey = null;

		Cipher cipher0 = Cipher.getInstance("RSA");
		cipher0.init(1, secretKey);
		byte[] wrappedKeyBytes = cipher0.wrap(wrappedKey);
		Assertions.hasEnsuredPredicate(cipher0);
		Assertions.mustBeInAcceptingState(cipher0);
		pBEKeySpec0.clearPassword();
		Assertions.mustBeInAcceptingState(pBEKeySpec0);

	}

	@Test
	public void cipherValidTest5() throws NoSuchPaddingException, InvalidKeySpecException, IllegalBlockSizeException,
			NoSuchAlgorithmException, InvalidKeyException {

		SecureRandom secureRandom0 = SecureRandom.getInstance("SHA1PRNG");
		byte[] genSeed = secureRandom0.generateSeed(0);
		Assertions.hasEnsuredPredicate(randInt);
		Assertions.mustBeInAcceptingState(secureRandom0);

		int keylength = 0;
		char[] password = null;

		PBEKeySpec pBEKeySpec0 = new PBEKeySpec(password, genSeed, 11314, keylength);
		Assertions.hasEnsuredPredicate(pBEKeySpec0);

		SecretKeyFactory secretKeyFactory0 = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA512");
		SecretKey secretKey = secretKeyFactory0.generateSecret(pBEKeySpec0);
		Assertions.hasEnsuredPredicate(secretKey);
		Assertions.mustBeInAcceptingState(secretKeyFactory0);

		Key wrappedKey = null;

		Cipher cipher0 = Cipher.getInstance("RSA");
		cipher0.init(1, secretKey, secureRandom0);
		byte[] wrappedKeyBytes = cipher0.wrap(wrappedKey);
		Assertions.hasEnsuredPredicate(cipher0);
		Assertions.mustBeInAcceptingState(cipher0);
		pBEKeySpec0.clearPassword();
		Assertions.mustBeInAcceptingState(pBEKeySpec0);

	}

	@Test
	public void cipherValidTest6() throws NoSuchPaddingException, InvalidKeySpecException, IllegalBlockSizeException,
			NoSuchAlgorithmException, InvalidKeyException, InvalidAlgorithmParameterException {

		SecureRandom secureRandom0 = SecureRandom.getInstance("SHA1PRNG");
		byte[] genSeed = secureRandom0.generateSeed(0);
		Assertions.hasEnsuredPredicate(randInt);
		Assertions.mustBeInAcceptingState(secureRandom0);

		int keylength = 0;
		char[] password = null;

		PBEKeySpec pBEKeySpec0 = new PBEKeySpec(password, genSeed, 21972, keylength);
		Assertions.hasEnsuredPredicate(pBEKeySpec0);

		SecretKeyFactory secretKeyFactory0 = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA512");
		SecretKey secretKey = secretKeyFactory0.generateSecret(pBEKeySpec0);
		Assertions.hasEnsuredPredicate(secretKey);
		Assertions.mustBeInAcceptingState(secretKeyFactory0);

		IvParameterSpec ivParameterSpec0 = new IvParameterSpec(genSeed);
		Assertions.hasEnsuredPredicate(ivParameterSpec0);
		Assertions.mustBeInAcceptingState(ivParameterSpec0);

		Key wrappedKey = null;

		Cipher cipher0 = Cipher.getInstance("RSA");
		cipher0.init(1, secretKey, ivParameterSpec0);
		byte[] wrappedKeyBytes = cipher0.wrap(wrappedKey);
		Assertions.hasEnsuredPredicate(cipher0);
		Assertions.mustBeInAcceptingState(cipher0);
		pBEKeySpec0.clearPassword();
		Assertions.mustBeInAcceptingState(pBEKeySpec0);

	}

	@Test
	public void cipherValidTest7() throws NoSuchPaddingException, InvalidKeySpecException, IllegalBlockSizeException,
			NoSuchAlgorithmException, InvalidKeyException, InvalidAlgorithmParameterException {

		SecureRandom secureRandom0 = SecureRandom.getInstance("SHA1PRNG");
		byte[] genSeed = secureRandom0.generateSeed(0);
		Assertions.hasEnsuredPredicate(randInt);
		Assertions.mustBeInAcceptingState(secureRandom0);

		int keylength = 0;
		char[] password = null;

		PBEKeySpec pBEKeySpec0 = new PBEKeySpec(password, genSeed, 24352, keylength);
		Assertions.hasEnsuredPredicate(pBEKeySpec0);

		SecretKeyFactory secretKeyFactory0 = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA512");
		SecretKey secretKey = secretKeyFactory0.generateSecret(pBEKeySpec0);
		Assertions.hasEnsuredPredicate(secretKey);
		Assertions.mustBeInAcceptingState(secretKeyFactory0);

		AlgorithmParameterGenerator algorithmParameterGenerator0 = AlgorithmParameterGenerator.getInstance("DH");
		algorithmParameterGenerator0.init(1024);
		AlgorithmParameters algorithmParameters = algorithmParameterGenerator0.generateParameters();
		Assertions.hasEnsuredPredicate(algorithmParameters);
		Assertions.mustBeInAcceptingState(algorithmParameterGenerator0);

		Key wrappedKey = null;

		Cipher cipher0 = Cipher.getInstance("RSA");
		cipher0.init(1, secretKey, algorithmParameters);
		byte[] wrappedKeyBytes = cipher0.wrap(wrappedKey);
		Assertions.hasEnsuredPredicate(cipher0);
		Assertions.mustBeInAcceptingState(cipher0);
		pBEKeySpec0.clearPassword();
		Assertions.mustBeInAcceptingState(pBEKeySpec0);

	}

	@Test
	public void cipherValidTest8() throws NoSuchPaddingException, InvalidKeySpecException, IllegalBlockSizeException,
			NoSuchAlgorithmException, InvalidKeyException, InvalidAlgorithmParameterException {

		SecureRandom secureRandom0 = SecureRandom.getInstance("SHA1PRNG");
		byte[] genSeed = secureRandom0.generateSeed(0);
		Assertions.hasEnsuredPredicate(randInt);
		Assertions.mustBeInAcceptingState(secureRandom0);

		int keylength = 0;
		char[] password = null;

		PBEKeySpec pBEKeySpec0 = new PBEKeySpec(password, genSeed, 11557, keylength);
		Assertions.hasEnsuredPredicate(pBEKeySpec0);

		SecretKeyFactory secretKeyFactory0 = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA512");
		SecretKey secretKey = secretKeyFactory0.generateSecret(pBEKeySpec0);
		Assertions.hasEnsuredPredicate(secretKey);
		Assertions.mustBeInAcceptingState(secretKeyFactory0);

		IvParameterSpec ivParameterSpec0 = new IvParameterSpec(genSeed);
		Assertions.hasEnsuredPredicate(ivParameterSpec0);
		Assertions.mustBeInAcceptingState(ivParameterSpec0);

		Key wrappedKey = null;

		Cipher cipher0 = Cipher.getInstance("RSA");
		cipher0.init(1, secretKey, ivParameterSpec0, secureRandom0);
		byte[] wrappedKeyBytes = cipher0.wrap(wrappedKey);
		Assertions.hasEnsuredPredicate(cipher0);
		Assertions.mustBeInAcceptingState(cipher0);
		pBEKeySpec0.clearPassword();
		Assertions.mustBeInAcceptingState(pBEKeySpec0);

	}

	@Test
	public void cipherValidTest9() throws NoSuchPaddingException, InvalidKeySpecException, IllegalBlockSizeException,
			NoSuchAlgorithmException, InvalidKeyException, InvalidAlgorithmParameterException {

		SecureRandom secureRandom0 = SecureRandom.getInstance("SHA1PRNG");
		byte[] genSeed = secureRandom0.generateSeed(0);
		Assertions.hasEnsuredPredicate(randInt);
		Assertions.mustBeInAcceptingState(secureRandom0);

		int keylength = 0;
		char[] password = null;

		PBEKeySpec pBEKeySpec0 = new PBEKeySpec(password, genSeed, 23365, keylength);
		Assertions.hasEnsuredPredicate(pBEKeySpec0);

		SecretKeyFactory secretKeyFactory0 = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA512");
		SecretKey secretKey = secretKeyFactory0.generateSecret(pBEKeySpec0);
		Assertions.hasEnsuredPredicate(secretKey);
		Assertions.mustBeInAcceptingState(secretKeyFactory0);

		AlgorithmParameterGenerator algorithmParameterGenerator0 = AlgorithmParameterGenerator.getInstance("DH");
		algorithmParameterGenerator0.init(1024);
		AlgorithmParameters algorithmParameters = algorithmParameterGenerator0.generateParameters();
		Assertions.hasEnsuredPredicate(algorithmParameters);
		Assertions.mustBeInAcceptingState(algorithmParameterGenerator0);

		Key wrappedKey = null;

		Cipher cipher0 = Cipher.getInstance("RSA");
		cipher0.init(1, secretKey, algorithmParameters, secureRandom0);
		byte[] wrappedKeyBytes = cipher0.wrap(wrappedKey);
		Assertions.hasEnsuredPredicate(cipher0);
		Assertions.mustBeInAcceptingState(cipher0);
		pBEKeySpec0.clearPassword();
		Assertions.mustBeInAcceptingState(pBEKeySpec0);

	}

	@Test
	public void cipherValidTest10() throws BadPaddingException, NoSuchPaddingException, IllegalBlockSizeException,
			NoSuchAlgorithmException, InvalidKeyException {

		Certificate cert = null;
		byte[] plainText = null;

		Cipher cipher0 = Cipher.getInstance("RSA");
		cipher0.init(1, cert);
		byte[] cipherText = cipher0.doFinal(plainText);
		Assertions.hasEnsuredPredicate(cipher0);
		Assertions.mustBeInAcceptingState(cipher0);

	}

	@Test
	public void cipherValidTest11() throws BadPaddingException, NoSuchPaddingException, IllegalBlockSizeException,
			NoSuchAlgorithmException, InvalidKeyException, NoSuchProviderException {

		Certificate cert = null;
		byte[] plainText = null;

		Cipher cipher0 = Cipher.getInstance("RSA", (Provider) null);
		cipher0.init(1, cert);
		byte[] cipherText = cipher0.doFinal(plainText);
		Assertions.hasEnsuredPredicate(cipher0);
		Assertions.mustBeInAcceptingState(cipher0);

	}

	@Test
	public void cipherValidTest12() throws BadPaddingException, NoSuchPaddingException, IllegalBlockSizeException,
			NoSuchAlgorithmException, InvalidKeyException {

		SecureRandom secureRandom0 = SecureRandom.getInstance("SHA1PRNG");
		Assertions.hasEnsuredPredicate(secureRandom0);
		Assertions.mustBeInAcceptingState(secureRandom0);

		Certificate cert = null;
		byte[] plainText = null;

		Cipher cipher0 = Cipher.getInstance("RSA");
		cipher0.init(1, cert, secureRandom0);
		byte[] cipherText = cipher0.doFinal(plainText);
		Assertions.hasEnsuredPredicate(cipher0);
		Assertions.mustBeInAcceptingState(cipher0);

	}

	@Test
	public void cipherValidTest13() throws BadPaddingException, NoSuchPaddingException, InvalidKeySpecException,
			IllegalBlockSizeException, NoSuchAlgorithmException, InvalidKeyException {

		SecureRandom secureRandom0 = SecureRandom.getInstance("SHA1PRNG");
		byte[] genSeed = secureRandom0.generateSeed(0);
		Assertions.hasEnsuredPredicate(randInt);
		Assertions.mustBeInAcceptingState(secureRandom0);

		int keylength = 0;
		char[] password = null;

		PBEKeySpec pBEKeySpec0 = new PBEKeySpec(password, genSeed, 25753, keylength);
		Assertions.hasEnsuredPredicate(pBEKeySpec0);

		SecretKeyFactory secretKeyFactory0 = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA512");
		SecretKey secretKey = secretKeyFactory0.generateSecret(pBEKeySpec0);
		Assertions.hasEnsuredPredicate(secretKey);
		Assertions.mustBeInAcceptingState(secretKeyFactory0);

		byte[] plainText = null;

		Cipher cipher0 = Cipher.getInstance("RSA");
		cipher0.init(1, secretKey);
		byte[] cipherText = cipher0.doFinal(plainText);
		Assertions.hasEnsuredPredicate(cipher0);
		Assertions.mustBeInAcceptingState(cipher0);
		pBEKeySpec0.clearPassword();
		Assertions.mustBeInAcceptingState(pBEKeySpec0);

	}

	@Test
	public void cipherValidTest14() throws BadPaddingException, NoSuchPaddingException, InvalidKeySpecException,
			IllegalBlockSizeException, NoSuchAlgorithmException, InvalidKeyException {

		SecureRandom secureRandom0 = SecureRandom.getInstance("SHA1PRNG");
		byte[] genSeed = secureRandom0.generateSeed(0);
		Assertions.hasEnsuredPredicate(randInt);
		Assertions.mustBeInAcceptingState(secureRandom0);

		int keylength = 0;
		char[] password = null;

		PBEKeySpec pBEKeySpec0 = new PBEKeySpec(password, genSeed, 25610, keylength);
		Assertions.hasEnsuredPredicate(pBEKeySpec0);

		SecretKeyFactory secretKeyFactory0 = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA512");
		SecretKey secretKey = secretKeyFactory0.generateSecret(pBEKeySpec0);
		Assertions.hasEnsuredPredicate(secretKey);
		Assertions.mustBeInAcceptingState(secretKeyFactory0);

		byte[] plainText = null;

		Cipher cipher0 = Cipher.getInstance("RSA");
		cipher0.init(1, secretKey, secureRandom0);
		byte[] cipherText = cipher0.doFinal(plainText);
		Assertions.hasEnsuredPredicate(cipher0);
		Assertions.mustBeInAcceptingState(cipher0);
		pBEKeySpec0.clearPassword();
		Assertions.mustBeInAcceptingState(pBEKeySpec0);

	}

	@Test
	public void cipherValidTest15()
			throws BadPaddingException, NoSuchPaddingException, InvalidKeySpecException, IllegalBlockSizeException,
			NoSuchAlgorithmException, InvalidKeyException, InvalidAlgorithmParameterException {

		SecureRandom secureRandom0 = SecureRandom.getInstance("SHA1PRNG");
		byte[] genSeed = secureRandom0.generateSeed(0);
		Assertions.hasEnsuredPredicate(randInt);
		Assertions.mustBeInAcceptingState(secureRandom0);

		int keylength = 0;
		char[] password = null;

		PBEKeySpec pBEKeySpec0 = new PBEKeySpec(password, genSeed, 27694, keylength);
		Assertions.hasEnsuredPredicate(pBEKeySpec0);

		SecretKeyFactory secretKeyFactory0 = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA512");
		SecretKey secretKey = secretKeyFactory0.generateSecret(pBEKeySpec0);
		Assertions.hasEnsuredPredicate(secretKey);
		Assertions.mustBeInAcceptingState(secretKeyFactory0);

		IvParameterSpec ivParameterSpec0 = new IvParameterSpec(genSeed);
		Assertions.hasEnsuredPredicate(ivParameterSpec0);
		Assertions.mustBeInAcceptingState(ivParameterSpec0);

		byte[] plainText = null;

		Cipher cipher0 = Cipher.getInstance("RSA");
		cipher0.init(1, secretKey, ivParameterSpec0);
		byte[] cipherText = cipher0.doFinal(plainText);
		Assertions.hasEnsuredPredicate(cipher0);
		Assertions.mustBeInAcceptingState(cipher0);
		pBEKeySpec0.clearPassword();
		Assertions.mustBeInAcceptingState(pBEKeySpec0);

	}

	@Test
	public void cipherValidTest16()
			throws BadPaddingException, NoSuchPaddingException, InvalidKeySpecException, IllegalBlockSizeException,
			NoSuchAlgorithmException, InvalidKeyException, InvalidAlgorithmParameterException {

		SecureRandom secureRandom0 = SecureRandom.getInstance("SHA1PRNG");
		byte[] genSeed = secureRandom0.generateSeed(0);
		Assertions.hasEnsuredPredicate(randInt);
		Assertions.mustBeInAcceptingState(secureRandom0);

		int keylength = 0;
		char[] password = null;

		PBEKeySpec pBEKeySpec0 = new PBEKeySpec(password, genSeed, 22091, keylength);
		Assertions.hasEnsuredPredicate(pBEKeySpec0);

		SecretKeyFactory secretKeyFactory0 = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA512");
		SecretKey secretKey = secretKeyFactory0.generateSecret(pBEKeySpec0);
		Assertions.hasEnsuredPredicate(secretKey);
		Assertions.mustBeInAcceptingState(secretKeyFactory0);

		AlgorithmParameterGenerator algorithmParameterGenerator0 = AlgorithmParameterGenerator.getInstance("DH");
		algorithmParameterGenerator0.init(1024);
		AlgorithmParameters algorithmParameters = algorithmParameterGenerator0.generateParameters();
		Assertions.hasEnsuredPredicate(algorithmParameters);
		Assertions.mustBeInAcceptingState(algorithmParameterGenerator0);

		byte[] plainText = null;

		Cipher cipher0 = Cipher.getInstance("RSA");
		cipher0.init(1, secretKey, algorithmParameters);
		byte[] cipherText = cipher0.doFinal(plainText);
		Assertions.hasEnsuredPredicate(cipher0);
		Assertions.mustBeInAcceptingState(cipher0);
		pBEKeySpec0.clearPassword();
		Assertions.mustBeInAcceptingState(pBEKeySpec0);

	}

	@Test
	public void cipherValidTest17()
			throws BadPaddingException, NoSuchPaddingException, InvalidKeySpecException, IllegalBlockSizeException,
			NoSuchAlgorithmException, InvalidKeyException, InvalidAlgorithmParameterException {

		SecureRandom secureRandom0 = SecureRandom.getInstance("SHA1PRNG");
		byte[] genSeed = secureRandom0.generateSeed(0);
		Assertions.hasEnsuredPredicate(randInt);
		Assertions.mustBeInAcceptingState(secureRandom0);

		int keylength = 0;
		char[] password = null;

		PBEKeySpec pBEKeySpec0 = new PBEKeySpec(password, genSeed, 29485, keylength);
		Assertions.hasEnsuredPredicate(pBEKeySpec0);

		SecretKeyFactory secretKeyFactory0 = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA512");
		SecretKey secretKey = secretKeyFactory0.generateSecret(pBEKeySpec0);
		Assertions.hasEnsuredPredicate(secretKey);
		Assertions.mustBeInAcceptingState(secretKeyFactory0);

		IvParameterSpec ivParameterSpec0 = new IvParameterSpec(genSeed);
		Assertions.hasEnsuredPredicate(ivParameterSpec0);
		Assertions.mustBeInAcceptingState(ivParameterSpec0);

		byte[] plainText = null;

		Cipher cipher0 = Cipher.getInstance("RSA");
		cipher0.init(1, secretKey, ivParameterSpec0, secureRandom0);
		byte[] cipherText = cipher0.doFinal(plainText);
		Assertions.hasEnsuredPredicate(cipher0);
		Assertions.mustBeInAcceptingState(cipher0);
		pBEKeySpec0.clearPassword();
		Assertions.mustBeInAcceptingState(pBEKeySpec0);

	}

	@Test
	public void cipherValidTest18()
			throws BadPaddingException, NoSuchPaddingException, InvalidKeySpecException, IllegalBlockSizeException,
			NoSuchAlgorithmException, InvalidKeyException, InvalidAlgorithmParameterException {

		SecureRandom secureRandom0 = SecureRandom.getInstance("SHA1PRNG");
		byte[] genSeed = secureRandom0.generateSeed(0);
		Assertions.hasEnsuredPredicate(randInt);
		Assertions.mustBeInAcceptingState(secureRandom0);

		int keylength = 0;
		char[] password = null;

		PBEKeySpec pBEKeySpec0 = new PBEKeySpec(password, genSeed, 22918, keylength);
		Assertions.hasEnsuredPredicate(pBEKeySpec0);

		SecretKeyFactory secretKeyFactory0 = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA512");
		SecretKey secretKey = secretKeyFactory0.generateSecret(pBEKeySpec0);
		Assertions.hasEnsuredPredicate(secretKey);
		Assertions.mustBeInAcceptingState(secretKeyFactory0);

		AlgorithmParameterGenerator algorithmParameterGenerator0 = AlgorithmParameterGenerator.getInstance("DH");
		algorithmParameterGenerator0.init(1024);
		AlgorithmParameters algorithmParameters = algorithmParameterGenerator0.generateParameters();
		Assertions.hasEnsuredPredicate(algorithmParameters);
		Assertions.mustBeInAcceptingState(algorithmParameterGenerator0);

		byte[] plainText = null;

		Cipher cipher0 = Cipher.getInstance("RSA");
		cipher0.init(1, secretKey, algorithmParameters, secureRandom0);
		byte[] cipherText = cipher0.doFinal(plainText);
		Assertions.hasEnsuredPredicate(cipher0);
		Assertions.mustBeInAcceptingState(cipher0);
		pBEKeySpec0.clearPassword();
		Assertions.mustBeInAcceptingState(pBEKeySpec0);

	}

	@Test
	public void cipherValidTest19() throws BadPaddingException, NoSuchPaddingException, IllegalBlockSizeException,
			NoSuchAlgorithmException, InvalidKeyException {

		int plain_off = 0;
		Certificate cert = null;
		byte[] plainText = null;
		int len = 0;

		Cipher cipher0 = Cipher.getInstance("RSA");
		cipher0.init(1, cert);
		byte[] cipherText = cipher0.doFinal(plainText, plain_off, len);
		Assertions.hasEnsuredPredicate(cipher0);
		Assertions.mustBeInAcceptingState(cipher0);

	}

	@Test
	public void cipherValidTest20() throws BadPaddingException, NoSuchPaddingException, IllegalBlockSizeException,
			NoSuchAlgorithmException, InvalidKeyException, ShortBufferException {

		byte[] cipherText = null;
		int plain_off = 0;
		Certificate cert = null;
		byte[] plainText = null;
		int len = 0;

		Cipher cipher0 = Cipher.getInstance("RSA");
		cipher0.init(1, cert);
		cipher0.doFinal(plainText, plain_off, len, cipherText);
		Assertions.hasEnsuredPredicate(cipher0);
		Assertions.mustBeInAcceptingState(cipher0);

	}

	@Test
	public void cipherValidTest21() throws BadPaddingException, NoSuchPaddingException, IllegalBlockSizeException,
			NoSuchAlgorithmException, InvalidKeyException, ShortBufferException {

		byte[] cipherText = null;
		int plain_off = 0;
		Certificate cert = null;
		byte[] plainText = null;
		int len = 0;
		int ciphertext_off = 0;

		Cipher cipher0 = Cipher.getInstance("RSA");
		cipher0.init(1, cert);
		cipher0.doFinal(plainText, plain_off, len, cipherText, ciphertext_off);
		Assertions.hasEnsuredPredicate(cipher0);
		Assertions.mustBeInAcceptingState(cipher0);

	}

	@Test
	public void cipherValidTest22() throws BadPaddingException, NoSuchPaddingException, IllegalBlockSizeException,
			NoSuchAlgorithmException, InvalidKeyException, ShortBufferException {

		ByteBuffer plainBuffer = null;
		Certificate cert = null;
		ByteBuffer cipherBuffer = null;

		Cipher cipher0 = Cipher.getInstance("RSA");
		cipher0.init(1, cert);
		cipher0.doFinal(plainBuffer, cipherBuffer);
		Assertions.hasEnsuredPredicate(cipher0);
		Assertions.mustBeInAcceptingState(cipher0);

	}

	@Test
	public void cipherValidTest23() throws BadPaddingException, NoSuchPaddingException, IllegalBlockSizeException,
			NoSuchAlgorithmException, InvalidKeyException {

		Certificate cert = null;
		byte[] plainText = null;
		byte[] pre_plaintext = null;

		Cipher cipher0 = Cipher.getInstance("RSA");
		cipher0.init(1, cert);
		byte[] pre_ciphertext = cipher0.update(pre_plaintext);
		byte[] cipherText = cipher0.doFinal(plainText);
		Assertions.hasEnsuredPredicate(cipher0);
		Assertions.mustBeInAcceptingState(cipher0);

	}

	@Test
	public void cipherValidTest24() throws BadPaddingException, NoSuchPaddingException, IllegalBlockSizeException,
			NoSuchAlgorithmException, InvalidKeyException, NoSuchProviderException {

		Certificate cert = null;
		byte[] plainText = null;
		byte[] pre_plaintext = null;

		Cipher cipher0 = Cipher.getInstance("RSA", (Provider) null);
		cipher0.init(1, cert);
		byte[] pre_ciphertext = cipher0.update(pre_plaintext);
		byte[] cipherText = cipher0.doFinal(plainText);
		Assertions.hasEnsuredPredicate(cipher0);
		Assertions.mustBeInAcceptingState(cipher0);

	}

	@Test
	public void cipherValidTest25() throws BadPaddingException, NoSuchPaddingException, IllegalBlockSizeException,
			NoSuchAlgorithmException, InvalidKeyException {

		SecureRandom secureRandom0 = SecureRandom.getInstance("SHA1PRNG");
		Assertions.hasEnsuredPredicate(secureRandom0);
		Assertions.mustBeInAcceptingState(secureRandom0);

		Certificate cert = null;
		byte[] plainText = null;
		byte[] pre_plaintext = null;

		Cipher cipher0 = Cipher.getInstance("RSA");
		cipher0.init(1, cert, secureRandom0);
		byte[] pre_ciphertext = cipher0.update(pre_plaintext);
		byte[] cipherText = cipher0.doFinal(plainText);
		Assertions.hasEnsuredPredicate(cipher0);
		Assertions.mustBeInAcceptingState(cipher0);

	}

	@Test
	public void cipherValidTest26() throws BadPaddingException, NoSuchPaddingException, InvalidKeySpecException,
			IllegalBlockSizeException, NoSuchAlgorithmException, InvalidKeyException {

		SecureRandom secureRandom0 = SecureRandom.getInstance("SHA1PRNG");
		byte[] genSeed = secureRandom0.generateSeed(0);
		Assertions.hasEnsuredPredicate(randInt);
		Assertions.mustBeInAcceptingState(secureRandom0);

		int keylength = 0;
		char[] password = null;

		PBEKeySpec pBEKeySpec0 = new PBEKeySpec(password, genSeed, 26802, keylength);
		Assertions.hasEnsuredPredicate(pBEKeySpec0);

		SecretKeyFactory secretKeyFactory0 = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA512");
		SecretKey secretKey = secretKeyFactory0.generateSecret(pBEKeySpec0);
		Assertions.hasEnsuredPredicate(secretKey);
		Assertions.mustBeInAcceptingState(secretKeyFactory0);

		byte[] plainText = null;
		byte[] pre_plaintext = null;

		Cipher cipher0 = Cipher.getInstance("RSA");
		cipher0.init(1, secretKey);
		byte[] pre_ciphertext = cipher0.update(pre_plaintext);
		byte[] cipherText = cipher0.doFinal(plainText);
		Assertions.hasEnsuredPredicate(cipher0);
		Assertions.mustBeInAcceptingState(cipher0);
		pBEKeySpec0.clearPassword();
		Assertions.mustBeInAcceptingState(pBEKeySpec0);

	}

	@Test
	public void cipherValidTest27() throws BadPaddingException, NoSuchPaddingException, InvalidKeySpecException,
			IllegalBlockSizeException, NoSuchAlgorithmException, InvalidKeyException {

		SecureRandom secureRandom0 = SecureRandom.getInstance("SHA1PRNG");
		byte[] genSeed = secureRandom0.generateSeed(0);
		Assertions.hasEnsuredPredicate(randInt);
		Assertions.mustBeInAcceptingState(secureRandom0);

		int keylength = 0;
		char[] password = null;

		PBEKeySpec pBEKeySpec0 = new PBEKeySpec(password, genSeed, 20149, keylength);
		Assertions.hasEnsuredPredicate(pBEKeySpec0);

		SecretKeyFactory secretKeyFactory0 = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA512");
		SecretKey secretKey = secretKeyFactory0.generateSecret(pBEKeySpec0);
		Assertions.hasEnsuredPredicate(secretKey);
		Assertions.mustBeInAcceptingState(secretKeyFactory0);

		byte[] plainText = null;
		byte[] pre_plaintext = null;

		Cipher cipher0 = Cipher.getInstance("RSA");
		cipher0.init(1, secretKey, secureRandom0);
		byte[] pre_ciphertext = cipher0.update(pre_plaintext);
		byte[] cipherText = cipher0.doFinal(plainText);
		Assertions.hasEnsuredPredicate(cipher0);
		Assertions.mustBeInAcceptingState(cipher0);
		pBEKeySpec0.clearPassword();
		Assertions.mustBeInAcceptingState(pBEKeySpec0);

	}

	@Test
	public void cipherValidTest28()
			throws BadPaddingException, NoSuchPaddingException, InvalidKeySpecException, IllegalBlockSizeException,
			NoSuchAlgorithmException, InvalidKeyException, InvalidAlgorithmParameterException {

		SecureRandom secureRandom0 = SecureRandom.getInstance("SHA1PRNG");
		byte[] genSeed = secureRandom0.generateSeed(0);
		Assertions.hasEnsuredPredicate(randInt);
		Assertions.mustBeInAcceptingState(secureRandom0);

		int keylength = 0;
		char[] password = null;

		PBEKeySpec pBEKeySpec0 = new PBEKeySpec(password, genSeed, 18806, keylength);
		Assertions.hasEnsuredPredicate(pBEKeySpec0);

		SecretKeyFactory secretKeyFactory0 = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA512");
		SecretKey secretKey = secretKeyFactory0.generateSecret(pBEKeySpec0);
		Assertions.hasEnsuredPredicate(secretKey);
		Assertions.mustBeInAcceptingState(secretKeyFactory0);

		IvParameterSpec ivParameterSpec0 = new IvParameterSpec(genSeed);
		Assertions.hasEnsuredPredicate(ivParameterSpec0);
		Assertions.mustBeInAcceptingState(ivParameterSpec0);

		byte[] plainText = null;
		byte[] pre_plaintext = null;

		Cipher cipher0 = Cipher.getInstance("RSA");
		cipher0.init(1, secretKey, ivParameterSpec0);
		byte[] pre_ciphertext = cipher0.update(pre_plaintext);
		byte[] cipherText = cipher0.doFinal(plainText);
		Assertions.hasEnsuredPredicate(cipher0);
		Assertions.mustBeInAcceptingState(cipher0);
		pBEKeySpec0.clearPassword();
		Assertions.mustBeInAcceptingState(pBEKeySpec0);

	}

	@Test
	public void cipherValidTest29()
			throws BadPaddingException, NoSuchPaddingException, InvalidKeySpecException, IllegalBlockSizeException,
			NoSuchAlgorithmException, InvalidKeyException, InvalidAlgorithmParameterException {

		SecureRandom secureRandom0 = SecureRandom.getInstance("SHA1PRNG");
		byte[] genSeed = secureRandom0.generateSeed(0);
		Assertions.hasEnsuredPredicate(randInt);
		Assertions.mustBeInAcceptingState(secureRandom0);

		int keylength = 0;
		char[] password = null;

		PBEKeySpec pBEKeySpec0 = new PBEKeySpec(password, genSeed, 11805, keylength);
		Assertions.hasEnsuredPredicate(pBEKeySpec0);

		SecretKeyFactory secretKeyFactory0 = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA512");
		SecretKey secretKey = secretKeyFactory0.generateSecret(pBEKeySpec0);
		Assertions.hasEnsuredPredicate(secretKey);
		Assertions.mustBeInAcceptingState(secretKeyFactory0);

		AlgorithmParameterGenerator algorithmParameterGenerator0 = AlgorithmParameterGenerator.getInstance("DH");
		algorithmParameterGenerator0.init(1024);
		AlgorithmParameters algorithmParameters = algorithmParameterGenerator0.generateParameters();
		Assertions.hasEnsuredPredicate(algorithmParameters);
		Assertions.mustBeInAcceptingState(algorithmParameterGenerator0);

		byte[] plainText = null;
		byte[] pre_plaintext = null;

		Cipher cipher0 = Cipher.getInstance("RSA");
		cipher0.init(1, secretKey, algorithmParameters);
		byte[] pre_ciphertext = cipher0.update(pre_plaintext);
		byte[] cipherText = cipher0.doFinal(plainText);
		Assertions.hasEnsuredPredicate(cipher0);
		Assertions.mustBeInAcceptingState(cipher0);
		pBEKeySpec0.clearPassword();
		Assertions.mustBeInAcceptingState(pBEKeySpec0);

	}

	@Test
	public void cipherValidTest30()
			throws BadPaddingException, NoSuchPaddingException, InvalidKeySpecException, IllegalBlockSizeException,
			NoSuchAlgorithmException, InvalidKeyException, InvalidAlgorithmParameterException {

		SecureRandom secureRandom0 = SecureRandom.getInstance("SHA1PRNG");
		byte[] genSeed = secureRandom0.generateSeed(0);
		Assertions.hasEnsuredPredicate(randInt);
		Assertions.mustBeInAcceptingState(secureRandom0);

		int keylength = 0;
		char[] password = null;

		PBEKeySpec pBEKeySpec0 = new PBEKeySpec(password, genSeed, 27346, keylength);
		Assertions.hasEnsuredPredicate(pBEKeySpec0);

		SecretKeyFactory secretKeyFactory0 = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA512");
		SecretKey secretKey = secretKeyFactory0.generateSecret(pBEKeySpec0);
		Assertions.hasEnsuredPredicate(secretKey);
		Assertions.mustBeInAcceptingState(secretKeyFactory0);

		IvParameterSpec ivParameterSpec0 = new IvParameterSpec(genSeed);
		Assertions.hasEnsuredPredicate(ivParameterSpec0);
		Assertions.mustBeInAcceptingState(ivParameterSpec0);

		byte[] plainText = null;
		byte[] pre_plaintext = null;

		Cipher cipher0 = Cipher.getInstance("RSA");
		cipher0.init(1, secretKey, ivParameterSpec0, secureRandom0);
		byte[] pre_ciphertext = cipher0.update(pre_plaintext);
		byte[] cipherText = cipher0.doFinal(plainText);
		Assertions.hasEnsuredPredicate(cipher0);
		Assertions.mustBeInAcceptingState(cipher0);
		pBEKeySpec0.clearPassword();
		Assertions.mustBeInAcceptingState(pBEKeySpec0);

	}

	@Test
	public void cipherValidTest31()
			throws BadPaddingException, NoSuchPaddingException, InvalidKeySpecException, IllegalBlockSizeException,
			NoSuchAlgorithmException, InvalidKeyException, InvalidAlgorithmParameterException {

		SecureRandom secureRandom0 = SecureRandom.getInstance("SHA1PRNG");
		byte[] genSeed = secureRandom0.generateSeed(0);
		Assertions.hasEnsuredPredicate(randInt);
		Assertions.mustBeInAcceptingState(secureRandom0);

		int keylength = 0;
		char[] password = null;

		PBEKeySpec pBEKeySpec0 = new PBEKeySpec(password, genSeed, 13780, keylength);
		Assertions.hasEnsuredPredicate(pBEKeySpec0);

		SecretKeyFactory secretKeyFactory0 = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA512");
		SecretKey secretKey = secretKeyFactory0.generateSecret(pBEKeySpec0);
		Assertions.hasEnsuredPredicate(secretKey);
		Assertions.mustBeInAcceptingState(secretKeyFactory0);

		AlgorithmParameterGenerator algorithmParameterGenerator0 = AlgorithmParameterGenerator.getInstance("DH");
		algorithmParameterGenerator0.init(1024);
		AlgorithmParameters algorithmParameters = algorithmParameterGenerator0.generateParameters();
		Assertions.hasEnsuredPredicate(algorithmParameters);
		Assertions.mustBeInAcceptingState(algorithmParameterGenerator0);

		byte[] plainText = null;
		byte[] pre_plaintext = null;

		Cipher cipher0 = Cipher.getInstance("RSA");
		cipher0.init(1, secretKey, algorithmParameters, secureRandom0);
		byte[] pre_ciphertext = cipher0.update(pre_plaintext);
		byte[] cipherText = cipher0.doFinal(plainText);
		Assertions.hasEnsuredPredicate(cipher0);
		Assertions.mustBeInAcceptingState(cipher0);
		pBEKeySpec0.clearPassword();
		Assertions.mustBeInAcceptingState(pBEKeySpec0);

	}

	@Test
	public void cipherValidTest32() throws BadPaddingException, NoSuchPaddingException, IllegalBlockSizeException,
			NoSuchAlgorithmException, InvalidKeyException {

		Certificate cert = null;
		byte[] plainText = null;
		byte[] pre_plaintext = null;
		int pre_plain_off = 0;

		Cipher cipher0 = Cipher.getInstance("RSA");
		cipher0.init(1, cert);
		byte[] pre_ciphertext = cipher0.update(pre_plaintext, pre_plain_off, 0);
		byte[] cipherText = cipher0.doFinal(plainText);
		Assertions.hasEnsuredPredicate(cipher0);
		Assertions.mustBeInAcceptingState(cipher0);

	}

	@Test
	public void cipherValidTest33() throws BadPaddingException, NoSuchPaddingException, IllegalBlockSizeException,
			NoSuchAlgorithmException, InvalidKeyException, ShortBufferException {

		Certificate cert = null;
		int pre_len = 0;
		byte[] plainText = null;
		byte[] pre_ciphertext = null;
		byte[] pre_plaintext = null;
		int pre_plain_off = 0;

		Cipher cipher0 = Cipher.getInstance("RSA");
		cipher0.init(1, cert);
		cipher0.update(pre_plaintext, pre_plain_off, pre_len, pre_ciphertext);
		byte[] cipherText = cipher0.doFinal(plainText);
		Assertions.hasEnsuredPredicate(cipher0);
		Assertions.mustBeInAcceptingState(cipher0);

	}

	@Test
	public void cipherValidTest34() throws BadPaddingException, NoSuchPaddingException, IllegalBlockSizeException,
			NoSuchAlgorithmException, InvalidKeyException, ShortBufferException {

		int pre_ciphertext_off = 0;
		Certificate cert = null;
		int pre_len = 0;
		byte[] plainText = null;
		byte[] pre_ciphertext = null;
		byte[] pre_plaintext = null;
		int pre_plain_off = 0;

		Cipher cipher0 = Cipher.getInstance("RSA");
		cipher0.init(1, cert);
		cipher0.update(pre_plaintext, pre_plain_off, pre_len, pre_ciphertext, pre_ciphertext_off);
		byte[] cipherText = cipher0.doFinal(plainText);
		Assertions.hasEnsuredPredicate(cipher0);
		Assertions.mustBeInAcceptingState(cipher0);

	}

	@Test
	public void cipherValidTest35() throws BadPaddingException, NoSuchPaddingException, IllegalBlockSizeException,
			NoSuchAlgorithmException, InvalidKeyException, ShortBufferException {

		ByteBuffer pre_plainBuffer = null;
		Certificate cert = null;
		byte[] plainText = null;
		ByteBuffer pre_cipherBuffer = null;

		Cipher cipher0 = Cipher.getInstance("RSA");
		cipher0.init(1, cert);
		cipher0.update(pre_plainBuffer, pre_cipherBuffer);
		byte[] cipherText = cipher0.doFinal(plainText);
		Assertions.hasEnsuredPredicate(cipher0);
		Assertions.mustBeInAcceptingState(cipher0);

	}

	@Test
	public void cipherValidTest36() throws BadPaddingException, NoSuchPaddingException, IllegalBlockSizeException,
			NoSuchAlgorithmException, InvalidKeyException {

		int plain_off = 0;
		Certificate cert = null;
		byte[] plainText = null;
		int len = 0;
		byte[] pre_plaintext = null;

		Cipher cipher0 = Cipher.getInstance("RSA");
		cipher0.init(1, cert);
		byte[] pre_ciphertext = cipher0.update(pre_plaintext);
		byte[] cipherText = cipher0.doFinal(plainText, plain_off, len);
		Assertions.hasEnsuredPredicate(cipher0);
		Assertions.mustBeInAcceptingState(cipher0);

	}

	@Test
	public void cipherValidTest37() throws BadPaddingException, NoSuchPaddingException, IllegalBlockSizeException,
			NoSuchAlgorithmException, InvalidKeyException, ShortBufferException {

		byte[] cipherText = null;
		int plain_off = 0;
		Certificate cert = null;
		byte[] plainText = null;
		int len = 0;
		byte[] pre_plaintext = null;

		Cipher cipher0 = Cipher.getInstance("RSA");
		cipher0.init(1, cert);
		byte[] pre_ciphertext = cipher0.update(pre_plaintext);
		cipher0.doFinal(plainText, plain_off, len, cipherText);
		Assertions.hasEnsuredPredicate(cipher0);
		Assertions.mustBeInAcceptingState(cipher0);

	}

	@Test
	public void cipherValidTest38() throws BadPaddingException, NoSuchPaddingException, IllegalBlockSizeException,
			NoSuchAlgorithmException, InvalidKeyException, ShortBufferException {

		byte[] cipherText = null;
		int plain_off = 0;
		Certificate cert = null;
		byte[] plainText = null;
		int len = 0;
		byte[] pre_plaintext = null;
		int ciphertext_off = 0;

		Cipher cipher0 = Cipher.getInstance("RSA");
		cipher0.init(1, cert);
		byte[] pre_ciphertext = cipher0.update(pre_plaintext);
		cipher0.doFinal(plainText, plain_off, len, cipherText, ciphertext_off);
		Assertions.hasEnsuredPredicate(cipher0);
		Assertions.mustBeInAcceptingState(cipher0);

	}

	@Test
	public void cipherValidTest39() throws BadPaddingException, NoSuchPaddingException, IllegalBlockSizeException,
			NoSuchAlgorithmException, InvalidKeyException, ShortBufferException {

		ByteBuffer plainBuffer = null;
		Certificate cert = null;
		ByteBuffer cipherBuffer = null;
		byte[] pre_plaintext = null;

		Cipher cipher0 = Cipher.getInstance("RSA");
		cipher0.init(1, cert);
		byte[] pre_ciphertext = cipher0.update(pre_plaintext);
		cipher0.doFinal(plainBuffer, cipherBuffer);
		Assertions.hasEnsuredPredicate(cipher0);
		Assertions.mustBeInAcceptingState(cipher0);

	}

	@Test
	public void cipherValidTest40() throws BadPaddingException, NoSuchPaddingException, IllegalBlockSizeException,
			NoSuchAlgorithmException, InvalidKeyException {

		Certificate cert = null;
		byte[] pre_plaintext = null;

		Cipher cipher0 = Cipher.getInstance("RSA");
		cipher0.init(1, cert);
		byte[] pre_ciphertext = cipher0.update(pre_plaintext);
		byte[] cipherText = cipher0.doFinal();
		Assertions.hasEnsuredPredicate(cipher0);
		Assertions.mustBeInAcceptingState(cipher0);

	}

	@Test
	public void cipherValidTest41() throws BadPaddingException, NoSuchPaddingException, IllegalBlockSizeException,
			NoSuchAlgorithmException, InvalidKeyException, ShortBufferException {

		byte[] cipherText = null;
		Certificate cert = null;
		byte[] pre_plaintext = null;
		int ciphertext_off = 0;

		Cipher cipher0 = Cipher.getInstance("RSA");
		cipher0.init(1, cert);
		byte[] pre_ciphertext = cipher0.update(pre_plaintext);
		cipher0.doFinal(cipherText, ciphertext_off);
		Assertions.hasEnsuredPredicate(cipher0);
		Assertions.mustBeInAcceptingState(cipher0);

	}

	@Test
	public void cipherInvalidTest1() throws NoSuchPaddingException, NoSuchAlgorithmException {

		Cipher cipher0 = Cipher.getInstance("RSA");
		Assertions.notHasEnsuredPredicate(cipher0);
		Assertions.mustNotBeInAcceptingState(cipher0);

	}

	@Test
	public void cipherInvalidTest2() throws NoSuchPaddingException, NoSuchAlgorithmException, NoSuchProviderException {

		Cipher cipher0 = Cipher.getInstance("RSA", (Provider) null);
		Assertions.notHasEnsuredPredicate(cipher0);
		Assertions.mustNotBeInAcceptingState(cipher0);

	}

	@Test
	public void cipherInvalidTest3() throws NoSuchPaddingException, NoSuchAlgorithmException, InvalidKeyException {

		Certificate cert = null;

		Cipher cipher0 = Cipher.getInstance("RSA");
		cipher0.init(1, cert);
		Assertions.hasEnsuredPredicate(cipher0);
		Assertions.mustNotBeInAcceptingState(cipher0);

	}

	@Test
	public void cipherInvalidTest4()
			throws NoSuchPaddingException, NoSuchAlgorithmException, InvalidKeyException, NoSuchProviderException {

		Certificate cert = null;

		Cipher cipher0 = Cipher.getInstance("RSA", (Provider) null);
		cipher0.init(1, cert);
		Assertions.hasEnsuredPredicate(cipher0);
		Assertions.mustNotBeInAcceptingState(cipher0);

	}

	@Test
	public void cipherInvalidTest5() throws NoSuchPaddingException, NoSuchAlgorithmException, InvalidKeyException {

		SecureRandom secureRandom0 = SecureRandom.getInstance("SHA1PRNG");
		Assertions.hasEnsuredPredicate(secureRandom0);
		Assertions.mustBeInAcceptingState(secureRandom0);

		Certificate cert = null;

		Cipher cipher0 = Cipher.getInstance("RSA");
		cipher0.init(1, cert, secureRandom0);
		Assertions.hasEnsuredPredicate(cipher0);
		Assertions.mustNotBeInAcceptingState(cipher0);

	}

	@Test
	public void cipherInvalidTest6()
			throws NoSuchPaddingException, InvalidKeySpecException, NoSuchAlgorithmException, InvalidKeyException {

		SecureRandom secureRandom0 = SecureRandom.getInstance("SHA1PRNG");
		byte[] genSeed = secureRandom0.generateSeed(0);
		Assertions.hasEnsuredPredicate(randInt);
		Assertions.mustBeInAcceptingState(secureRandom0);

		int keylength = 0;
		char[] password = null;

		PBEKeySpec pBEKeySpec0 = new PBEKeySpec(password, genSeed, 27567, keylength);
		Assertions.hasEnsuredPredicate(pBEKeySpec0);

		SecretKeyFactory secretKeyFactory0 = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA512");
		SecretKey secretKey = secretKeyFactory0.generateSecret(pBEKeySpec0);
		Assertions.hasEnsuredPredicate(secretKey);
		Assertions.mustBeInAcceptingState(secretKeyFactory0);

		Cipher cipher0 = Cipher.getInstance("RSA");
		cipher0.init(1, secretKey);
		Assertions.hasEnsuredPredicate(cipher0);
		Assertions.mustNotBeInAcceptingState(cipher0);
		pBEKeySpec0.clearPassword();
		Assertions.mustBeInAcceptingState(pBEKeySpec0);

	}

	@Test
	public void cipherInvalidTest7()
			throws NoSuchPaddingException, InvalidKeySpecException, NoSuchAlgorithmException, InvalidKeyException {

		SecureRandom secureRandom0 = SecureRandom.getInstance("SHA1PRNG");
		byte[] genSeed = secureRandom0.generateSeed(0);
		Assertions.hasEnsuredPredicate(randInt);
		Assertions.mustBeInAcceptingState(secureRandom0);

		int keylength = 0;
		char[] password = null;

		PBEKeySpec pBEKeySpec0 = new PBEKeySpec(password, genSeed, 11322, keylength);
		Assertions.hasEnsuredPredicate(pBEKeySpec0);

		SecretKeyFactory secretKeyFactory0 = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA512");
		SecretKey secretKey = secretKeyFactory0.generateSecret(pBEKeySpec0);
		Assertions.hasEnsuredPredicate(secretKey);
		Assertions.mustBeInAcceptingState(secretKeyFactory0);

		Cipher cipher0 = Cipher.getInstance("RSA");
		cipher0.init(1, secretKey, secureRandom0);
		Assertions.hasEnsuredPredicate(cipher0);
		Assertions.mustNotBeInAcceptingState(cipher0);
		pBEKeySpec0.clearPassword();
		Assertions.mustBeInAcceptingState(pBEKeySpec0);

	}

	@Test
	public void cipherInvalidTest8() throws NoSuchPaddingException, InvalidKeySpecException, NoSuchAlgorithmException,
			InvalidKeyException, InvalidAlgorithmParameterException {

		SecureRandom secureRandom0 = SecureRandom.getInstance("SHA1PRNG");
		byte[] genSeed = secureRandom0.generateSeed(0);
		Assertions.hasEnsuredPredicate(randInt);
		Assertions.mustBeInAcceptingState(secureRandom0);

		int keylength = 0;
		char[] password = null;

		PBEKeySpec pBEKeySpec0 = new PBEKeySpec(password, genSeed, 23238, keylength);
		Assertions.hasEnsuredPredicate(pBEKeySpec0);

		SecretKeyFactory secretKeyFactory0 = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA512");
		SecretKey secretKey = secretKeyFactory0.generateSecret(pBEKeySpec0);
		Assertions.hasEnsuredPredicate(secretKey);
		Assertions.mustBeInAcceptingState(secretKeyFactory0);

		IvParameterSpec ivParameterSpec0 = new IvParameterSpec(genSeed);
		Assertions.hasEnsuredPredicate(ivParameterSpec0);
		Assertions.mustBeInAcceptingState(ivParameterSpec0);

		Cipher cipher0 = Cipher.getInstance("RSA");
		cipher0.init(1, secretKey, ivParameterSpec0);
		Assertions.hasEnsuredPredicate(cipher0);
		Assertions.mustNotBeInAcceptingState(cipher0);
		pBEKeySpec0.clearPassword();
		Assertions.mustBeInAcceptingState(pBEKeySpec0);

	}

	@Test
	public void cipherInvalidTest9() throws NoSuchPaddingException, InvalidKeySpecException, NoSuchAlgorithmException,
			InvalidKeyException, InvalidAlgorithmParameterException {

		SecureRandom secureRandom0 = SecureRandom.getInstance("SHA1PRNG");
		byte[] genSeed = secureRandom0.generateSeed(0);
		Assertions.hasEnsuredPredicate(randInt);
		Assertions.mustBeInAcceptingState(secureRandom0);

		int keylength = 0;
		char[] password = null;

		PBEKeySpec pBEKeySpec0 = new PBEKeySpec(password, genSeed, 13587, keylength);
		Assertions.hasEnsuredPredicate(pBEKeySpec0);

		SecretKeyFactory secretKeyFactory0 = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA512");
		SecretKey secretKey = secretKeyFactory0.generateSecret(pBEKeySpec0);
		Assertions.hasEnsuredPredicate(secretKey);
		Assertions.mustBeInAcceptingState(secretKeyFactory0);

		AlgorithmParameterGenerator algorithmParameterGenerator0 = AlgorithmParameterGenerator.getInstance("DH");
		algorithmParameterGenerator0.init(1024);
		AlgorithmParameters algorithmParameters = algorithmParameterGenerator0.generateParameters();
		Assertions.hasEnsuredPredicate(algorithmParameters);
		Assertions.mustBeInAcceptingState(algorithmParameterGenerator0);

		Cipher cipher0 = Cipher.getInstance("RSA");
		cipher0.init(1, secretKey, algorithmParameters);
		Assertions.hasEnsuredPredicate(cipher0);
		Assertions.mustNotBeInAcceptingState(cipher0);
		pBEKeySpec0.clearPassword();
		Assertions.mustBeInAcceptingState(pBEKeySpec0);

	}

	@Test
	public void cipherInvalidTest10() throws NoSuchPaddingException, InvalidKeySpecException, NoSuchAlgorithmException,
			InvalidKeyException, InvalidAlgorithmParameterException {

		SecureRandom secureRandom0 = SecureRandom.getInstance("SHA1PRNG");
		byte[] genSeed = secureRandom0.generateSeed(0);
		Assertions.hasEnsuredPredicate(randInt);
		Assertions.mustBeInAcceptingState(secureRandom0);

		int keylength = 0;
		char[] password = null;

		PBEKeySpec pBEKeySpec0 = new PBEKeySpec(password, genSeed, 16147, keylength);
		Assertions.hasEnsuredPredicate(pBEKeySpec0);

		SecretKeyFactory secretKeyFactory0 = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA512");
		SecretKey secretKey = secretKeyFactory0.generateSecret(pBEKeySpec0);
		Assertions.hasEnsuredPredicate(secretKey);
		Assertions.mustBeInAcceptingState(secretKeyFactory0);

		IvParameterSpec ivParameterSpec0 = new IvParameterSpec(genSeed);
		Assertions.hasEnsuredPredicate(ivParameterSpec0);
		Assertions.mustBeInAcceptingState(ivParameterSpec0);

		Cipher cipher0 = Cipher.getInstance("RSA");
		cipher0.init(1, secretKey, ivParameterSpec0, secureRandom0);
		Assertions.hasEnsuredPredicate(cipher0);
		Assertions.mustNotBeInAcceptingState(cipher0);
		pBEKeySpec0.clearPassword();
		Assertions.mustBeInAcceptingState(pBEKeySpec0);

	}

	@Test
	public void cipherInvalidTest11() throws NoSuchPaddingException, InvalidKeySpecException, NoSuchAlgorithmException,
			InvalidKeyException, InvalidAlgorithmParameterException {

		SecureRandom secureRandom0 = SecureRandom.getInstance("SHA1PRNG");
		byte[] genSeed = secureRandom0.generateSeed(0);
		Assertions.hasEnsuredPredicate(randInt);
		Assertions.mustBeInAcceptingState(secureRandom0);

		int keylength = 0;
		char[] password = null;

		PBEKeySpec pBEKeySpec0 = new PBEKeySpec(password, genSeed, 27378, keylength);
		Assertions.hasEnsuredPredicate(pBEKeySpec0);

		SecretKeyFactory secretKeyFactory0 = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA512");
		SecretKey secretKey = secretKeyFactory0.generateSecret(pBEKeySpec0);
		Assertions.hasEnsuredPredicate(secretKey);
		Assertions.mustBeInAcceptingState(secretKeyFactory0);

		AlgorithmParameterGenerator algorithmParameterGenerator0 = AlgorithmParameterGenerator.getInstance("DH");
		algorithmParameterGenerator0.init(1024);
		AlgorithmParameters algorithmParameters = algorithmParameterGenerator0.generateParameters();
		Assertions.hasEnsuredPredicate(algorithmParameters);
		Assertions.mustBeInAcceptingState(algorithmParameterGenerator0);

		Cipher cipher0 = Cipher.getInstance("RSA");
		cipher0.init(1, secretKey, algorithmParameters, secureRandom0);
		Assertions.hasEnsuredPredicate(cipher0);
		Assertions.mustNotBeInAcceptingState(cipher0);
		pBEKeySpec0.clearPassword();
		Assertions.mustBeInAcceptingState(pBEKeySpec0);

	}

	@Test
	public void cipherInvalidTest12()
			throws NoSuchPaddingException, IllegalBlockSizeException, NoSuchAlgorithmException, InvalidKeyException {

		Key wrappedKey = null;

		Cipher cipher0 = Cipher.getInstance("RSA");
		byte[] wrappedKeyBytes = cipher0.wrap(wrappedKey);
		Assertions.notHasEnsuredPredicate(wrappedKeyBytes);
		Assertions.mustNotBeInAcceptingState(cipher0);

	}

	@Test
	public void cipherInvalidTest13() throws NoSuchPaddingException, IllegalBlockSizeException,
			NoSuchAlgorithmException, InvalidKeyException, NoSuchProviderException {

		Key wrappedKey = null;

		Cipher cipher0 = Cipher.getInstance("RSA", (Provider) null);
		byte[] wrappedKeyBytes = cipher0.wrap(wrappedKey);
		Assertions.notHasEnsuredPredicate(wrappedKeyBytes);
		Assertions.mustNotBeInAcceptingState(cipher0);

	}

	@Test
	public void cipherInvalidTest14()
			throws BadPaddingException, NoSuchPaddingException, IllegalBlockSizeException, NoSuchAlgorithmException {

		byte[] plainText = null;

		Cipher cipher0 = Cipher.getInstance("RSA");
		byte[] cipherText = cipher0.doFinal(plainText);
		Assertions.notHasEnsuredPredicate(cipherText);
		Assertions.mustNotBeInAcceptingState(cipher0);

	}

	@Test
	public void cipherInvalidTest15() throws BadPaddingException, NoSuchPaddingException, IllegalBlockSizeException,
			NoSuchAlgorithmException, NoSuchProviderException {

		byte[] plainText = null;

		Cipher cipher0 = Cipher.getInstance("RSA", (Provider) null);
		byte[] cipherText = cipher0.doFinal(plainText);
		Assertions.notHasEnsuredPredicate(cipherText);
		Assertions.mustNotBeInAcceptingState(cipher0);

	}

	@Test
	public void cipherInvalidTest16()
			throws BadPaddingException, NoSuchPaddingException, IllegalBlockSizeException, NoSuchAlgorithmException {

		int plain_off = 0;
		byte[] plainText = null;
		int len = 0;

		Cipher cipher0 = Cipher.getInstance("RSA");
		byte[] cipherText = cipher0.doFinal(plainText, plain_off, len);
		Assertions.notHasEnsuredPredicate(cipherText);
		Assertions.mustNotBeInAcceptingState(cipher0);

	}

	@Test
	public void cipherInvalidTest17() throws BadPaddingException, NoSuchPaddingException, IllegalBlockSizeException,
			NoSuchAlgorithmException, ShortBufferException {

		byte[] cipherText = null;
		int plain_off = 0;
		byte[] plainText = null;
		int len = 0;

		Cipher cipher0 = Cipher.getInstance("RSA");
		cipher0.doFinal(plainText, plain_off, len, cipherText);
		Assertions.notHasEnsuredPredicate(cipherText);
		Assertions.mustNotBeInAcceptingState(cipher0);

	}

	@Test
	public void cipherInvalidTest18() throws BadPaddingException, NoSuchPaddingException, IllegalBlockSizeException,
			NoSuchAlgorithmException, ShortBufferException {

		byte[] cipherText = null;
		int plain_off = 0;
		byte[] plainText = null;
		int len = 0;
		int ciphertext_off = 0;

		Cipher cipher0 = Cipher.getInstance("RSA");
		cipher0.doFinal(plainText, plain_off, len, cipherText, ciphertext_off);
		Assertions.notHasEnsuredPredicate(cipherText);
		Assertions.mustNotBeInAcceptingState(cipher0);

	}

	@Test
	public void cipherInvalidTest19() throws BadPaddingException, NoSuchPaddingException, IllegalBlockSizeException,
			NoSuchAlgorithmException, ShortBufferException {

		ByteBuffer plainBuffer = null;
		ByteBuffer cipherBuffer = null;

		Cipher cipher0 = Cipher.getInstance("RSA");
		cipher0.doFinal(plainBuffer, cipherBuffer);
		Assertions.notHasEnsuredPredicate(cipherBuffer);
		Assertions.mustNotBeInAcceptingState(cipher0);

	}

	@Test
	public void cipherInvalidTest20() throws NoSuchPaddingException, NoSuchAlgorithmException, InvalidKeyException {

		Certificate cert = null;
		byte[] pre_plaintext = null;

		Cipher cipher0 = Cipher.getInstance("RSA");
		cipher0.init(1, cert);
		byte[] pre_ciphertext = cipher0.update(pre_plaintext);
		Assertions.hasEnsuredPredicate(cipher0);
		Assertions.mustNotBeInAcceptingState(cipher0);

	}

	@Test
	public void cipherInvalidTest21()
			throws NoSuchPaddingException, NoSuchAlgorithmException, InvalidKeyException, NoSuchProviderException {

		Certificate cert = null;
		byte[] pre_plaintext = null;

		Cipher cipher0 = Cipher.getInstance("RSA", (Provider) null);
		cipher0.init(1, cert);
		byte[] pre_ciphertext = cipher0.update(pre_plaintext);
		Assertions.hasEnsuredPredicate(cipher0);
		Assertions.mustNotBeInAcceptingState(cipher0);

	}

	@Test
	public void cipherInvalidTest22() throws NoSuchPaddingException, NoSuchAlgorithmException, InvalidKeyException {

		SecureRandom secureRandom0 = SecureRandom.getInstance("SHA1PRNG");
		Assertions.hasEnsuredPredicate(secureRandom0);
		Assertions.mustBeInAcceptingState(secureRandom0);

		Certificate cert = null;
		byte[] pre_plaintext = null;

		Cipher cipher0 = Cipher.getInstance("RSA");
		cipher0.init(1, cert, secureRandom0);
		byte[] pre_ciphertext = cipher0.update(pre_plaintext);
		Assertions.hasEnsuredPredicate(cipher0);
		Assertions.mustNotBeInAcceptingState(cipher0);

	}

	@Test
	public void cipherInvalidTest23()
			throws NoSuchPaddingException, InvalidKeySpecException, NoSuchAlgorithmException, InvalidKeyException {

		SecureRandom secureRandom0 = SecureRandom.getInstance("SHA1PRNG");
		byte[] genSeed = secureRandom0.generateSeed(0);
		Assertions.hasEnsuredPredicate(randInt);
		Assertions.mustBeInAcceptingState(secureRandom0);

		int keylength = 0;
		char[] password = null;

		PBEKeySpec pBEKeySpec0 = new PBEKeySpec(password, genSeed, 19213, keylength);
		Assertions.hasEnsuredPredicate(pBEKeySpec0);

		SecretKeyFactory secretKeyFactory0 = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA512");
		SecretKey secretKey = secretKeyFactory0.generateSecret(pBEKeySpec0);
		Assertions.hasEnsuredPredicate(secretKey);
		Assertions.mustBeInAcceptingState(secretKeyFactory0);

		byte[] pre_plaintext = null;

		Cipher cipher0 = Cipher.getInstance("RSA");
		cipher0.init(1, secretKey);
		byte[] pre_ciphertext = cipher0.update(pre_plaintext);
		Assertions.hasEnsuredPredicate(cipher0);
		Assertions.mustNotBeInAcceptingState(cipher0);
		pBEKeySpec0.clearPassword();
		Assertions.mustBeInAcceptingState(pBEKeySpec0);

	}

	@Test
	public void cipherInvalidTest24()
			throws NoSuchPaddingException, InvalidKeySpecException, NoSuchAlgorithmException, InvalidKeyException {

		SecureRandom secureRandom0 = SecureRandom.getInstance("SHA1PRNG");
		byte[] genSeed = secureRandom0.generateSeed(0);
		Assertions.hasEnsuredPredicate(randInt);
		Assertions.mustBeInAcceptingState(secureRandom0);

		int keylength = 0;
		char[] password = null;

		PBEKeySpec pBEKeySpec0 = new PBEKeySpec(password, genSeed, 25984, keylength);
		Assertions.hasEnsuredPredicate(pBEKeySpec0);

		SecretKeyFactory secretKeyFactory0 = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA512");
		SecretKey secretKey = secretKeyFactory0.generateSecret(pBEKeySpec0);
		Assertions.hasEnsuredPredicate(secretKey);
		Assertions.mustBeInAcceptingState(secretKeyFactory0);

		byte[] pre_plaintext = null;

		Cipher cipher0 = Cipher.getInstance("RSA");
		cipher0.init(1, secretKey, secureRandom0);
		byte[] pre_ciphertext = cipher0.update(pre_plaintext);
		Assertions.hasEnsuredPredicate(cipher0);
		Assertions.mustNotBeInAcceptingState(cipher0);
		pBEKeySpec0.clearPassword();
		Assertions.mustBeInAcceptingState(pBEKeySpec0);

	}

	@Test
	public void cipherInvalidTest25() throws NoSuchPaddingException, InvalidKeySpecException, NoSuchAlgorithmException,
			InvalidKeyException, InvalidAlgorithmParameterException {

		SecureRandom secureRandom0 = SecureRandom.getInstance("SHA1PRNG");
		byte[] genSeed = secureRandom0.generateSeed(0);
		Assertions.hasEnsuredPredicate(randInt);
		Assertions.mustBeInAcceptingState(secureRandom0);

		int keylength = 0;
		char[] password = null;

		PBEKeySpec pBEKeySpec0 = new PBEKeySpec(password, genSeed, 22876, keylength);
		Assertions.hasEnsuredPredicate(pBEKeySpec0);

		SecretKeyFactory secretKeyFactory0 = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA512");
		SecretKey secretKey = secretKeyFactory0.generateSecret(pBEKeySpec0);
		Assertions.hasEnsuredPredicate(secretKey);
		Assertions.mustBeInAcceptingState(secretKeyFactory0);

		IvParameterSpec ivParameterSpec0 = new IvParameterSpec(genSeed);
		Assertions.hasEnsuredPredicate(ivParameterSpec0);
		Assertions.mustBeInAcceptingState(ivParameterSpec0);

		byte[] pre_plaintext = null;

		Cipher cipher0 = Cipher.getInstance("RSA");
		cipher0.init(1, secretKey, ivParameterSpec0);
		byte[] pre_ciphertext = cipher0.update(pre_plaintext);
		Assertions.hasEnsuredPredicate(cipher0);
		Assertions.mustNotBeInAcceptingState(cipher0);
		pBEKeySpec0.clearPassword();
		Assertions.mustBeInAcceptingState(pBEKeySpec0);

	}

	@Test
	public void cipherInvalidTest26() throws NoSuchPaddingException, InvalidKeySpecException, NoSuchAlgorithmException,
			InvalidKeyException, InvalidAlgorithmParameterException {

		SecureRandom secureRandom0 = SecureRandom.getInstance("SHA1PRNG");
		byte[] genSeed = secureRandom0.generateSeed(0);
		Assertions.hasEnsuredPredicate(randInt);
		Assertions.mustBeInAcceptingState(secureRandom0);

		int keylength = 0;
		char[] password = null;

		PBEKeySpec pBEKeySpec0 = new PBEKeySpec(password, genSeed, 28694, keylength);
		Assertions.hasEnsuredPredicate(pBEKeySpec0);

		SecretKeyFactory secretKeyFactory0 = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA512");
		SecretKey secretKey = secretKeyFactory0.generateSecret(pBEKeySpec0);
		Assertions.hasEnsuredPredicate(secretKey);
		Assertions.mustBeInAcceptingState(secretKeyFactory0);

		AlgorithmParameterGenerator algorithmParameterGenerator0 = AlgorithmParameterGenerator.getInstance("DH");
		algorithmParameterGenerator0.init(1024);
		AlgorithmParameters algorithmParameters = algorithmParameterGenerator0.generateParameters();
		Assertions.hasEnsuredPredicate(algorithmParameters);
		Assertions.mustBeInAcceptingState(algorithmParameterGenerator0);

		byte[] pre_plaintext = null;

		Cipher cipher0 = Cipher.getInstance("RSA");
		cipher0.init(1, secretKey, algorithmParameters);
		byte[] pre_ciphertext = cipher0.update(pre_plaintext);
		Assertions.hasEnsuredPredicate(cipher0);
		Assertions.mustNotBeInAcceptingState(cipher0);
		pBEKeySpec0.clearPassword();
		Assertions.mustBeInAcceptingState(pBEKeySpec0);

	}

	@Test
	public void cipherInvalidTest27() throws NoSuchPaddingException, InvalidKeySpecException, NoSuchAlgorithmException,
			InvalidKeyException, InvalidAlgorithmParameterException {

		SecureRandom secureRandom0 = SecureRandom.getInstance("SHA1PRNG");
		byte[] genSeed = secureRandom0.generateSeed(0);
		Assertions.hasEnsuredPredicate(randInt);
		Assertions.mustBeInAcceptingState(secureRandom0);

		int keylength = 0;
		char[] password = null;

		PBEKeySpec pBEKeySpec0 = new PBEKeySpec(password, genSeed, 28708, keylength);
		Assertions.hasEnsuredPredicate(pBEKeySpec0);

		SecretKeyFactory secretKeyFactory0 = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA512");
		SecretKey secretKey = secretKeyFactory0.generateSecret(pBEKeySpec0);
		Assertions.hasEnsuredPredicate(secretKey);
		Assertions.mustBeInAcceptingState(secretKeyFactory0);

		IvParameterSpec ivParameterSpec0 = new IvParameterSpec(genSeed);
		Assertions.hasEnsuredPredicate(ivParameterSpec0);
		Assertions.mustBeInAcceptingState(ivParameterSpec0);

		byte[] pre_plaintext = null;

		Cipher cipher0 = Cipher.getInstance("RSA");
		cipher0.init(1, secretKey, ivParameterSpec0, secureRandom0);
		byte[] pre_ciphertext = cipher0.update(pre_plaintext);
		Assertions.hasEnsuredPredicate(cipher0);
		Assertions.mustNotBeInAcceptingState(cipher0);
		pBEKeySpec0.clearPassword();
		Assertions.mustBeInAcceptingState(pBEKeySpec0);

	}

	@Test
	public void cipherInvalidTest28() throws NoSuchPaddingException, InvalidKeySpecException, NoSuchAlgorithmException,
			InvalidKeyException, InvalidAlgorithmParameterException {

		SecureRandom secureRandom0 = SecureRandom.getInstance("SHA1PRNG");
		byte[] genSeed = secureRandom0.generateSeed(0);
		Assertions.hasEnsuredPredicate(randInt);
		Assertions.mustBeInAcceptingState(secureRandom0);

		int keylength = 0;
		char[] password = null;

		PBEKeySpec pBEKeySpec0 = new PBEKeySpec(password, genSeed, 29040, keylength);
		Assertions.hasEnsuredPredicate(pBEKeySpec0);

		SecretKeyFactory secretKeyFactory0 = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA512");
		SecretKey secretKey = secretKeyFactory0.generateSecret(pBEKeySpec0);
		Assertions.hasEnsuredPredicate(secretKey);
		Assertions.mustBeInAcceptingState(secretKeyFactory0);

		AlgorithmParameterGenerator algorithmParameterGenerator0 = AlgorithmParameterGenerator.getInstance("DH");
		algorithmParameterGenerator0.init(1024);
		AlgorithmParameters algorithmParameters = algorithmParameterGenerator0.generateParameters();
		Assertions.hasEnsuredPredicate(algorithmParameters);
		Assertions.mustBeInAcceptingState(algorithmParameterGenerator0);

		byte[] pre_plaintext = null;

		Cipher cipher0 = Cipher.getInstance("RSA");
		cipher0.init(1, secretKey, algorithmParameters, secureRandom0);
		byte[] pre_ciphertext = cipher0.update(pre_plaintext);
		Assertions.hasEnsuredPredicate(cipher0);
		Assertions.mustNotBeInAcceptingState(cipher0);
		pBEKeySpec0.clearPassword();
		Assertions.mustBeInAcceptingState(pBEKeySpec0);

	}

	@Test
	public void cipherInvalidTest29() throws NoSuchPaddingException, NoSuchAlgorithmException, InvalidKeyException {

		Certificate cert = null;
		byte[] pre_plaintext = null;
		int pre_plain_off = 0;

		Cipher cipher0 = Cipher.getInstance("RSA");
		cipher0.init(1, cert);
		byte[] pre_ciphertext = cipher0.update(pre_plaintext, pre_plain_off, 0);
		Assertions.hasEnsuredPredicate(cipher0);
		Assertions.mustNotBeInAcceptingState(cipher0);

	}

	@Test
	public void cipherInvalidTest30()
			throws NoSuchPaddingException, NoSuchAlgorithmException, InvalidKeyException, ShortBufferException {

		Certificate cert = null;
		int pre_len = 0;
		byte[] pre_ciphertext = null;
		byte[] pre_plaintext = null;
		int pre_plain_off = 0;

		Cipher cipher0 = Cipher.getInstance("RSA");
		cipher0.init(1, cert);
		cipher0.update(pre_plaintext, pre_plain_off, pre_len, pre_ciphertext);
		Assertions.hasEnsuredPredicate(cipher0);
		Assertions.mustNotBeInAcceptingState(cipher0);

	}

	@Test
	public void cipherInvalidTest31()
			throws NoSuchPaddingException, NoSuchAlgorithmException, InvalidKeyException, ShortBufferException {

		int pre_ciphertext_off = 0;
		Certificate cert = null;
		int pre_len = 0;
		byte[] pre_ciphertext = null;
		byte[] pre_plaintext = null;
		int pre_plain_off = 0;

		Cipher cipher0 = Cipher.getInstance("RSA");
		cipher0.init(1, cert);
		cipher0.update(pre_plaintext, pre_plain_off, pre_len, pre_ciphertext, pre_ciphertext_off);
		Assertions.hasEnsuredPredicate(cipher0);
		Assertions.mustNotBeInAcceptingState(cipher0);

	}

	@Test
	public void cipherInvalidTest32()
			throws NoSuchPaddingException, NoSuchAlgorithmException, InvalidKeyException, ShortBufferException {

		ByteBuffer pre_plainBuffer = null;
		Certificate cert = null;
		ByteBuffer pre_cipherBuffer = null;

		Cipher cipher0 = Cipher.getInstance("RSA");
		cipher0.init(1, cert);
		cipher0.update(pre_plainBuffer, pre_cipherBuffer);
		Assertions.hasEnsuredPredicate(cipher0);
		Assertions.mustNotBeInAcceptingState(cipher0);

	}

	@Test
	public void cipherInvalidTest33()
			throws BadPaddingException, NoSuchPaddingException, IllegalBlockSizeException, NoSuchAlgorithmException {

		byte[] plainText = null;
		byte[] pre_plaintext = null;

		Cipher cipher0 = Cipher.getInstance("RSA");
		byte[] pre_ciphertext = cipher0.update(pre_plaintext);
		byte[] cipherText = cipher0.doFinal(plainText);
		Assertions.notHasEnsuredPredicate(cipherText);
		Assertions.mustNotBeInAcceptingState(cipher0);

	}

	@Test
	public void cipherInvalidTest34() throws BadPaddingException, NoSuchPaddingException, IllegalBlockSizeException,
			NoSuchAlgorithmException, NoSuchProviderException {

		byte[] plainText = null;
		byte[] pre_plaintext = null;

		Cipher cipher0 = Cipher.getInstance("RSA", (Provider) null);
		byte[] pre_ciphertext = cipher0.update(pre_plaintext);
		byte[] cipherText = cipher0.doFinal(plainText);
		Assertions.notHasEnsuredPredicate(cipherText);
		Assertions.mustNotBeInAcceptingState(cipher0);

	}

	@Test
	public void cipherInvalidTest35()
			throws BadPaddingException, NoSuchPaddingException, IllegalBlockSizeException, NoSuchAlgorithmException {

		byte[] plainText = null;
		byte[] pre_plaintext = null;
		int pre_plain_off = 0;

		Cipher cipher0 = Cipher.getInstance("RSA");
		byte[] pre_ciphertext = cipher0.update(pre_plaintext, pre_plain_off, 0);
		byte[] cipherText = cipher0.doFinal(plainText);
		Assertions.notHasEnsuredPredicate(cipherText);
		Assertions.mustNotBeInAcceptingState(cipher0);

	}

	@Test
	public void cipherInvalidTest36() throws BadPaddingException, NoSuchPaddingException, IllegalBlockSizeException,
			NoSuchAlgorithmException, ShortBufferException {

		int pre_len = 0;
		byte[] plainText = null;
		byte[] pre_ciphertext = null;
		byte[] pre_plaintext = null;
		int pre_plain_off = 0;

		Cipher cipher0 = Cipher.getInstance("RSA");
		cipher0.update(pre_plaintext, pre_plain_off, pre_len, pre_ciphertext);
		byte[] cipherText = cipher0.doFinal(plainText);
		Assertions.notHasEnsuredPredicate(cipherText);
		Assertions.mustNotBeInAcceptingState(cipher0);

	}

	@Test
	public void cipherInvalidTest37() throws BadPaddingException, NoSuchPaddingException, IllegalBlockSizeException,
			NoSuchAlgorithmException, ShortBufferException {

		int pre_ciphertext_off = 0;
		int pre_len = 0;
		byte[] plainText = null;
		byte[] pre_ciphertext = null;
		byte[] pre_plaintext = null;
		int pre_plain_off = 0;

		Cipher cipher0 = Cipher.getInstance("RSA");
		cipher0.update(pre_plaintext, pre_plain_off, pre_len, pre_ciphertext, pre_ciphertext_off);
		byte[] cipherText = cipher0.doFinal(plainText);
		Assertions.notHasEnsuredPredicate(cipherText);
		Assertions.mustNotBeInAcceptingState(cipher0);

	}

	@Test
	public void cipherInvalidTest38() throws BadPaddingException, NoSuchPaddingException, IllegalBlockSizeException,
			NoSuchAlgorithmException, ShortBufferException {

		ByteBuffer pre_plainBuffer = null;
		byte[] plainText = null;
		ByteBuffer pre_cipherBuffer = null;

		Cipher cipher0 = Cipher.getInstance("RSA");
		cipher0.update(pre_plainBuffer, pre_cipherBuffer);
		byte[] cipherText = cipher0.doFinal(plainText);
		Assertions.notHasEnsuredPredicate(cipherText);
		Assertions.mustNotBeInAcceptingState(cipher0);

	}

	@Test
	public void cipherInvalidTest39()
			throws BadPaddingException, NoSuchPaddingException, IllegalBlockSizeException, NoSuchAlgorithmException {

		int plain_off = 0;
		byte[] plainText = null;
		int len = 0;
		byte[] pre_plaintext = null;

		Cipher cipher0 = Cipher.getInstance("RSA");
		byte[] pre_ciphertext = cipher0.update(pre_plaintext);
		byte[] cipherText = cipher0.doFinal(plainText, plain_off, len);
		Assertions.notHasEnsuredPredicate(cipherText);
		Assertions.mustNotBeInAcceptingState(cipher0);

	}

	@Test
	public void cipherInvalidTest40() throws BadPaddingException, NoSuchPaddingException, IllegalBlockSizeException,
			NoSuchAlgorithmException, ShortBufferException {

		byte[] cipherText = null;
		int plain_off = 0;
		byte[] plainText = null;
		int len = 0;
		byte[] pre_plaintext = null;

		Cipher cipher0 = Cipher.getInstance("RSA");
		byte[] pre_ciphertext = cipher0.update(pre_plaintext);
		cipher0.doFinal(plainText, plain_off, len, cipherText);
		Assertions.notHasEnsuredPredicate(cipherText);
		Assertions.mustNotBeInAcceptingState(cipher0);

	}

	@Test
	public void cipherInvalidTest41() throws BadPaddingException, NoSuchPaddingException, IllegalBlockSizeException,
			NoSuchAlgorithmException, ShortBufferException {

		byte[] cipherText = null;
		int plain_off = 0;
		byte[] plainText = null;
		int len = 0;
		byte[] pre_plaintext = null;
		int ciphertext_off = 0;

		Cipher cipher0 = Cipher.getInstance("RSA");
		byte[] pre_ciphertext = cipher0.update(pre_plaintext);
		cipher0.doFinal(plainText, plain_off, len, cipherText, ciphertext_off);
		Assertions.notHasEnsuredPredicate(cipherText);
		Assertions.mustNotBeInAcceptingState(cipher0);

	}

	@Test
	public void cipherInvalidTest42() throws BadPaddingException, NoSuchPaddingException, IllegalBlockSizeException,
			NoSuchAlgorithmException, ShortBufferException {

		ByteBuffer plainBuffer = null;
		ByteBuffer cipherBuffer = null;
		byte[] pre_plaintext = null;

		Cipher cipher0 = Cipher.getInstance("RSA");
		byte[] pre_ciphertext = cipher0.update(pre_plaintext);
		cipher0.doFinal(plainBuffer, cipherBuffer);
		Assertions.notHasEnsuredPredicate(cipherBuffer);
		Assertions.mustNotBeInAcceptingState(cipher0);

	}

	@Test
	public void cipherInvalidTest43()
			throws BadPaddingException, NoSuchPaddingException, IllegalBlockSizeException, NoSuchAlgorithmException {

		byte[] pre_plaintext = null;

		Cipher cipher0 = Cipher.getInstance("RSA");
		byte[] pre_ciphertext = cipher0.update(pre_plaintext);
		byte[] cipherText = cipher0.doFinal();
		Assertions.notHasEnsuredPredicate(cipherText);
		Assertions.mustNotBeInAcceptingState(cipher0);

	}

	@Test
	public void cipherInvalidTest44() throws BadPaddingException, NoSuchPaddingException, IllegalBlockSizeException,
			NoSuchAlgorithmException, ShortBufferException {

		byte[] cipherText = null;
		byte[] pre_plaintext = null;
		int ciphertext_off = 0;

		Cipher cipher0 = Cipher.getInstance("RSA");
		byte[] pre_ciphertext = cipher0.update(pre_plaintext);
		cipher0.doFinal(cipherText, ciphertext_off);
		Assertions.notHasEnsuredPredicate(cipherText);
		Assertions.mustNotBeInAcceptingState(cipher0);

	}
}