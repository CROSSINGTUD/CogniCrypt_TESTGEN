package jca;

import java.security.SecureRandom;
import test.assertions.Assertions;
import crypto.analysis.CrySLRulesetSelector.Ruleset;
import java.security.NoSuchAlgorithmException;
import org.junit.Test;
import javax.crypto.spec.PBEParameterSpec;
import java.security.spec.AlgorithmParameterSpec;
import test.UsagePatternTestingFramework;

public class PBEParameterSpecTest extends UsagePatternTestingFramework {
	protected Ruleset getRuleSet() {
		return Ruleset.JavaCryptographicArchitecture;

	}

	@Test
	public void pBEParameterSpecValidTest1() throws NoSuchAlgorithmException {

		SecureRandom secureRandom0 = SecureRandom.getInstance("SHA1PRNG");
		byte[] genSeed = secureRandom0.generateSeed(0);
		Assertions.hasEnsuredPredicate(randInt);
		Assertions.mustBeInAcceptingState(secureRandom0);

		PBEParameterSpec pBEParameterSpec0 = new PBEParameterSpec(genSeed, 17501);
		Assertions.hasEnsuredPredicate(pBEParameterSpec0);
		Assertions.mustBeInAcceptingState(pBEParameterSpec0);

	}

	@Test
	public void pBEParameterSpecValidTest2() throws NoSuchAlgorithmException {

		SecureRandom secureRandom0 = SecureRandom.getInstance("SHA1PRNG");
		byte[] genSeed = secureRandom0.generateSeed(0);
		Assertions.hasEnsuredPredicate(randInt);
		Assertions.mustBeInAcceptingState(secureRandom0);

		AlgorithmParameterSpec paramSpec = null;

		PBEParameterSpec pBEParameterSpec0 = new PBEParameterSpec(genSeed, 29328, paramSpec);
		Assertions.hasEnsuredPredicate(pBEParameterSpec0);
		Assertions.mustBeInAcceptingState(pBEParameterSpec0);

	}
}