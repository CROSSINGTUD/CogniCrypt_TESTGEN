package jca;

import java.security.SecureRandom;
import test.assertions.Assertions;
import java.security.AlgorithmParameterGenerator;
import crypto.analysis.CrySLRulesetSelector.Ruleset;
import java.security.NoSuchAlgorithmException;
import org.junit.Test;
import java.lang.String;
import java.security.spec.AlgorithmParameterSpec;
import test.UsagePatternTestingFramework;
import java.security.NoSuchProviderException;
import java.security.AlgorithmParameters;
import java.security.InvalidAlgorithmParameterException;

public class AlgorithmParameterGeneratorTest extends UsagePatternTestingFramework {
	protected Ruleset getRuleSet() {
		return Ruleset.JavaCryptographicArchitecture;

	}

	@Test
	public void algorithmParameterGeneratorValidTest1() throws NoSuchAlgorithmException {

		AlgorithmParameterGenerator algorithmParameterGenerator0 = AlgorithmParameterGenerator.getInstance("DH");
		algorithmParameterGenerator0.init(1024);
		AlgorithmParameters algorithmParameters = algorithmParameterGenerator0.generateParameters();
		Assertions.hasEnsuredPredicate(algorithmParameters);
		Assertions.mustBeInAcceptingState(algorithmParameterGenerator0);

	}

	@Test
	public void algorithmParameterGeneratorValidTest2() throws NoSuchAlgorithmException, NoSuchProviderException {

		AlgorithmParameterGenerator algorithmParameterGenerator0 = AlgorithmParameterGenerator.getInstance("DH",
				(String) null);
		algorithmParameterGenerator0.init(1024);
		AlgorithmParameters algorithmParameters = algorithmParameterGenerator0.generateParameters();
		Assertions.hasEnsuredPredicate(algorithmParameters);
		Assertions.mustBeInAcceptingState(algorithmParameterGenerator0);

	}

	@Test
	public void algorithmParameterGeneratorValidTest3() throws NoSuchAlgorithmException {

		SecureRandom secureRandom0 = SecureRandom.getInstance("SHA1PRNG");
		Assertions.hasEnsuredPredicate(secureRandom0);
		Assertions.mustBeInAcceptingState(secureRandom0);

		AlgorithmParameterGenerator algorithmParameterGenerator0 = AlgorithmParameterGenerator.getInstance("DH");
		algorithmParameterGenerator0.init(1024, secureRandom0);
		AlgorithmParameters algorithmParameters = algorithmParameterGenerator0.generateParameters();
		Assertions.hasEnsuredPredicate(algorithmParameters);
		Assertions.mustBeInAcceptingState(algorithmParameterGenerator0);

	}

	@Test
	public void algorithmParameterGeneratorValidTest4()
			throws NoSuchAlgorithmException, InvalidAlgorithmParameterException {

		AlgorithmParameterSpec genParamSpec = null;

		AlgorithmParameterGenerator algorithmParameterGenerator0 = AlgorithmParameterGenerator.getInstance("DH");
		algorithmParameterGenerator0.init(genParamSpec);
		AlgorithmParameters algorithmParameters = algorithmParameterGenerator0.generateParameters();
		Assertions.hasEnsuredPredicate(algorithmParameters);
		Assertions.mustBeInAcceptingState(algorithmParameterGenerator0);

	}

	@Test
	public void algorithmParameterGeneratorValidTest5()
			throws NoSuchAlgorithmException, InvalidAlgorithmParameterException {

		SecureRandom secureRandom0 = SecureRandom.getInstance("SHA1PRNG");
		Assertions.hasEnsuredPredicate(secureRandom0);
		Assertions.mustBeInAcceptingState(secureRandom0);

		AlgorithmParameterSpec genParamSpec = null;

		AlgorithmParameterGenerator algorithmParameterGenerator0 = AlgorithmParameterGenerator.getInstance("DH");
		algorithmParameterGenerator0.init(genParamSpec, secureRandom0);
		AlgorithmParameters algorithmParameters = algorithmParameterGenerator0.generateParameters();
		Assertions.hasEnsuredPredicate(algorithmParameters);
		Assertions.mustBeInAcceptingState(algorithmParameterGenerator0);

	}

	@Test
	public void algorithmParameterGeneratorInvalidTest1() throws NoSuchAlgorithmException {

		AlgorithmParameterGenerator algorithmParameterGenerator0 = AlgorithmParameterGenerator.getInstance("DH");
		Assertions.mustNotBeInAcceptingState(algorithmParameterGenerator0);

	}

	@Test
	public void algorithmParameterGeneratorInvalidTest2() throws NoSuchAlgorithmException, NoSuchProviderException {

		AlgorithmParameterGenerator algorithmParameterGenerator0 = AlgorithmParameterGenerator.getInstance("DH",
				(String) null);
		Assertions.mustNotBeInAcceptingState(algorithmParameterGenerator0);

	}

	@Test
	public void algorithmParameterGeneratorInvalidTest3() throws NoSuchAlgorithmException {

		AlgorithmParameterGenerator algorithmParameterGenerator0 = AlgorithmParameterGenerator.getInstance("DH");
		algorithmParameterGenerator0.init(1024);
		Assertions.mustNotBeInAcceptingState(algorithmParameterGenerator0);

	}

	@Test
	public void algorithmParameterGeneratorInvalidTest4() throws NoSuchAlgorithmException, NoSuchProviderException {

		AlgorithmParameterGenerator algorithmParameterGenerator0 = AlgorithmParameterGenerator.getInstance("DH",
				(String) null);
		algorithmParameterGenerator0.init(1024);
		Assertions.mustNotBeInAcceptingState(algorithmParameterGenerator0);

	}

	@Test
	public void algorithmParameterGeneratorInvalidTest5() throws NoSuchAlgorithmException {

		SecureRandom secureRandom0 = SecureRandom.getInstance("SHA1PRNG");
		Assertions.hasEnsuredPredicate(secureRandom0);
		Assertions.mustBeInAcceptingState(secureRandom0);

		AlgorithmParameterGenerator algorithmParameterGenerator0 = AlgorithmParameterGenerator.getInstance("DH");
		algorithmParameterGenerator0.init(1024, secureRandom0);
		Assertions.mustNotBeInAcceptingState(algorithmParameterGenerator0);

	}

	@Test
	public void algorithmParameterGeneratorInvalidTest6()
			throws NoSuchAlgorithmException, InvalidAlgorithmParameterException {

		AlgorithmParameterSpec genParamSpec = null;

		AlgorithmParameterGenerator algorithmParameterGenerator0 = AlgorithmParameterGenerator.getInstance("DH");
		algorithmParameterGenerator0.init(genParamSpec);
		Assertions.mustNotBeInAcceptingState(algorithmParameterGenerator0);

	}

	@Test
	public void algorithmParameterGeneratorInvalidTest7()
			throws NoSuchAlgorithmException, InvalidAlgorithmParameterException {

		SecureRandom secureRandom0 = SecureRandom.getInstance("SHA1PRNG");
		Assertions.hasEnsuredPredicate(secureRandom0);
		Assertions.mustBeInAcceptingState(secureRandom0);

		AlgorithmParameterSpec genParamSpec = null;

		AlgorithmParameterGenerator algorithmParameterGenerator0 = AlgorithmParameterGenerator.getInstance("DH");
		algorithmParameterGenerator0.init(genParamSpec, secureRandom0);
		Assertions.mustNotBeInAcceptingState(algorithmParameterGenerator0);

	}

	@Test
	public void algorithmParameterGeneratorInvalidTest8() throws NoSuchAlgorithmException {

		AlgorithmParameterGenerator algorithmParameterGenerator0 = AlgorithmParameterGenerator.getInstance("DH");
		AlgorithmParameters algorithmParameters = algorithmParameterGenerator0.generateParameters();
		Assertions.notHasEnsuredPredicate(algorithmParameters);
		Assertions.mustNotBeInAcceptingState(algorithmParameterGenerator0);

	}

	@Test
	public void algorithmParameterGeneratorInvalidTest9() throws NoSuchAlgorithmException, NoSuchProviderException {

		AlgorithmParameterGenerator algorithmParameterGenerator0 = AlgorithmParameterGenerator.getInstance("DH",
				(String) null);
		AlgorithmParameters algorithmParameters = algorithmParameterGenerator0.generateParameters();
		Assertions.notHasEnsuredPredicate(algorithmParameters);
		Assertions.mustNotBeInAcceptingState(algorithmParameterGenerator0);

	}
}