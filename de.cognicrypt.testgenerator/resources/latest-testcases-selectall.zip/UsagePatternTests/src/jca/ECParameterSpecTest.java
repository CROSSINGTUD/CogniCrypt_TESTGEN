package jca;

import test.assertions.Assertions;
import crypto.analysis.CrySLRulesetSelector.Ruleset;
import java.security.spec.ECPoint;
import org.junit.Test;
import java.math.BigInteger;
import java.security.spec.EllipticCurve;
import test.UsagePatternTestingFramework;
import java.security.spec.ECParameterSpec;

public class ECParameterSpecTest extends UsagePatternTestingFramework {
	protected Ruleset getRuleSet() {
		return Ruleset.JavaCryptographicArchitecture;

	}

	@Test
	public void eCParameterSpecValidTest1() {

		BigInteger n = null;
		int h = 0;
		EllipticCurve curve = null;
		ECPoint g = null;

		ECParameterSpec eCParameterSpec0 = new ECParameterSpec(curve, g, n, h);
		Assertions.hasEnsuredPredicate(eCParameterSpec0);
		Assertions.mustBeInAcceptingState(eCParameterSpec0);

	}
}