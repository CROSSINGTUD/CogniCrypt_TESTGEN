package jca;

import java.io.OutputStream;
import test.assertions.Assertions;
import crypto.analysis.CrySLRulesetSelector.Ruleset;
import javax.crypto.IllegalBlockSizeException;
import org.junit.Test;
import java.io.IOException;
import javax.crypto.Cipher;
import java.security.Key;
import java.security.cert.Certificate;
import javax.crypto.NoSuchPaddingException;
import java.security.NoSuchAlgorithmException;
import java.security.InvalidKeyException;
import test.UsagePatternTestingFramework;
import javax.crypto.CipherOutputStream;

public class CipherOutputStreamTest extends UsagePatternTestingFramework {
	protected Ruleset getRuleSet() {
		return Ruleset.JavaCryptographicArchitecture;

	}

	@Test
	public void cipherOutputStreamValidTest1() throws NoSuchPaddingException, IllegalBlockSizeException,
			NoSuchAlgorithmException, InvalidKeyException, IOException {

		Certificate cert = null;
		Key wrappedKey = null;

		Cipher cipher0 = Cipher.getInstance("RSA");
		cipher0.init(1, cert);
		byte[] wrappedKeyBytes = cipher0.wrap(wrappedKey);
		Assertions.hasEnsuredPredicate(cipher0);
		Assertions.mustBeInAcceptingState(cipher0);

		int specifiedByte = 0;
		OutputStream os = null;

		CipherOutputStream cipherOutputStream0 = new CipherOutputStream(os, cipher0);
		cipherOutputStream0.write(specifiedByte);
		cipherOutputStream0.close();
		Assertions.hasEnsuredPredicate(os);
		Assertions.mustBeInAcceptingState(cipherOutputStream0);

	}

	@Test
	public void cipherOutputStreamValidTest2() throws NoSuchPaddingException, IllegalBlockSizeException,
			NoSuchAlgorithmException, InvalidKeyException, IOException {

		Certificate cert = null;
		Key wrappedKey = null;

		Cipher cipher0 = Cipher.getInstance("RSA");
		cipher0.init(1, cert);
		byte[] wrappedKeyBytes = cipher0.wrap(wrappedKey);
		Assertions.hasEnsuredPredicate(cipher0);
		Assertions.mustBeInAcceptingState(cipher0);

		OutputStream os = null;
		byte[] data = null;

		CipherOutputStream cipherOutputStream0 = new CipherOutputStream(os, cipher0);
		cipherOutputStream0.write(data);
		cipherOutputStream0.close();
		Assertions.hasEnsuredPredicate(os);
		Assertions.mustBeInAcceptingState(cipherOutputStream0);

	}

	@Test
	public void cipherOutputStreamValidTest3() throws NoSuchPaddingException, IllegalBlockSizeException,
			NoSuchAlgorithmException, InvalidKeyException, IOException {

		Certificate cert = null;
		Key wrappedKey = null;

		Cipher cipher0 = Cipher.getInstance("RSA");
		cipher0.init(1, cert);
		byte[] wrappedKeyBytes = cipher0.wrap(wrappedKey);
		Assertions.hasEnsuredPredicate(cipher0);
		Assertions.mustBeInAcceptingState(cipher0);

		OutputStream os = null;
		byte[] data = null;
		int offset = 0;
		int len = 0;

		CipherOutputStream cipherOutputStream0 = new CipherOutputStream(os, cipher0);
		cipherOutputStream0.write(data, offset, len);
		cipherOutputStream0.close();
		Assertions.hasEnsuredPredicate(os);
		Assertions.mustBeInAcceptingState(cipherOutputStream0);

	}

	@Test
	public void cipherOutputStreamInvalidTest1()
			throws NoSuchPaddingException, IllegalBlockSizeException, NoSuchAlgorithmException, InvalidKeyException {

		Certificate cert = null;
		Key wrappedKey = null;

		Cipher cipher0 = Cipher.getInstance("RSA");
		cipher0.init(1, cert);
		byte[] wrappedKeyBytes = cipher0.wrap(wrappedKey);
		Assertions.hasEnsuredPredicate(cipher0);
		Assertions.mustBeInAcceptingState(cipher0);

		OutputStream os = null;

		CipherOutputStream cipherOutputStream0 = new CipherOutputStream(os, cipher0);
		Assertions.notHasEnsuredPredicate(os);
		Assertions.mustNotBeInAcceptingState(cipherOutputStream0);

	}

	@Test
	public void cipherOutputStreamInvalidTest2() throws NoSuchPaddingException, IllegalBlockSizeException,
			NoSuchAlgorithmException, InvalidKeyException, IOException {

		Certificate cert = null;
		Key wrappedKey = null;

		Cipher cipher0 = Cipher.getInstance("RSA");
		cipher0.init(1, cert);
		byte[] wrappedKeyBytes = cipher0.wrap(wrappedKey);
		Assertions.hasEnsuredPredicate(cipher0);
		Assertions.mustBeInAcceptingState(cipher0);

		int specifiedByte = 0;
		OutputStream os = null;

		CipherOutputStream cipherOutputStream0 = new CipherOutputStream(os, cipher0);
		cipherOutputStream0.write(specifiedByte);
		Assertions.notHasEnsuredPredicate(os);
		Assertions.mustNotBeInAcceptingState(cipherOutputStream0);

	}

	@Test
	public void cipherOutputStreamInvalidTest3() throws NoSuchPaddingException, IllegalBlockSizeException,
			NoSuchAlgorithmException, InvalidKeyException, IOException {

		Certificate cert = null;
		Key wrappedKey = null;

		Cipher cipher0 = Cipher.getInstance("RSA");
		cipher0.init(1, cert);
		byte[] wrappedKeyBytes = cipher0.wrap(wrappedKey);
		Assertions.hasEnsuredPredicate(cipher0);
		Assertions.mustBeInAcceptingState(cipher0);

		OutputStream os = null;
		byte[] data = null;

		CipherOutputStream cipherOutputStream0 = new CipherOutputStream(os, cipher0);
		cipherOutputStream0.write(data);
		Assertions.notHasEnsuredPredicate(os);
		Assertions.mustNotBeInAcceptingState(cipherOutputStream0);

	}

	@Test
	public void cipherOutputStreamInvalidTest4() throws NoSuchPaddingException, IllegalBlockSizeException,
			NoSuchAlgorithmException, InvalidKeyException, IOException {

		Certificate cert = null;
		Key wrappedKey = null;

		Cipher cipher0 = Cipher.getInstance("RSA");
		cipher0.init(1, cert);
		byte[] wrappedKeyBytes = cipher0.wrap(wrappedKey);
		Assertions.hasEnsuredPredicate(cipher0);
		Assertions.mustBeInAcceptingState(cipher0);

		OutputStream os = null;
		byte[] data = null;
		int offset = 0;
		int len = 0;

		CipherOutputStream cipherOutputStream0 = new CipherOutputStream(os, cipher0);
		cipherOutputStream0.write(data, offset, len);
		Assertions.notHasEnsuredPredicate(os);
		Assertions.mustNotBeInAcceptingState(cipherOutputStream0);

	}

	@Test
	public void cipherOutputStreamInvalidTest5() throws NoSuchPaddingException, IllegalBlockSizeException,
			NoSuchAlgorithmException, InvalidKeyException, IOException {

		Certificate cert = null;
		Key wrappedKey = null;

		Cipher cipher0 = Cipher.getInstance("RSA");
		cipher0.init(1, cert);
		byte[] wrappedKeyBytes = cipher0.wrap(wrappedKey);
		Assertions.hasEnsuredPredicate(cipher0);
		Assertions.mustBeInAcceptingState(cipher0);

		OutputStream os = null;

		CipherOutputStream cipherOutputStream0 = new CipherOutputStream(os, cipher0);
		cipherOutputStream0.close();
		Assertions.notHasEnsuredPredicate(os);
		Assertions.mustNotBeInAcceptingState(cipherOutputStream0);

	}
}