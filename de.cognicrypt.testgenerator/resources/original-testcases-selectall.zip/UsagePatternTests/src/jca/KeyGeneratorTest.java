package jca;

import test.assertions.Assertions;
import crypto.analysis.CrySLRulesetSelector.Ruleset;
import java.security.NoSuchAlgorithmException;
import org.junit.Test;
import javax.crypto.SecretKey;
import test.UsagePatternTestingFramework;
import javax.crypto.KeyGenerator;

public class KeyGeneratorTest extends UsagePatternTestingFramework {
	protected Ruleset getRuleSet() {
		return Ruleset.JavaCryptographicArchitecture;

	}

	@Test
	public void keyGeneratorValidTest1() throws NoSuchAlgorithmException {

		KeyGenerator keyGenerator0 = KeyGenerator.getInstance("AES");
		SecretKey secretKey = keyGenerator0.generateKey();
		Assertions.hasEnsuredPredicate(secretKey);
		Assertions.mustBeInAcceptingState(keyGenerator0);

	}

	@Test
	public void keyGeneratorValidTest2() throws NoSuchAlgorithmException {

		KeyGenerator keyGenerator0 = KeyGenerator.getInstance("AES");
		keyGenerator0.init(128);
		SecretKey secretKey = keyGenerator0.generateKey();
		Assertions.hasEnsuredPredicate(secretKey);
		Assertions.mustBeInAcceptingState(keyGenerator0);

	}

	@Test
	public void keyGeneratorInvalidTest1() throws NoSuchAlgorithmException {

		KeyGenerator keyGenerator0 = KeyGenerator.getInstance("AES");
		Assertions.mustNotBeInAcceptingState(keyGenerator0);

	}

	@Test
	public void keyGeneratorInvalidTest2() throws NoSuchAlgorithmException {

		KeyGenerator keyGenerator0 = KeyGenerator.getInstance("AES");
		keyGenerator0.init(128);
		Assertions.mustNotBeInAcceptingState(keyGenerator0);

	}
}