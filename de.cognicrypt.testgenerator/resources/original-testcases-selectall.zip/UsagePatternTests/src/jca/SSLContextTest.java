package jca;

import java.security.SecureRandom;
import javax.net.ssl.SSLContext;
import test.assertions.Assertions;
import crypto.analysis.CrySLRulesetSelector.Ruleset;
import java.security.NoSuchAlgorithmException;
import javax.net.ssl.TrustManager;
import org.junit.Test;
import java.security.KeyManagementException;
import test.UsagePatternTestingFramework;
import javax.net.ssl.KeyManager;
import javax.net.ssl.SSLEngine;

public class SSLContextTest extends UsagePatternTestingFramework {
	protected Ruleset getRuleSet() {
		return Ruleset.JavaCryptographicArchitecture;

	}

	@Test
	public void sSLContextValidTest1() throws NoSuchAlgorithmException, KeyManagementException {

		TrustManager[] tms = null;
		KeyManager[] kms = null;

		SSLContext sSLContext0 = SSLContext.getInstance("TLSv1.2");
		sSLContext0.init(kms, tms, (SecureRandom) null);
		Assertions.hasEnsuredPredicate(sSLContext0);
		Assertions.mustBeInAcceptingState(sSLContext0);

	}

	@Test
	public void sSLContextValidTest2() throws NoSuchAlgorithmException, KeyManagementException {

		TrustManager[] tms = null;
		KeyManager[] kms = null;

		SSLContext sSLContext0 = SSLContext.getInstance("TLSv1.2");
		sSLContext0.init(kms, tms, (SecureRandom) null);
		SSLEngine sSLEngine = sSLContext0.createSSLEngine();
		Assertions.hasEnsuredPredicate(sSLContext0);
		Assertions.mustBeInAcceptingState(sSLContext0);

	}

	@Test
	public void sSLContextInvalidTest1() throws NoSuchAlgorithmException {

		SSLContext sSLContext0 = SSLContext.getInstance("TLSv1.2");
		Assertions.notHasEnsuredPredicate(sSLContext0);
		Assertions.mustNotBeInAcceptingState(sSLContext0);

	}

	@Test
	public void sSLContextInvalidTest2() throws NoSuchAlgorithmException {

		SSLContext sSLContext0 = SSLContext.getInstance("TLSv1.2");
		SSLEngine sSLEngine = sSLContext0.createSSLEngine();
		Assertions.notHasEnsuredPredicate(sSLEngine);
		Assertions.mustNotBeInAcceptingState(sSLContext0);

	}
}