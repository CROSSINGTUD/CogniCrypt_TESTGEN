package jca;

import java.security.SecureRandom;
import test.assertions.Assertions;
import crypto.analysis.CrySLRulesetSelector.Ruleset;
import javax.crypto.spec.IvParameterSpec;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidParameterSpecException;
import org.junit.Test;
import java.io.IOException;
import test.UsagePatternTestingFramework;
import java.security.AlgorithmParameters;

public class AlgorithmParametersTest extends UsagePatternTestingFramework {
	protected Ruleset getRuleSet() {
		return Ruleset.JavaCryptographicArchitecture;

	}

	@Test
	public void algorithmParametersValidTest1() throws NoSuchAlgorithmException, InvalidParameterSpecException {

		SecureRandom secureRandom0 = SecureRandom.getInstance("SHA1PRNG");
		byte[] genSeed = secureRandom0.generateSeed(0);
		Assertions.hasEnsuredPredicate(randInt);
		Assertions.mustBeInAcceptingState(secureRandom0);

		IvParameterSpec ivParameterSpec0 = new IvParameterSpec(genSeed);
		Assertions.hasEnsuredPredicate(ivParameterSpec0);
		Assertions.mustBeInAcceptingState(ivParameterSpec0);

		AlgorithmParameters algorithmParameters0 = AlgorithmParameters.getInstance("AES");
		algorithmParameters0.init(ivParameterSpec0);
		Assertions.hasEnsuredPredicate(algorithmParameters0);
		Assertions.mustBeInAcceptingState(algorithmParameters0);

	}

	@Test
	public void algorithmParametersValidTest2()
			throws NoSuchAlgorithmException, InvalidParameterSpecException, IOException {

		SecureRandom secureRandom0 = SecureRandom.getInstance("SHA1PRNG");
		byte[] genSeed = secureRandom0.generateSeed(0);
		Assertions.hasEnsuredPredicate(randInt);
		Assertions.mustBeInAcceptingState(secureRandom0);

		IvParameterSpec ivParameterSpec0 = new IvParameterSpec(genSeed);
		Assertions.hasEnsuredPredicate(ivParameterSpec0);
		Assertions.mustBeInAcceptingState(ivParameterSpec0);

		AlgorithmParameters algorithmParameters0 = AlgorithmParameters.getInstance("AES");
		algorithmParameters0.init(ivParameterSpec0);
		byte[] parsRes = algorithmParameters0.getEncoded();
		Assertions.hasEnsuredPredicate(parsRes);
		Assertions.mustBeInAcceptingState(algorithmParameters0);

	}

	@Test
	public void algorithmParametersInvalidTest1() throws NoSuchAlgorithmException {

		AlgorithmParameters algorithmParameters0 = AlgorithmParameters.getInstance("AES");
		Assertions.notHasEnsuredPredicate(algorithmParameters0);
		Assertions.mustNotBeInAcceptingState(algorithmParameters0);

	}

	@Test
	public void algorithmParametersInvalidTest2() throws NoSuchAlgorithmException, IOException {

		AlgorithmParameters algorithmParameters0 = AlgorithmParameters.getInstance("AES");
		byte[] parsRes = algorithmParameters0.getEncoded();
		Assertions.notHasEnsuredPredicate(parsRes);
		Assertions.mustNotBeInAcceptingState(algorithmParameters0);

	}
}