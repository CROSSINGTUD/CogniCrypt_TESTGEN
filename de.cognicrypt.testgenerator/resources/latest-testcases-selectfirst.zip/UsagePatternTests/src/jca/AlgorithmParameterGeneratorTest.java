package jca;

import test.assertions.Assertions;
import java.security.AlgorithmParameterGenerator;
import crypto.analysis.CrySLRulesetSelector.Ruleset;
import java.security.NoSuchAlgorithmException;
import org.junit.Test;
import test.UsagePatternTestingFramework;
import java.security.AlgorithmParameters;

public class AlgorithmParameterGeneratorTest extends UsagePatternTestingFramework {
	protected Ruleset getRuleSet() {
		return Ruleset.JavaCryptographicArchitecture;

	}

	@Test
	public void algorithmParameterGeneratorValidTest1() throws NoSuchAlgorithmException {

		AlgorithmParameterGenerator algorithmParameterGenerator0 = AlgorithmParameterGenerator.getInstance("DH");
		algorithmParameterGenerator0.init(1024);
		AlgorithmParameters algorithmParameters = algorithmParameterGenerator0.generateParameters();
		Assertions.hasEnsuredPredicate(algorithmParameters);
		Assertions.mustBeInAcceptingState(algorithmParameterGenerator0);

	}

	@Test
	public void algorithmParameterGeneratorInvalidTest1() throws NoSuchAlgorithmException {

		AlgorithmParameterGenerator algorithmParameterGenerator0 = AlgorithmParameterGenerator.getInstance("DH");
		Assertions.mustNotBeInAcceptingState(algorithmParameterGenerator0);

	}

	@Test
	public void algorithmParameterGeneratorInvalidTest2() throws NoSuchAlgorithmException {

		AlgorithmParameterGenerator algorithmParameterGenerator0 = AlgorithmParameterGenerator.getInstance("DH");
		algorithmParameterGenerator0.init(1024);
		Assertions.mustNotBeInAcceptingState(algorithmParameterGenerator0);

	}

	@Test
	public void algorithmParameterGeneratorInvalidTest3() throws NoSuchAlgorithmException {

		AlgorithmParameterGenerator algorithmParameterGenerator0 = AlgorithmParameterGenerator.getInstance("DH");
		AlgorithmParameters algorithmParameters = algorithmParameterGenerator0.generateParameters();
		Assertions.notHasEnsuredPredicate(algorithmParameters);
		Assertions.mustNotBeInAcceptingState(algorithmParameterGenerator0);

	}
}