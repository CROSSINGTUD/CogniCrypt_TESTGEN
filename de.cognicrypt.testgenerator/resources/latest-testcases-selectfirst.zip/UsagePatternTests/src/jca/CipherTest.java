package jca;

import java.security.Key;
import javax.crypto.BadPaddingException;
import test.assertions.Assertions;
import java.security.cert.Certificate;
import crypto.analysis.CrySLRulesetSelector.Ruleset;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.IllegalBlockSizeException;
import java.security.NoSuchAlgorithmException;
import org.junit.Test;
import java.security.InvalidKeyException;
import test.UsagePatternTestingFramework;
import javax.crypto.Cipher;

public class CipherTest extends UsagePatternTestingFramework {
	protected Ruleset getRuleSet() {
		return Ruleset.JavaCryptographicArchitecture;

	}

	@Test
	public void cipherValidTest1()
			throws NoSuchPaddingException, IllegalBlockSizeException, NoSuchAlgorithmException, InvalidKeyException {

		Certificate cert = null;
		Key wrappedKey = null;

		Cipher cipher0 = Cipher.getInstance("RSA");
		cipher0.init(1, cert);
		byte[] wrappedKeyBytes = cipher0.wrap(wrappedKey);
		Assertions.hasEnsuredPredicate(cipher0);
		Assertions.mustBeInAcceptingState(cipher0);

	}

	@Test
	public void cipherValidTest2() throws BadPaddingException, NoSuchPaddingException, IllegalBlockSizeException,
			NoSuchAlgorithmException, InvalidKeyException {

		Certificate cert = null;
		byte[] plainText = null;

		Cipher cipher0 = Cipher.getInstance("RSA");
		cipher0.init(1, cert);
		byte[] cipherText = cipher0.doFinal(plainText);
		Assertions.hasEnsuredPredicate(cipher0);
		Assertions.mustBeInAcceptingState(cipher0);

	}

	@Test
	public void cipherValidTest3() throws BadPaddingException, NoSuchPaddingException, IllegalBlockSizeException,
			NoSuchAlgorithmException, InvalidKeyException {

		Certificate cert = null;
		byte[] plainText = null;
		byte[] pre_plaintext = null;

		Cipher cipher0 = Cipher.getInstance("RSA");
		cipher0.init(1, cert);
		byte[] pre_ciphertext = cipher0.update(pre_plaintext);
		byte[] cipherText = cipher0.doFinal(plainText);
		Assertions.hasEnsuredPredicate(cipher0);
		Assertions.mustBeInAcceptingState(cipher0);

	}

	@Test
	public void cipherInvalidTest1() throws NoSuchPaddingException, NoSuchAlgorithmException {

		Cipher cipher0 = Cipher.getInstance("RSA");
		Assertions.notHasEnsuredPredicate(cipher0);
		Assertions.mustNotBeInAcceptingState(cipher0);

	}

	@Test
	public void cipherInvalidTest2() throws NoSuchPaddingException, NoSuchAlgorithmException, InvalidKeyException {

		Certificate cert = null;

		Cipher cipher0 = Cipher.getInstance("RSA");
		cipher0.init(1, cert);
		Assertions.hasEnsuredPredicate(cipher0);
		Assertions.mustNotBeInAcceptingState(cipher0);

	}

	@Test
	public void cipherInvalidTest3()
			throws NoSuchPaddingException, IllegalBlockSizeException, NoSuchAlgorithmException, InvalidKeyException {

		Key wrappedKey = null;

		Cipher cipher0 = Cipher.getInstance("RSA");
		byte[] wrappedKeyBytes = cipher0.wrap(wrappedKey);
		Assertions.notHasEnsuredPredicate(wrappedKeyBytes);
		Assertions.mustNotBeInAcceptingState(cipher0);

	}

	@Test
	public void cipherInvalidTest4()
			throws BadPaddingException, NoSuchPaddingException, IllegalBlockSizeException, NoSuchAlgorithmException {

		byte[] plainText = null;

		Cipher cipher0 = Cipher.getInstance("RSA");
		byte[] cipherText = cipher0.doFinal(plainText);
		Assertions.notHasEnsuredPredicate(cipherText);
		Assertions.mustNotBeInAcceptingState(cipher0);

	}

	@Test
	public void cipherInvalidTest5() throws NoSuchPaddingException, NoSuchAlgorithmException, InvalidKeyException {

		Certificate cert = null;
		byte[] pre_plaintext = null;

		Cipher cipher0 = Cipher.getInstance("RSA");
		cipher0.init(1, cert);
		byte[] pre_ciphertext = cipher0.update(pre_plaintext);
		Assertions.hasEnsuredPredicate(cipher0);
		Assertions.mustNotBeInAcceptingState(cipher0);

	}

	@Test
	public void cipherInvalidTest6()
			throws BadPaddingException, NoSuchPaddingException, IllegalBlockSizeException, NoSuchAlgorithmException {

		byte[] plainText = null;
		byte[] pre_plaintext = null;

		Cipher cipher0 = Cipher.getInstance("RSA");
		byte[] pre_ciphertext = cipher0.update(pre_plaintext);
		byte[] cipherText = cipher0.doFinal(plainText);
		Assertions.notHasEnsuredPredicate(cipherText);
		Assertions.mustNotBeInAcceptingState(cipher0);

	}
}