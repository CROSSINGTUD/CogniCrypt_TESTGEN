package jca;

import test.assertions.Assertions;
import crypto.analysis.CrySLRulesetSelector.Ruleset;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import org.junit.Test;
import test.UsagePatternTestingFramework;

public class MessageDigestTest extends UsagePatternTestingFramework {
	protected Ruleset getRuleSet() {
		return Ruleset.JavaCryptographicArchitecture;

	}

	@Test
	public void messageDigestValidTest1() throws NoSuchAlgorithmException {

		byte[] inbytearr = null;

		MessageDigest messageDigest0 = MessageDigest.getInstance("SHA-256");
		byte[] out = messageDigest0.digest(inbytearr);
		Assertions.hasEnsuredPredicate(out);
		Assertions.mustBeInAcceptingState(messageDigest0);

	}

	@Test
	public void messageDigestValidTest2() throws NoSuchAlgorithmException {

		byte[] inbytearr = null;
		byte pre_inbyte = 0;

		MessageDigest messageDigest0 = MessageDigest.getInstance("SHA-256");
		byte[] out = messageDigest0.digest(inbytearr);
		messageDigest0.update(pre_inbyte);
		out = messageDigest0.digest();
		Assertions.hasEnsuredPredicate(out);
		Assertions.mustBeInAcceptingState(messageDigest0);

	}

	@Test
	public void messageDigestInvalidTest1() throws NoSuchAlgorithmException {

		MessageDigest messageDigest0 = MessageDigest.getInstance("SHA-256");
		Assertions.hasEnsuredPredicate(messageDigest0);
		Assertions.mustNotBeInAcceptingState(messageDigest0);

	}

	@Test
	public void messageDigestInvalidTest2() throws NoSuchAlgorithmException {

		byte pre_inbyte = 0;

		MessageDigest messageDigest0 = MessageDigest.getInstance("SHA-256");
		messageDigest0.update(pre_inbyte);
		byte[] out = messageDigest0.digest();
		Assertions.notHasEnsuredPredicate(out);
		Assertions.mustNotBeInAcceptingState(messageDigest0);

	}

	@Test
	public void messageDigestInvalidTest3() throws NoSuchAlgorithmException {

		byte[] inbytearr = null;

		MessageDigest messageDigest0 = MessageDigest.getInstance("SHA-256");
		byte[] out = messageDigest0.digest(inbytearr);
		out = messageDigest0.digest();
		Assertions.hasEnsuredPredicate(out);
		Assertions.mustNotBeInAcceptingState(messageDigest0);

	}
}