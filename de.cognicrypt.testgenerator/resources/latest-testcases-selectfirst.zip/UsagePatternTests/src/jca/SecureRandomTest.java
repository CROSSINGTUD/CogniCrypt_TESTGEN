package jca;

import java.security.SecureRandom;
import test.assertions.Assertions;
import crypto.analysis.CrySLRulesetSelector.Ruleset;
import java.security.NoSuchAlgorithmException;
import org.junit.Test;
import test.UsagePatternTestingFramework;

public class SecureRandomTest extends UsagePatternTestingFramework {
	protected Ruleset getRuleSet() {
		return Ruleset.JavaCryptographicArchitecture;

	}

	@Test
	public void secureRandomValidTest1() throws NoSuchAlgorithmException {

		SecureRandom secureRandom0 = SecureRandom.getInstance("SHA1PRNG");
		Assertions.hasEnsuredPredicate(secureRandom0);
		Assertions.mustBeInAcceptingState(secureRandom0);

	}

	@Test
	public void secureRandomValidTest2() throws NoSuchAlgorithmException {

		SecureRandom secureRandom1 = SecureRandom.getInstance("SHA1PRNG");
		byte[] genSeed = secureRandom1.generateSeed(0);
		Assertions.hasEnsuredPredicate(randInt);
		Assertions.mustBeInAcceptingState(secureRandom1);

		SecureRandom secureRandom0 = SecureRandom.getInstance("SHA1PRNG");
		secureRandom0.setSeed(genSeed);
		Assertions.hasEnsuredPredicate(secureRandom0);
		Assertions.mustBeInAcceptingState(secureRandom0);

	}

	@Test
	public void secureRandomValidTest3() throws NoSuchAlgorithmException {

		SecureRandom secureRandom0 = SecureRandom.getInstance("SHA1PRNG");
		byte[] genSeed = secureRandom0.generateSeed(0);
		Assertions.hasEnsuredPredicate(randInt);
		Assertions.mustBeInAcceptingState(secureRandom0);

	}

	@Test
	public void secureRandomValidTest4() throws NoSuchAlgorithmException {

		SecureRandom secureRandom1 = SecureRandom.getInstance("SHA1PRNG");
		byte[] genSeed = secureRandom1.generateSeed(0);
		Assertions.hasEnsuredPredicate(randInt);
		Assertions.mustBeInAcceptingState(secureRandom1);

		SecureRandom secureRandom0 = SecureRandom.getInstance("SHA1PRNG");
		secureRandom0.setSeed(genSeed);
		genSeed = secureRandom0.generateSeed(0);
		Assertions.hasEnsuredPredicate(randInt);
		Assertions.mustBeInAcceptingState(secureRandom0);

	}

	@Test
	public void secureRandomValidTest5() throws NoSuchAlgorithmException {

		SecureRandom secureRandom1 = SecureRandom.getInstance("SHA1PRNG");
		byte[] genSeed = secureRandom1.generateSeed(0);
		Assertions.hasEnsuredPredicate(randInt);
		Assertions.mustBeInAcceptingState(secureRandom1);

		SecureRandom secureRandom0 = SecureRandom.getInstance("SHA1PRNG");
		secureRandom0.setSeed(genSeed);
		genSeed = secureRandom0.generateSeed(0);
		secureRandom0.setSeed(genSeed);
		Assertions.hasEnsuredPredicate(randInt);
		Assertions.mustBeInAcceptingState(secureRandom0);

	}

	@Test
	public void secureRandomInvalidTest1() throws NoSuchAlgorithmException {

		SecureRandom secureRandom1 = SecureRandom.getInstance("SHA1PRNG");
		byte[] genSeed = secureRandom1.generateSeed(0);
		Assertions.hasEnsuredPredicate(randInt);
		Assertions.mustBeInAcceptingState(secureRandom1);

		SecureRandom secureRandom0 = SecureRandom.getInstance("SHA1PRNG");
		genSeed = secureRandom0.generateSeed(0);
		secureRandom0.setSeed(genSeed);
		Assertions.notHasEnsuredPredicate(randInt);
		Assertions.mustNotBeInAcceptingState(secureRandom0);

	}

	@Test
	public void secureRandomInvalidTest2() throws NoSuchAlgorithmException {

		SecureRandom secureRandom1 = SecureRandom.getInstance("SHA1PRNG");
		byte[] genSeed = secureRandom1.generateSeed(0);
		Assertions.hasEnsuredPredicate(randInt);
		Assertions.mustBeInAcceptingState(secureRandom1);

		SecureRandom secureRandom0 = SecureRandom.getInstance("SHA1PRNG");
		secureRandom0.setSeed(genSeed);
		secureRandom0.setSeed(genSeed);
		Assertions.hasEnsuredPredicate(secureRandom0);
		Assertions.mustNotBeInAcceptingState(secureRandom0);

	}
}