package jca;

import test.assertions.Assertions;
import crypto.analysis.CrySLRulesetSelector.Ruleset;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.DigestInputStream;
import org.junit.Test;
import java.io.IOException;
import test.UsagePatternTestingFramework;
import java.io.InputStream;

public class DigestInputStreamTest extends UsagePatternTestingFramework {
	protected Ruleset getRuleSet() {
		return Ruleset.JavaCryptographicArchitecture;

	}

	@Test
	public void digestInputStreamValidTest1() throws NoSuchAlgorithmException, IOException {

		byte[] inbytearr = null;

		MessageDigest messageDigest0 = MessageDigest.getInstance("SHA-256");
		byte[] out = messageDigest0.digest(inbytearr);
		Assertions.hasEnsuredPredicate(out);
		Assertions.mustBeInAcceptingState(messageDigest0);

		InputStream is = null;

		DigestInputStream digestInputStream0 = new DigestInputStream(is, messageDigest0);
		digestInputStream0.read();
		digestInputStream0.close();
		Assertions.hasEnsuredPredicate(is);
		Assertions.mustBeInAcceptingState(digestInputStream0);

	}

	@Test
	public void digestInputStreamInvalidTest1() throws NoSuchAlgorithmException {

		byte[] inbytearr = null;

		MessageDigest messageDigest0 = MessageDigest.getInstance("SHA-256");
		byte[] out = messageDigest0.digest(inbytearr);
		Assertions.hasEnsuredPredicate(out);
		Assertions.mustBeInAcceptingState(messageDigest0);

		InputStream is = null;

		DigestInputStream digestInputStream0 = new DigestInputStream(is, messageDigest0);
		Assertions.notHasEnsuredPredicate(is);
		Assertions.mustNotBeInAcceptingState(digestInputStream0);

	}

	@Test
	public void digestInputStreamInvalidTest2() throws NoSuchAlgorithmException, IOException {

		byte[] inbytearr = null;

		MessageDigest messageDigest0 = MessageDigest.getInstance("SHA-256");
		byte[] out = messageDigest0.digest(inbytearr);
		Assertions.hasEnsuredPredicate(out);
		Assertions.mustBeInAcceptingState(messageDigest0);

		InputStream is = null;

		DigestInputStream digestInputStream0 = new DigestInputStream(is, messageDigest0);
		digestInputStream0.read();
		Assertions.notHasEnsuredPredicate(is);
		Assertions.mustNotBeInAcceptingState(digestInputStream0);

	}

	@Test
	public void digestInputStreamInvalidTest3() throws NoSuchAlgorithmException, IOException {

		byte[] inbytearr = null;

		MessageDigest messageDigest0 = MessageDigest.getInstance("SHA-256");
		byte[] out = messageDigest0.digest(inbytearr);
		Assertions.hasEnsuredPredicate(out);
		Assertions.mustBeInAcceptingState(messageDigest0);

		InputStream is = null;

		DigestInputStream digestInputStream0 = new DigestInputStream(is, messageDigest0);
		digestInputStream0.close();
		Assertions.notHasEnsuredPredicate(is);
		Assertions.mustNotBeInAcceptingState(digestInputStream0);

	}
}