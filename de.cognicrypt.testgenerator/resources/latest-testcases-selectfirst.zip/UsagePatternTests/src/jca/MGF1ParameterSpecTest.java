package jca;

import test.assertions.Assertions;
import crypto.analysis.CrySLRulesetSelector.Ruleset;
import org.junit.Test;
import test.UsagePatternTestingFramework;
import java.security.spec.MGF1ParameterSpec;

public class MGF1ParameterSpecTest extends UsagePatternTestingFramework {
	protected Ruleset getRuleSet() {
		return Ruleset.JavaCryptographicArchitecture;

	}

	@Test
	public void mGF1ParameterSpecValidTest1() {

		MGF1ParameterSpec mGF1ParameterSpec0 = new MGF1ParameterSpec("SHA-256");
		Assertions.hasEnsuredPredicate(mGF1ParameterSpec0);
		Assertions.mustBeInAcceptingState(mGF1ParameterSpec0);

	}
}