package jca;

import test.assertions.Assertions;
import crypto.analysis.CrySLRulesetSelector.Ruleset;
import javax.crypto.IllegalBlockSizeException;
import org.junit.Test;
import java.io.IOException;
import javax.crypto.Cipher;
import javax.crypto.CipherInputStream;
import java.security.Key;
import java.security.cert.Certificate;
import javax.crypto.NoSuchPaddingException;
import java.security.NoSuchAlgorithmException;
import java.security.InvalidKeyException;
import test.UsagePatternTestingFramework;
import java.io.InputStream;

public class CipherInputStreamTest extends UsagePatternTestingFramework {
	protected Ruleset getRuleSet() {
		return Ruleset.JavaCryptographicArchitecture;

	}

	@Test
	public void cipherInputStreamValidTest1() throws NoSuchPaddingException, IllegalBlockSizeException,
			NoSuchAlgorithmException, InvalidKeyException, IOException {

		Certificate cert = null;
		Key wrappedKey = null;

		Cipher cipher0 = Cipher.getInstance("RSA");
		cipher0.init(1, cert);
		byte[] wrappedKeyBytes = cipher0.wrap(wrappedKey);
		Assertions.hasEnsuredPredicate(cipher0);
		Assertions.mustBeInAcceptingState(cipher0);

		InputStream is = null;

		CipherInputStream cipherInputStream0 = new CipherInputStream(is, cipher0);
		cipherInputStream0.read();
		cipherInputStream0.close();
		Assertions.hasEnsuredPredicate(is);
		Assertions.mustBeInAcceptingState(cipherInputStream0);

	}

	@Test
	public void cipherInputStreamInvalidTest1()
			throws NoSuchPaddingException, IllegalBlockSizeException, NoSuchAlgorithmException, InvalidKeyException {

		Certificate cert = null;
		Key wrappedKey = null;

		Cipher cipher0 = Cipher.getInstance("RSA");
		cipher0.init(1, cert);
		byte[] wrappedKeyBytes = cipher0.wrap(wrappedKey);
		Assertions.hasEnsuredPredicate(cipher0);
		Assertions.mustBeInAcceptingState(cipher0);

		InputStream is = null;

		CipherInputStream cipherInputStream0 = new CipherInputStream(is, cipher0);
		Assertions.notHasEnsuredPredicate(is);
		Assertions.mustNotBeInAcceptingState(cipherInputStream0);

	}

	@Test
	public void cipherInputStreamInvalidTest2() throws NoSuchPaddingException, IllegalBlockSizeException,
			NoSuchAlgorithmException, InvalidKeyException, IOException {

		Certificate cert = null;
		Key wrappedKey = null;

		Cipher cipher0 = Cipher.getInstance("RSA");
		cipher0.init(1, cert);
		byte[] wrappedKeyBytes = cipher0.wrap(wrappedKey);
		Assertions.hasEnsuredPredicate(cipher0);
		Assertions.mustBeInAcceptingState(cipher0);

		InputStream is = null;

		CipherInputStream cipherInputStream0 = new CipherInputStream(is, cipher0);
		cipherInputStream0.read();
		Assertions.notHasEnsuredPredicate(is);
		Assertions.mustNotBeInAcceptingState(cipherInputStream0);

	}

	@Test
	public void cipherInputStreamInvalidTest3() throws NoSuchPaddingException, IllegalBlockSizeException,
			NoSuchAlgorithmException, InvalidKeyException, IOException {

		Certificate cert = null;
		Key wrappedKey = null;

		Cipher cipher0 = Cipher.getInstance("RSA");
		cipher0.init(1, cert);
		byte[] wrappedKeyBytes = cipher0.wrap(wrappedKey);
		Assertions.hasEnsuredPredicate(cipher0);
		Assertions.mustBeInAcceptingState(cipher0);

		InputStream is = null;

		CipherInputStream cipherInputStream0 = new CipherInputStream(is, cipher0);
		cipherInputStream0.close();
		Assertions.notHasEnsuredPredicate(is);
		Assertions.mustNotBeInAcceptingState(cipherInputStream0);

	}
}