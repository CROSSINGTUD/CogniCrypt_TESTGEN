package jca;

import java.security.Key;
import java.lang.IllegalStateException;
import test.assertions.Assertions;
import crypto.analysis.CrySLRulesetSelector.Ruleset;
import javax.crypto.KeyAgreement;
import java.security.NoSuchAlgorithmException;
import org.junit.Test;
import java.security.InvalidKeyException;
import test.UsagePatternTestingFramework;

public class KeyAgreementTest extends UsagePatternTestingFramework {
	protected Ruleset getRuleSet() {
		return Ruleset.JavaCryptographicArchitecture;

	}

	@Test
	public void keyAgreementValidTest1() throws IllegalStateException, NoSuchAlgorithmException, InvalidKeyException {

		boolean lastPhase = false;
		Key key = null;

		KeyAgreement keyAgreement0 = KeyAgreement.getInstance("DH");
		keyAgreement0.init(key);
		keyAgreement0.doPhase(key, lastPhase);
		keyAgreement0.generateSecret();
		Assertions.hasEnsuredPredicate(key);
		Assertions.mustBeInAcceptingState(keyAgreement0);

	}

	@Test
	public void keyAgreementInvalidTest1() throws NoSuchAlgorithmException {

		KeyAgreement keyAgreement0 = KeyAgreement.getInstance("DH");
		Assertions.mustNotBeInAcceptingState(keyAgreement0);

	}

	@Test
	public void keyAgreementInvalidTest2() throws NoSuchAlgorithmException, InvalidKeyException {

		Key key = null;

		KeyAgreement keyAgreement0 = KeyAgreement.getInstance("DH");
		keyAgreement0.init(key);
		Assertions.notHasEnsuredPredicate(key);
		Assertions.mustNotBeInAcceptingState(keyAgreement0);

	}

	@Test
	public void keyAgreementInvalidTest3() throws IllegalStateException, NoSuchAlgorithmException, InvalidKeyException {

		boolean lastPhase = false;
		Key key = null;

		KeyAgreement keyAgreement0 = KeyAgreement.getInstance("DH");
		keyAgreement0.init(key);
		keyAgreement0.doPhase(key, lastPhase);
		Assertions.notHasEnsuredPredicate(key);
		Assertions.mustNotBeInAcceptingState(keyAgreement0);

	}

	@Test
	public void keyAgreementInvalidTest4() throws IllegalStateException, NoSuchAlgorithmException, InvalidKeyException {

		boolean lastPhase = false;
		Key key = null;

		KeyAgreement keyAgreement0 = KeyAgreement.getInstance("DH");
		keyAgreement0.doPhase(key, lastPhase);
		keyAgreement0.generateSecret();
		Assertions.notHasEnsuredPredicate(key);
		Assertions.mustNotBeInAcceptingState(keyAgreement0);

	}

	@Test
	public void keyAgreementInvalidTest5() throws IllegalStateException, NoSuchAlgorithmException, InvalidKeyException {

		Key key = null;

		KeyAgreement keyAgreement0 = KeyAgreement.getInstance("DH");
		keyAgreement0.init(key);
		keyAgreement0.generateSecret();
		Assertions.notHasEnsuredPredicate(key);
		Assertions.mustNotBeInAcceptingState(keyAgreement0);

	}
}