package jca;

import java.lang.IllegalStateException;
import test.assertions.Assertions;
import crypto.analysis.CrySLRulesetSelector.Ruleset;
import java.security.spec.InvalidKeySpecException;
import javax.crypto.Mac;
import org.junit.Test;
import java.security.SecureRandom;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import java.security.NoSuchAlgorithmException;
import java.security.InvalidKeyException;
import javax.crypto.SecretKey;
import test.UsagePatternTestingFramework;

public class MacTest extends UsagePatternTestingFramework {
	protected Ruleset getRuleSet() {
		return Ruleset.JavaCryptographicArchitecture;

	}

	@Test
	public void macValidTest1()
			throws IllegalStateException, InvalidKeySpecException, NoSuchAlgorithmException, InvalidKeyException {

		SecureRandom secureRandom0 = SecureRandom.getInstance("SHA1PRNG");
		byte[] genSeed = secureRandom0.generateSeed(0);
		Assertions.hasEnsuredPredicate(randInt);
		Assertions.mustBeInAcceptingState(secureRandom0);

		int keylength = 0;
		char[] password = null;

		PBEKeySpec pBEKeySpec0 = new PBEKeySpec(password, genSeed, 17166, keylength);
		Assertions.hasEnsuredPredicate(pBEKeySpec0);

		SecretKeyFactory secretKeyFactory0 = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA512");
		SecretKey secretKey = secretKeyFactory0.generateSecret(pBEKeySpec0);
		Assertions.hasEnsuredPredicate(secretKey);
		Assertions.mustBeInAcceptingState(secretKeyFactory0);

		Mac mac0 = Mac.getInstance("HmacMD5");
		mac0.init(secretKey);
		byte[] output1 = mac0.doFinal();
		Assertions.hasEnsuredPredicate(output1);
		Assertions.mustBeInAcceptingState(mac0);
		pBEKeySpec0.clearPassword();
		Assertions.mustBeInAcceptingState(pBEKeySpec0);

	}

	@Test
	public void macValidTest2()
			throws IllegalStateException, InvalidKeySpecException, NoSuchAlgorithmException, InvalidKeyException {

		SecureRandom secureRandom0 = SecureRandom.getInstance("SHA1PRNG");
		byte[] genSeed = secureRandom0.generateSeed(0);
		Assertions.hasEnsuredPredicate(randInt);
		Assertions.mustBeInAcceptingState(secureRandom0);

		int keylength = 0;
		char[] password = null;

		PBEKeySpec pBEKeySpec0 = new PBEKeySpec(password, genSeed, 24647, keylength);
		Assertions.hasEnsuredPredicate(pBEKeySpec0);

		SecretKeyFactory secretKeyFactory0 = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA512");
		SecretKey secretKey = secretKeyFactory0.generateSecret(pBEKeySpec0);
		Assertions.hasEnsuredPredicate(secretKey);
		Assertions.mustBeInAcceptingState(secretKeyFactory0);

		byte inp = 0;

		Mac mac0 = Mac.getInstance("HmacMD5");
		mac0.init(secretKey);
		mac0.update(inp);
		byte[] output1 = mac0.doFinal();
		Assertions.hasEnsuredPredicate(output1);
		Assertions.mustBeInAcceptingState(mac0);
		pBEKeySpec0.clearPassword();
		Assertions.mustBeInAcceptingState(pBEKeySpec0);

	}

	@Test
	public void macInvalidTest1() throws NoSuchAlgorithmException {

		Mac mac0 = Mac.getInstance("HmacMD5");
		Assertions.mustNotBeInAcceptingState(mac0);

	}

	@Test
	public void macInvalidTest2() throws InvalidKeySpecException, NoSuchAlgorithmException, InvalidKeyException {

		SecureRandom secureRandom0 = SecureRandom.getInstance("SHA1PRNG");
		byte[] genSeed = secureRandom0.generateSeed(0);
		Assertions.hasEnsuredPredicate(randInt);
		Assertions.mustBeInAcceptingState(secureRandom0);

		int keylength = 0;
		char[] password = null;

		PBEKeySpec pBEKeySpec0 = new PBEKeySpec(password, genSeed, 17419, keylength);
		Assertions.hasEnsuredPredicate(pBEKeySpec0);

		SecretKeyFactory secretKeyFactory0 = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA512");
		SecretKey secretKey = secretKeyFactory0.generateSecret(pBEKeySpec0);
		Assertions.hasEnsuredPredicate(secretKey);
		Assertions.mustBeInAcceptingState(secretKeyFactory0);

		Mac mac0 = Mac.getInstance("HmacMD5");
		mac0.init(secretKey);
		Assertions.mustNotBeInAcceptingState(mac0);
		pBEKeySpec0.clearPassword();
		Assertions.mustBeInAcceptingState(pBEKeySpec0);

	}

	@Test
	public void macInvalidTest3() throws IllegalStateException, NoSuchAlgorithmException {

		Mac mac0 = Mac.getInstance("HmacMD5");
		byte[] output1 = mac0.doFinal();
		Assertions.notHasEnsuredPredicate(output1);
		Assertions.mustNotBeInAcceptingState(mac0);

	}

	@Test
	public void macInvalidTest4()
			throws IllegalStateException, InvalidKeySpecException, NoSuchAlgorithmException, InvalidKeyException {

		SecureRandom secureRandom0 = SecureRandom.getInstance("SHA1PRNG");
		byte[] genSeed = secureRandom0.generateSeed(0);
		Assertions.hasEnsuredPredicate(randInt);
		Assertions.mustBeInAcceptingState(secureRandom0);

		int keylength = 0;
		char[] password = null;

		PBEKeySpec pBEKeySpec0 = new PBEKeySpec(password, genSeed, 28909, keylength);
		Assertions.hasEnsuredPredicate(pBEKeySpec0);

		SecretKeyFactory secretKeyFactory0 = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA512");
		SecretKey secretKey = secretKeyFactory0.generateSecret(pBEKeySpec0);
		Assertions.hasEnsuredPredicate(secretKey);
		Assertions.mustBeInAcceptingState(secretKeyFactory0);

		byte inp = 0;

		Mac mac0 = Mac.getInstance("HmacMD5");
		mac0.init(secretKey);
		mac0.update(inp);
		Assertions.mustNotBeInAcceptingState(mac0);
		pBEKeySpec0.clearPassword();
		Assertions.mustBeInAcceptingState(pBEKeySpec0);

	}

	@Test
	public void macInvalidTest5() throws IllegalStateException, NoSuchAlgorithmException {

		byte inp = 0;

		Mac mac0 = Mac.getInstance("HmacMD5");
		mac0.update(inp);
		byte[] output1 = mac0.doFinal();
		Assertions.notHasEnsuredPredicate(output1);
		Assertions.mustNotBeInAcceptingState(mac0);

	}
}