package jca;

import test.assertions.Assertions;
import crypto.analysis.CrySLRulesetSelector.Ruleset;
import javax.net.ssl.TrustManagerFactory;
import java.security.NoSuchAlgorithmException;
import javax.net.ssl.TrustManager;
import org.junit.Test;
import java.security.KeyStore;
import java.io.IOException;
import java.security.KeyStoreException;
import java.security.cert.CertificateException;
import test.UsagePatternTestingFramework;
import java.io.InputStream;

public class TrustManagerFactoryTest extends UsagePatternTestingFramework {
	protected Ruleset getRuleSet() {
		return Ruleset.JavaCryptographicArchitecture;

	}

	@Test
	public void trustManagerFactoryValidTest1()
			throws NoSuchAlgorithmException, IOException, KeyStoreException, CertificateException {

		InputStream fileinput = null;
		char[] passwordIn = null;

		KeyStore keyStore0 = KeyStore.getInstance("JCEKS");
		keyStore0.load(fileinput, passwordIn);
		Assertions.hasEnsuredPredicate(keyStore0);
		Assertions.mustBeInAcceptingState(keyStore0);

		TrustManagerFactory trustManagerFactory0 = TrustManagerFactory.getInstance("PKIX");
		trustManagerFactory0.init(keyStore0);
		Assertions.hasEnsuredPredicate(trustManagerFactory0);
		Assertions.mustBeInAcceptingState(trustManagerFactory0);

	}

	@Test
	public void trustManagerFactoryValidTest2()
			throws NoSuchAlgorithmException, IOException, KeyStoreException, CertificateException {

		InputStream fileinput = null;
		char[] passwordIn = null;

		KeyStore keyStore0 = KeyStore.getInstance("JCEKS");
		keyStore0.load(fileinput, passwordIn);
		Assertions.hasEnsuredPredicate(keyStore0);
		Assertions.mustBeInAcceptingState(keyStore0);

		TrustManagerFactory trustManagerFactory0 = TrustManagerFactory.getInstance("PKIX");
		trustManagerFactory0.init(keyStore0);
		TrustManager[] trustManager = trustManagerFactory0.getTrustManagers();
		Assertions.hasEnsuredPredicate(trustManagerFactory0);
		Assertions.mustBeInAcceptingState(trustManagerFactory0);

	}

	@Test
	public void trustManagerFactoryInvalidTest1() throws NoSuchAlgorithmException {

		TrustManagerFactory trustManagerFactory0 = TrustManagerFactory.getInstance("PKIX");
		Assertions.notHasEnsuredPredicate(trustManagerFactory0);
		Assertions.mustNotBeInAcceptingState(trustManagerFactory0);

	}

	@Test
	public void trustManagerFactoryInvalidTest2() throws NoSuchAlgorithmException {

		TrustManagerFactory trustManagerFactory0 = TrustManagerFactory.getInstance("PKIX");
		TrustManager[] trustManager = trustManagerFactory0.getTrustManagers();
		Assertions.notHasEnsuredPredicate(trustManager);
		Assertions.mustNotBeInAcceptingState(trustManagerFactory0);

	}
}