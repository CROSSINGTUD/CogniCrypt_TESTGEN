package jca;

import test.assertions.Assertions;
import javax.crypto.spec.OAEPParameterSpec;
import crypto.analysis.CrySLRulesetSelector.Ruleset;
import javax.crypto.spec.PSource;
import org.junit.Test;
import test.UsagePatternTestingFramework;
import java.security.spec.MGF1ParameterSpec;

public class OAEPParameterSpecTest extends UsagePatternTestingFramework {
	protected Ruleset getRuleSet() {
		return Ruleset.JavaCryptographicArchitecture;

	}

	@Test
	public void oAEPParameterSpecValidTest1() {

		MGF1ParameterSpec mGF1ParameterSpec0 = new MGF1ParameterSpec("SHA-256");
		Assertions.hasEnsuredPredicate(mGF1ParameterSpec0);
		Assertions.mustBeInAcceptingState(mGF1ParameterSpec0);

		PSource pSrc = null;

		OAEPParameterSpec oAEPParameterSpec0 = new OAEPParameterSpec("SHA-256", "MGF1", mGF1ParameterSpec0, pSrc);
		Assertions.hasEnsuredPredicate(oAEPParameterSpec0);
		Assertions.mustBeInAcceptingState(oAEPParameterSpec0);

	}
}