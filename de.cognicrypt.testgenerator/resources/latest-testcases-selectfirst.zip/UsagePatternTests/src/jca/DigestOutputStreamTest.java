package jca;

import java.io.OutputStream;
import java.security.DigestOutputStream;
import test.assertions.Assertions;
import crypto.analysis.CrySLRulesetSelector.Ruleset;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import org.junit.Test;
import java.io.IOException;
import test.UsagePatternTestingFramework;

public class DigestOutputStreamTest extends UsagePatternTestingFramework {
	protected Ruleset getRuleSet() {
		return Ruleset.JavaCryptographicArchitecture;

	}

	@Test
	public void digestOutputStreamValidTest1() throws NoSuchAlgorithmException, IOException {

		byte[] inbytearr = null;

		MessageDigest messageDigest0 = MessageDigest.getInstance("SHA-256");
		byte[] out = messageDigest0.digest(inbytearr);
		Assertions.hasEnsuredPredicate(out);
		Assertions.mustBeInAcceptingState(messageDigest0);

		int specifiedByte = 0;
		OutputStream os = null;

		DigestOutputStream digestOutputStream0 = new DigestOutputStream(os, messageDigest0);
		digestOutputStream0.write(specifiedByte);
		digestOutputStream0.close();
		Assertions.hasEnsuredPredicate(os);
		Assertions.mustBeInAcceptingState(digestOutputStream0);

	}

	@Test
	public void digestOutputStreamInvalidTest1() throws NoSuchAlgorithmException {

		byte[] inbytearr = null;

		MessageDigest messageDigest0 = MessageDigest.getInstance("SHA-256");
		byte[] out = messageDigest0.digest(inbytearr);
		Assertions.hasEnsuredPredicate(out);
		Assertions.mustBeInAcceptingState(messageDigest0);

		OutputStream os = null;

		DigestOutputStream digestOutputStream0 = new DigestOutputStream(os, messageDigest0);
		Assertions.notHasEnsuredPredicate(os);
		Assertions.mustNotBeInAcceptingState(digestOutputStream0);

	}

	@Test
	public void digestOutputStreamInvalidTest2() throws NoSuchAlgorithmException, IOException {

		byte[] inbytearr = null;

		MessageDigest messageDigest0 = MessageDigest.getInstance("SHA-256");
		byte[] out = messageDigest0.digest(inbytearr);
		Assertions.hasEnsuredPredicate(out);
		Assertions.mustBeInAcceptingState(messageDigest0);

		int specifiedByte = 0;
		OutputStream os = null;

		DigestOutputStream digestOutputStream0 = new DigestOutputStream(os, messageDigest0);
		digestOutputStream0.write(specifiedByte);
		Assertions.notHasEnsuredPredicate(os);
		Assertions.mustNotBeInAcceptingState(digestOutputStream0);

	}

	@Test
	public void digestOutputStreamInvalidTest3() throws NoSuchAlgorithmException, IOException {

		byte[] inbytearr = null;

		MessageDigest messageDigest0 = MessageDigest.getInstance("SHA-256");
		byte[] out = messageDigest0.digest(inbytearr);
		Assertions.hasEnsuredPredicate(out);
		Assertions.mustBeInAcceptingState(messageDigest0);

		OutputStream os = null;

		DigestOutputStream digestOutputStream0 = new DigestOutputStream(os, messageDigest0);
		digestOutputStream0.close();
		Assertions.notHasEnsuredPredicate(os);
		Assertions.mustNotBeInAcceptingState(digestOutputStream0);

	}
}